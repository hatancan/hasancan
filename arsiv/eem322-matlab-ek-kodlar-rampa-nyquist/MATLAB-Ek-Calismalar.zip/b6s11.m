clc;
clear all;

p=[1 4 8 2];
roots(p);

num=[0 0 0 1];
den=    [1 4 8 0];
rlocus(num,den);
%axis('square');
grid on;
title('Root Locus');