clc;
clear all;

p=[1 5 9 20 2];
roots(p);

num=[1 5 9 20 0];
den=[0 0 0 0 1];
rlocus(num,den);
%axis('square');
grid on;
title('Root Locus');