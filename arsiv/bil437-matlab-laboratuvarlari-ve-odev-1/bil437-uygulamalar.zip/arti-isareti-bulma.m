function islem1 = islem1(image)
[x,y]=size(image);
image2=zeros(x,y);
for m=1:x-2
    for n=1:y-2
        if image(m+1,n+1)==1 && image(m,n+1)==1 && image(m+1,n)==1 && image(m+1,n+2) && image(m+2,n+1)==1
            image2(m+1,n+1)=1;
        end
    end
end
islem1=image2;
end