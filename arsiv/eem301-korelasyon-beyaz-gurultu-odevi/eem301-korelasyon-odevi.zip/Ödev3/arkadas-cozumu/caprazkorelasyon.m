t=linspace(0,100,50);
x=10*cos(900*t+52);
y=5*cos(400*t+37);
figure(1);
N = length(x);
xlim([0,N])
[acor,lag]=xcorr(x,y);
plot(lag,acor)
