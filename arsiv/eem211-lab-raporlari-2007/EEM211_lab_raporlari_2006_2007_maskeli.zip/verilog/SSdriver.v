`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:    21:19:51 12/10/07
// Design Name:    
// Module Name:    SSdriver
// Project Name:   
// Target Device:  
// Tool versions:  
// Description:
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////
module SSdriver(SS,AN,mclk,S1,S2,S3,S4);
input mclk;
input [3:0] S1,S2,S3,S4;
output reg [7:0] SS;
output reg [3:0] AN;
wire [7:0] w1,w2,w3,w4;
wire clk;
wire [3:0] w5;
reg [1:0] cnt;
clkdiv cdiv(clk,mclk);
decoder d1(w1,S1);
decoder d2(w2,S2);
decoder d3(w3,S3);
decoder d4(w4,S4);
anode_decoder d5(w5,cnt);
initial cnt=0;
always @(posedge clk)
begin
cnt=cnt+1;
end
always @(cnt)
begin
AN<=w5;
case (cnt)
2'b00 : SS<=w1;
2'b01 : SS<=w2;
2'b10 : SS<=w3;
2'b11 : SS<=w4;
endcase
end
endmodule