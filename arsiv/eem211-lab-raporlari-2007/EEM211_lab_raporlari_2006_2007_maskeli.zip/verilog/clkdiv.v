`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:    21:22:07 12/10/07
// Design Name:    
// Module Name:    clkdiv
// Project Name:   
// Target Device:  
// Tool versions:  
// Description:
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////
module clkdiv(clk,mclk);
output clk;
input mclk;
reg [15:0] cnt;
assign clk=cnt[15];
initial cnt=0; // Don't forget!! Otherwise simulator does generate X only
always @(posedge mclk)
begin
cnt = cnt+1;
end
endmodule
