`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:    21:21:37 12/10/07
// Design Name:    
// Module Name:    decoder
// Project Name:   
// Target Device:  
// Tool versions:  
// Description:
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////
module decoder (SS,S);
output reg [7:0] SS;
input [3:0] S;
always @(S)
case (S)
0 : SS=8'b10000001;
1 : SS=8'b10011111;
2 : SS=8'b01001001;
3 : SS=8'b00001101;
4 : SS=8'b00010111;
5 : SS=8'b00100101;
6 : SS=8'b00100001;
7 : SS=8'b10001111;
8 : SS=8'b00000001;
9 : SS=8'b00000101;
10 : SS=8'b11111110;
default : SS=8'b11111111;
endcase
endmodule