`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:    21:23:34 12/10/07
// Design Name:    
// Module Name:    anode_decoder
// Project Name:   
// Target Device:  
// Tool versions:  
// Description:
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////
module anode_decoder(AN,cnt);
output reg [3:0] AN;
input [1:0] cnt;
always @(cnt)
case (cnt)
0 : AN=4'b1110;
1 : AN=4'b1101;
2 : AN=4'b1011;
3 : AN=4'b0111;
default : AN=4'b1111;
endcase
endmodule