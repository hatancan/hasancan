/* Template fonksiyon kullanarak iterator yard�m� ile liste elemanlar�n�n
   de�erlerini de�i�tirmeye y�neli bir �rnek...
*/
#include <list> 
#include <iostream>
#include <iomanip>
using namespace std;

template <typename T>
void yaz(T& Ref)
{
    list<int>::iterator p; 
    for (p = Ref.begin ( ); p != Ref.end ( ); p++)  
	cout <<setw(5)<< *p ;
	cout<<endl;
}

template <typename T>
void degistir(T& Ref)
{
    list<int>::iterator p; 
    for (p = Ref.begin ( ); p != Ref.end ( ); p++)
	(*p)++;
}

int main () {

    list<int>L;     
    L.push_back (9);
    L.push_back (7);
    L.push_back (5);
    L.push_back (3);

    cout<<"Orjinal Liste : ";
    yaz(L);
    degistir(L);
    cout<<"Degismis Liste: ";
    yaz(L);
    system("pause");
    return 0;
}

/*
Orjinal Liste :     9    7    5    3
Degismis Liste:    10    8    6    4
Press any key to continue . . .
*/
