// Queue i�in STL Class�

#include <iomanip>
#include <iostream>
#include <queue>


#define boy 10

using namespace std;

int main()
{
queue<int> kuyruk;


for(int i=0;i<boy;i++)
kuyruk.push(i); // �nce 0 eklenir sonra arkas�na 1 sonra arkas�na 2 ...

cout<<"kuyruk boyu: "<<kuyruk.size()<<endl;

while(!kuyruk.empty())
{
  cout<<kuyruk.front()<<" ";
  kuyruk.pop();
}


cout<<endl;
system("pause");
return 0;
}

/* EKRAN CIKTISI
----------------
kuyruk boyu: 10
0 1 2 3 4 5 6 7 8 9
Press any key to continue . . .
*/

/*

bool empty() const;
 kuyruk bo� ise True , de�ilse False.
 
T& front();
kuyru�un en �n�ndeki elemana referans d�nd�r�r.
�nko�ul: Y���n bo� olmamal�. 

const T& front()const;
 front() fonksiyonunun sabit olan�d�r.
 
 
void pop() : kuyru�un en �n�nden eleman siler.
Precondition (�n ko�ul) : kuyruk bo� olmamal�

void push(const T & item ) : item isimli arg�man� kuyru�un en sonuna ekler
Postcondition (Sondurum):  kuyru�un en sonunda yeni bir eleman olu�ur.

int size() const;
 kuyruktaki eleman say�s�n� d�nd�r�r.
 
*/
