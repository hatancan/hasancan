/*
void pop(); 
   A��klama:
      Y���t�n en �st�ndeki eleman� y���ttan ��kart�r.
     (ilkdurum)Precondition : Stack bo� olmamal�
     (Sondurum)Postcondition : Stack bo� olabilir (tek eleman varsa)
                               Stackin en �st�ndeki eleman de�i�ir.
                               Stackdeki eleman say�s� 1 azal�r.
       
void push( const T & item); 
      A��klama :
               Parametre olarak verilen de�eri stackin en �st�ne ekler.
               (Sondurum)Postcondition : Stacin tepesinde yeni bir eleman olur.

T& top();
   A��klama: En �stteki elemana referance olacak de�er d�nd�r�r.
   (Precondition) : Stack bo� olmamal�d�r.

const T& top() const;
   Di�erinin const versiyonudur.
   
   
bool empty() const; 
   A��klama: Stack bo� ise true d�nd�r�r.

int size() const;
   Stackde bulunan eleman say�s�n� d�nd�r�r.
*/

#include <iostream>
#include <stack>

using namespace std;

int main()
{

stack<int> s;

s.push(1);
s.push(2);
s.push(3);


cout<< s.top()<<endl;
s.pop();
cout<< s.top()<<endl;
s.pop();
cout<< s.top()<<endl;
s.pop();

   if(s.empty()==1)
     cout<<"Stack bos !!"<<endl;
   else
     cout<<"Dolu"<<endl;
     
system("pause");
return 0;
}
/*
3
2
1
Stack bos !!
*/
