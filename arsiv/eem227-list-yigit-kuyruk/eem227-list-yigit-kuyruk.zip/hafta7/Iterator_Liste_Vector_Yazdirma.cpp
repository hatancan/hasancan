// iterator kullanarak liste ve vector elemanlar�n� yazd�rma yontemi...
#include <iostream>
#include <iomanip>
#include <list>
#include <vector>


using namespace std;

 
int main()
{
int a[5]={1,3,5,7,9};
double b[5]={2.2,4.4,6.6,8.8,10.10};

int sizea=sizeof(a)/sizeof(int);
int sizeb=sizeof(b)/sizeof(double);


  list<int> listA(a,a+sizea);   // int listenin de�erlerini belirledik.
  list<double> listB(b,b+sizeb);// double listenin de�erlerini belirledik.
vector<int> Avector(a,a+sizea); // vector�n de�erlerini belirledik.
 
  list<int>::iterator iterA;    // int liste i�in iterator tan�mlad�k
  list<double>::iterator iterB; // double liste i�in iterator tan�mlad�k
vector<int>::iterator Vec_it;   // vectorler i�inde iteratorler kullan�labilir !
  
  
//-----------------------------------------------------  
// int Listeyi ba��ndan sonuna do�ru listeyi yazd�ral�m
// listelerde indis ile de�ere ula�amad���m�z i�in iterator kullanmak zorunludur
   iterA = listA.begin();
   cout << "int Liste bastan sona dogru   : ";
  while(iterA!=listA.end())
   { 
    cout<<*iterA<<" ";
    iterA++;
   }

cout<<"\nfor dongusu ile ayni listeyi tekrar yazdiralim \n";
   for ( iterA = listA.begin(); iterA != listA.end(); iterA ++ ) {
    cout << *iterA << "  ";
  }
//------------------------------------------------------

  
   cout<<endl<<endl;

//-----------------------------------------------------------------------------   
// Liste sonundan ba��na do�ru listeyi eksiksiz yazd�ral�m...
   iterB = listB.end();
   iterB--; 
   cout << "double Liste Sondan basa dogru: ";
   // Listelerde tan�ml� olan indis y�ntemi olmad��� i�in begin ve end gibi
   // fonksiyonlarla iterat�r�m�z� konumland�r�yoruz.
   // end fonksiyonu listenin sonundaki elemandan bir sonraki konumu g�sterir,
   // dolay�s�yla yazd�rmaya ba�lamadan �nce bir kez iteratoru geri �ektik...
   while(iterB!=listB.begin())
   { 
    cout << * iterB << " ";
    iterB --;
   }
   cout << *iterB; // ilk eleman�da yazd�rabilmek i�in koyduk...
//-----------------------------------------------------------------------------   

cout<<endl<<endl;
//--------------------------------------------------------------------
// Bir vekt�r� indis operat�r� olmadan iterator yard�m� ile yazd�ral�m  
  Vec_it = Avector.begin();
  cout << "int Vector bastan sona dogru  : " ;
while(Vec_it!=Avector.end())
   { 
    cout << *Vec_it << " ";
    Vec_it ++;
   }
//---------------------------------------------------------------------

   cout<<endl<<endl;
 
system("pause");
return 0;
} 

/*
int Liste bastan sona dogru   : 1 3 5 7 9
for dongusu ile ayni listeyi tekrar yazdiralim
1  3  5  7  9

double Liste Sondan basa dogru: 10.1 8.8 6.6 4.4 2.2

int Vector bastan sona dogru  : 1 3 5 7 9

Press any key to continue . . .
*/
