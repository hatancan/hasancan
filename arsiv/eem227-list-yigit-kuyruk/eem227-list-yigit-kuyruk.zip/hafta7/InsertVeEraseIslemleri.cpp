/*
 Bu program bir liste olu�turduktan sonra, bu listeye istenilen konuma 
 eleman ekleme i�lemi ve istenilen konumdaki eleman� silme i�lemi yapar.
 �ndis operatoru olmad���ndan dolay� liste elemanlar� �zerinde dolan�rken
 iteratorlerden faydalan�l�r...

 Listenin fonksiyonlar� olan insert() ve erase() fonksiyonlar� parametre olarak
 i�lem yap�lacak liste �zerinde tan�mlanm�� bir iteratoru almal�d�r.

*/
#include <list> 
#include <iostream>
#include <iomanip>
using namespace std;

template <typename T>
void yaz(T& Ref)
{
    list<int>::iterator p; 
    for (p = Ref.begin ( ); p != Ref.end ( ); p++)  
	cout <<setw(5)<< *p ;
	cout<<endl;
}


int main () {

    list<int>L;     
    L.push_back (10);
    L.push_front (20);
    L.push_back (40);
    L.push_back (5);
    L.push_front (15);
    L.push_front (50);

    cout<<"Orjinal Liste: "<<endl;
    yaz(L);
    
list<int>::iterator iter1,iter2;
    iter1 = L.begin(); // iterator listenin ilk eleman�n� g�sterir
    iter1 ++; // iterator bir sonraki eleman� i�aret etmektedir.
    
    cout<<"3 eklenmeden once iteratorun gosterdigi deger : "<<*iter1<<endl;
    L.insert(iter1,3); // insert i�lemi iteratorun g�sterdi�i yerden �nceki 
                       // konuma yap�l�r !!! Listenin boyu 1 artar
                       // ekleme noktas�n�n sa��nda kalan de�erler 1 sa�a shift 
                       // ettirilir..
    
   cout<<"Eklendikten sonra iteratorun gosterdigi deger : "<<*iter1<<endl<<endl; 
                    // ekleme i�lemi yap�ld�ktan sonra iterat�r�n g�sterdi�i
                       // de�er de�i�mez !!! iteratorde 1 kez sola kaym��t�r.
    
    cout<<"3 eklendikten sonra Listenin durumu: "<<endl;
    yaz(L);
    
    
    
    iter2 = L.end(); // listenin en son eleman�ndan sonraki konuma konu�lan�r.
    iter2-- ; // iteratoru listenin en son eleman� olacak �ekilde 1 kez �ektik.
    iter2-- ; // iteratoru sondan 1 �nceki elemana �eker.
    cout<<"Silmeden once iteratorun gosterdigi deger : "<<*iter2<<endl;
    
    L.erase(iter2); // ve iteratorun g�sterdi�i eleman silinir.
    cout<<"Sildikten sonra iteratorun gosterdigi deger : "<<*iter2<<endl<<endl;
    // silme i�leminden sonra itertorun gosterdi�i de�er listeden ��kart�l�r,
    // fakar o iterator silinen eleman� hala g�stermektedir...
    
    cout<<"Silme isleminden sonra Listenin durumu: "<<endl;
    yaz(L);
    
    system("pause");
    return 0;
}

/*
Orjinal Liste:
   50   15   20   10   40    5

3 eklenmeden once iteratorun gosterdigi deger : 15
Eklendikten sonra iteratorun gosterdigi deger : 15

3 eklendikten sonra Listenin durumu:
   50    3   15   20   10   40    5

Silmeden once iteratorun gosterdigi deger : 40
Sildikten sonra iteratorun gosterdigi deger : 40

Silme isleminden sonra Listenin durumu:
   50    3   15   20   10    5
Press any key to continue . . .
*/
