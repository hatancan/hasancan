// Vector veri yap�s�n� kullanarak, kendi Queue yap�n�z� olu�turun

#include <iostream>
#include <vector>
using namespace std;

template <typename T>
class MyQueue
{
      vector<T> data;
   public:
     void Add(T const &);
     void Remove();
     void Print();
};

template <typename T> 
void MyQueue<T> ::Add(T const &d)
{
     data.push_back(d);
}

template <typename T> 
void MyQueue<T>::Remove()
{
     data.erase(data.begin( ) + 0,data.begin( ) + 1); //en ba�dan 1.eleman� sil
}

template <typename T> 
void MyQueue<T>::Print()
{
     vector <int>::iterator It1;
     It1 = data.begin();
     for ( It1 = data.begin( ) ; It1 != data.end( ) ; It1++ )
        cout << " " << *It1<<endl;

}

int main()
{
     MyQueue<int> q;
     q.Add(1);
     q.Add(24);
     q.Add(32);
     q.Add(11);
     q.Add(72);
     q.Add(3);
     
     cout<<"Veriler (Silmeden Once)"<<endl;
     q.Print();

     q.Remove();
     cout<<"Veriler (Sildikten Sonra)"<<endl;
     q.Print();
system("pause");
return 0;
}
