/*
Soru : Klavyeden girilen N basamakl� bir say�y� tersten yazd�rabilen bir
program� queue veri yap�s� kullanarak kodlay�n�z.
*/
#include <queue>
#include <iostream>
using namespace std;

int main()
{
int sayi,bas=0;
queue<int> Bque;
cout<<"Max. 10 basamakli bir sayi giriniz : ";
cin>>sayi;
do{
          if(sayi!=0)
          {
           bas=sayi%10;
           sayi/=10;
           Bque.push(bas);
          }
          else
           break;
  }while((sayi!=0));

cout<<"Tersten Sayi : ";
while(!Bque.empty())
{
 cout<<Bque.front();
 Bque.pop();
}
cout<<endl;
system("pause");
return 0;
}
