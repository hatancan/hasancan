/*
Soru:
10 elemanl�k rastgele karakter de�erlerinden olu�mu� LL olu�turun.
Sona ekle y�ntemi ile yap�n�z.
*/
#include<iostream>
#include<ctime>   
using namespace std;

template <typename T>
class node
{
 
  private:
      T nodeValue;      // data held by the node
      node<T> *next;    // next node in the list
      
   public:
      node(const T& item, node<T> *nextNode=NULL)			  
      {
         nodeValue=item;
		 next=nextNode;
	  }

/*
 fonksiyona Class dan t�remi� nesne olmadan eri�mek i�in fonksiyonu static
tan�mlad�k */	  
static T printList(node<T> *ptr)
      {

        while (ptr->next != NULL) // Araya ok koymak i�in bu �ekilde yapt�k...
        {
         cout << ptr->nodeValue<<"->" ;
         ptr = ptr->next;
        }
         cout<<ptr->nodeValue<<"->NULL" ;
           cout << endl;

       }

};

int main()
{
    
node<char> *P,*head=NULL;

srand(time(NULL));
for(int i=1 ; i<10 ; i++)
{
 P = new node<char> (65+rand()%26,head);
 head = P;
}

// nesne kullanmadan scope resolution ile static fonksiyona eri�tik...
 node<char>::printList(head); 
 
 system("pause");
 return 0;
}

/*
Q->Q->J->H->T->S->U->A->U->NULL
Press any key to continue . . .
*/
