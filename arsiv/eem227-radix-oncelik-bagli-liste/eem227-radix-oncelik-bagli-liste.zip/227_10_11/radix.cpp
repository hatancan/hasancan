/* 1) 
  RADIX SORT (Tabana g�re s�ralama)
  ---------------------------------
   3 basama�a kadar olan 20 adet random say�y� radix sort ile s�ralar.
   
  * d basamakl� say�lar i�in �al��ma zaman� O(2*d*n)=O(n) kadard�r.
  * Lineer bir algoritmad�r. 
  * Say�lar� kar��la�t�rarak s�ralama i�lemi yapmad��� i�in h�zl� �al���r.  

*/
#include <iostream>
#include <iomanip>
#include <vector>
#include <queue>
#include <time.h>
using namespace std;

void distribute(const vector<int>& v, queue<int> digitQueue[],int power)
{
	int i;
	for (i = 0; i < v.size(); i++)
		digitQueue[(v[i] / power) % 10].push(v[i]);
}


void collect(queue<int> digitQueue[], vector<int>& v)
{
	int i = 0, digit;
	for (digit = 0; digit < 10; digit++)

		while (!digitQueue[digit].empty())
		{
			v[i] = digitQueue[digit].front();
			digitQueue[digit].pop();
			i++;
		}
}


void radixSort(vector<int>& v, int d)
{
	int i;
	int power = 1;
	queue<int> digitQueue[10]; // 10 adet  queue yarat�ld�

	for (i=0;i < d;i++)
	{
		distribute(v, digitQueue, power);
		collect(digitQueue, v);
		power *= 10;
	}
}


void displayVector(const vector<int>& v)
{
	int i;

	for (i=0; i < v.size(); i++)
	{
		cout << setw(12) << v[i];
		if ((i+1) % 6 == 0)		// newline every 6 numbers
			cout << endl;
	}
	cout << endl;
}

int main()
{
	vector<int> intVector;
	
	srand(time(NULL));
	int bnumber=2; // sa�dan ka� basama�a g�ree s�ralama yap�lacak
	int i;
	for (i = 0; i < 20; i++)
		intVector.push_back(rand()%100);
	cout<<"SIRALAMADAN ONCE VEKTORUN ICINDEKI BILGI \n";
    displayVector(intVector);
    
    cout<<"SIRALANDIKTAN SONRA VECTORUN ICINDEKI BILGI \n";
	radixSort(intVector, bnumber);
	displayVector(intVector);
	system("pause");
	return 0;
}
/* 
SIRALAMADAN ONCE VEKTORUN ICINDEKI BILGI
          13          68          47          48          72          48
          64          91          32          56          28          75
          23          75          31          61          60          80
          66          69
SIRALANDIKTAN SONRA VECTORUN ICINDEKI BILGI
          13          23          28          31          32          47
          48          48          56          60          61          64
          66          68          69          72          75          75
          80          91
Press any key to continue . . .
*/
