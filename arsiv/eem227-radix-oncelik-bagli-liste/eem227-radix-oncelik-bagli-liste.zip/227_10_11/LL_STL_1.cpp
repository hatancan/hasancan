/*
 Soru 1
   LL olu�turun
*/
#include<iostream>   
using namespace std;

template <typename T>
class node
{
 
  private:
      T nodeValue;      // data held by the node
      node<T> *next,*curr;    // next node in the list
      
         
   public:
      node(const T& item, node<T> *nextNode=NULL)			  
      {
         nodeValue=item;
		 next=nextNode;
	  }

/*
 fonksiyona Class dan t�remi� nesne olmadan eri�mek i�in fonksiyonu static
tan�mlad�k */	  
static void printList(node<T> *ptr)
      {
        while (ptr->next != NULL) // Araya ok koymak i�in bu �ekilde yapt�k...
        {
         cout << ptr->nodeValue<<" -> " ;
         ptr = ptr->next;
        }
         cout<<ptr->nodeValue<<" -> NULL" ;
           cout << endl;
       }

};

int main()
{
// Listenin ba��na ekleyen yap�...

 node<int> *p = new node<int>(10);
 node<int> *q = new node<int>(20,p);
 node<int> *r = new node<int>(30,q);

// nesne kullanmadan scope resolution ile fonksiyona eri�tik
 node<int>::printList(r); 
 
 system("pause");
 return 0;
}

/*
30 -> 20 -> 10 -> NULL
Press any key to continue . . .
*/

