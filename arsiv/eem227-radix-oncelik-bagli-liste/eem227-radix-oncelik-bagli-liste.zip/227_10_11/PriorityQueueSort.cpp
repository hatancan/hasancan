/* 3)
Priority Queue i�erisine aktar�m i�lemi zaten �nceli�e yani b�y�kl��e g�re 
s�ral� bir �ekilde otomatik olarak yap�ld��� i�in, ekstradan bir kar��la�t�rma
i�lemi yapmam�za gerek yoktur... */
#include <queue>
#include <iomanip>
#include <iostream>
#include <vector>
using namespace std;
 
int main()
{
priority_queue<int> pq;
//int arr[]={16,29,14,32,18,14,87,50,64,35};
int arr[]={1,1,10,9,8,7,6,5,4,3,2,1};
int arrsize=sizeof(arr)/sizeof(int);
vector<int> v(arr,arr+arrsize);	 
	 
int i, n=v.size(); 

cout<<"Vektor ilk Hali (Sirasiz): ";
  	for(i = 0; i < n; i++)
		cout << v[i] << "  ";
 	cout << endl;

// S�ralayan k�s�m-----------
for(int i=0 ; i<n ; i++)

  pq.push(v[i]);
 
for(int i=n-1 ; i>=0 ; i--) // K���kten b�y��e s�ralar
//for(int i=0 ; i<n ; i++)  // B�y�kten k����e s�ralar
{
 v[i] = pq.top(); 
 pq.pop();
} // S�ralama bitti------------


cout<<"Vektor Son hali (Sirali) : ";
 	for(i = 0; i < n; i++)
		cout << v[i] << "  ";
 	cout << endl;

system("pause");
return 0;
}
/* EKRAN �IKTISI
-----------------
Vektor ilk Hali (Sirasiz): 1  1  10  9  8  7  6  5  4  3  2  1
Vektor Son hali (Sirali) : 1  1  1  2  3  4  5  6  7  8  9  10 
*/
