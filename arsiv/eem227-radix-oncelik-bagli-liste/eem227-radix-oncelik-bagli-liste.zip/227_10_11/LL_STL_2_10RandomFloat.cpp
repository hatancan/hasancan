/*
Soru:
10 adet random float say�dan olu�an bir link list olu�turun,ekranda listeleyin.
Listeyi olu�tururken elemanlar� ba�a ekle y�ntemini kullanarak LL'e ekleyin.
*/
#include<iostream>   
using namespace std;

template <typename T>
class node
{
 
  private:
      T nodeValue;      // data held by the node
      node<T> *next;    // next node in the list
      
   public:
      node(const T& item, node<T> *nextNode=NULL)			  
      {
         nodeValue=item;
		 next=nextNode;
	  }

/*
 fonksiyona Class dan t�remi� nesne olmadan eri�mek i�in fonksiyonu static
tan�mlad�k */	  
static T printList(node<T> *ptr)
      {

        while (ptr->next != NULL) // Araya ok koymak i�in bu �ekilde yapt�k...
        {
         cout << ptr->nodeValue<<"->" ;
         ptr = ptr->next;
        }
         cout<<ptr->nodeValue<<"->NULL" ;
           cout << endl;

       }

};

int main()
{
    
node<float> *P;

for(int i=0 ; i<10 ; i++)
 P = new node<float> (15.0/(rand()%40*1.0),P);

// nesne kullanmadan scope resolution ile static fonksiyona eri�tik...
 node<float>::printList(P); 
 
 system("pause");
 return 0;
}

