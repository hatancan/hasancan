/*  2)
    PRIORITY QUEUELAR
    -----------------
Y�ksek �ncelikli olanlar priority queue nun en �st�nde bulunur.
Yani i�leme en �nce giren de�erler bunlard�r.
Dolay�s�yla,  queue ya push edilen de�erleri push edilme s�ras�na g�re de�il
�nceli�ine g�re queue den ��kart�r( top() ) eder. 
Normal Queue da bulunan FIFO kural� priority queuda ge�erli de�ildir !!!
*/

#include <queue>
#include <iomanip>
#include <iostream>
#include <vector>
using namespace std;
int main()
{
 
// �NCEL�KL� KUYRUK
// FIFO olarak �ALI�MAZ !!!
priority_queue<int> pq;
pq.push(10);
pq.push(30); // ---> En y�ksek prioritye sahip olan de�er bu !!! En �sttedir
pq.push(5);
pq.push(3);
cout<<"PRIORITY QUEUE"<<endl;
cout<<"Size : "<<pq.size()<<endl<<"Yuksek Oncelikli Olan : "<<pq.top()<<endl;

// NORMAL KUYRUK
//---------------
// Dikkat normal queue nun top fonksiyonu yoktur !!! front() fonksiyonu vard�r.
queue<int> s;
s.push(10); // ----> ilk giren bu First In, �lk ��kacak da bu !
s.push(30);
s.push(5);
s.push(3);

int x=s.front();
cout<<endl<<"NORMAL QUEUE"<<endl;
cout<<"Size : "<<s.size()<<endl<<"FIFO dan dolayi kuyruktan cikan : "<<x<<endl;
 
system("pause");
return 0;
}
/* EKRAN �IKTISI
-----------------
PRIORITY QUEUE
Size : 4
Yuksek Oncelikli Olan : 30

NORMAL QUEUE
Size : 4
FIFO dan dolayi kuyruktan cikan : 10 
*/
