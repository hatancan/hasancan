/*
Soru 4: Fonksiyonsuz
     Tam say�lardan olu�an 10 elemanl�k bir listeyi sona ekleyerek olu�turun.
*/
#include<iostream>
#include<ctime>   
using namespace std;

template <typename T>
class node
{
   public:
 
      T nodeValue;      // data held by the node
      node<T> *next;    // next node in the list
      
      node(const T& item, node<T> *nextNode=NULL)			  
      {
         nodeValue=item;
		 next=nextNode;
	  }

/*
 fonksiyona Class dan t�remi� nesne olmadan eri�mek i�in fonksiyonu static
tan�mlad�k */	  
static T printList(node<T> *ptr)
      {

        while (ptr->next != NULL) // Araya ok koymak i�in bu �ekilde yapt�k...
        {
         cout << ptr->nodeValue<<"->" ;
         ptr = ptr->next;
        }
         cout<<ptr->nodeValue<<"->NULL" ;
           cout << endl;

       }

};

int main()
{
    
node<int> *head=NULL,*curr;

srand(time(NULL));

for(int i=1 ; i<=10 ; i++)
{

 if(head == NULL)
   head = new node<int> (i);
 
 else
 {
 curr = head;

 while(curr->next!=NULL)
   curr = curr->next;
 
 curr->next = new node<int> (i); ;
 }
}

// nesne kullanmadan scope resolution ile static fonksiyona eri�tik...
 node<int>::printList(head); 

 
 system("pause");
 return 0;
}

/*
1->2->3->4->5->6->7->8->9->10->NULL
Press any key to continue . . .
*/
