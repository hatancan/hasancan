/*
    Circular Doubly Linked List
    
Kac eleman listeye eklenecek ? 4
Listeye eklenecek degeri giriniz: 13
Listeye eklenecek degeri giriniz: 12
Listeye eklenecek degeri giriniz: 42
Listeye eklenecek degeri giriniz: 34
Saat Yonunde Yazd�ral�m
<-12<=>13<=>34<=>42->
Saat Yonu Tersi Yazd�ral�m
<-12<=>42<=>34<=>13->

  Silinecek Degeri Giriniz : 12
Silme islemi basarili
Saat Yonunde Yazd�ral�m
<-13<=>34<=>42->
Saat Yonu Tersi Yazd�ral�m
<-13<=>42<=>34->
Press any key to continue . . .
*/

#include<iostream>
#include<ctime>   
using namespace std;

template <typename T>
class node
{
private: 
      T nodeValue;      // data held by the node
      node<T> *next;    // next node in the list
      node<T> *pre;     // previous node in the list
public:

 node(const T& item, node<T> *nextNode=NULL, node<T> *previousNode=NULL)		  
      {
         nodeValue=item;
		 next=nextNode;
		 pre=previousNode;
	  }

static T LLSiraliEkle(T value, node<T> * &ptr)
{

node<T> *curr=ptr,*pre=ptr,*s;
 
 if( ptr == NULL) // Liste bo� ise ilk nodu heade yerle�tir.
      {
       ptr = new node<T> (value);
       ptr->next = ptr;
       ptr->pre = ptr;
      }
 
 else if (ptr->nodeValue >= value) //  (head�n solu gibi d���n)
     {
     while(curr->nodeValue >= value && curr->next != ptr)
        curr = curr->next; // Saat y�n�nde dolan�p head den 1 �nceye geldik.
     
       s = new node<T> (value);
       s->next = ptr;
       s->pre = curr;
       curr->next = s;
       ptr->pre = s;
       ptr = s; 
     }  
 
else  
 { 
  while (curr->nodeValue <= value && curr->next!=ptr)
    {
      pre = curr; 
      curr = curr->next;  
     }  
      
   if(curr->next == ptr && curr->nodeValue <= value) // saat y�n�nde gti
       {
         s = new node<T> (value);
         s->next = ptr;
         s->pre = curr; 
         ptr->pre = s;
         curr->next = s;
       }
       
       
   else  // araya ekle
         {
          s = new node<T> (value);
          pre->next = s;
          s->pre = pre;
          s->next = curr;
          curr->pre = s;
         }      
  
 } // ELSE
}

static T printList(node<T> *ptr) // Saat Yonunde listeyi yazd�r
      {
        cout<<"<-";
        node<T>*curr = ptr;
        while (curr->next != ptr) // Araya ok koymak i�in bu �ekilde yapt�k...
        {
         cout << curr->nodeValue<<"<=>" ;
         curr = curr->next;
        }
         cout<<curr->nodeValue<<"->" ;
           cout << endl;
       }
       
       
static T printListT(node<T> *ptr) // Saat yonunun tersinde listeyi yazd�rma
      {
        cout<<"<-";
        node<T>*curr = ptr;
        while (curr->pre != ptr) // Araya ok koymak i�in bu �ekilde yapt�k...
        {
         cout << curr->nodeValue<<"<=>" ;
         curr = curr->pre;
        }
         cout<<curr->nodeValue<<"->" ;
           cout << endl;
       }
       
static T node<T>::ListedenSil(T value,node<T>* &ptr)
  {
     
node<T> *curr=ptr,*pre=ptr,*s;
 
 if( ptr == NULL) // Liste bo� ise
         cout<<"Liste yaratilmamis !" ;

 else if (ptr->nodeValue == value && ptr->next!=ptr) // �lk eleman silinecek
     {
       ptr = ptr->next;
       curr->pre->next = curr->next ;
       curr->next->pre = curr->pre;
       delete curr;
//       ptr->pre = ptr;
  //     ptr->next = ptr;
       cout<<"Silme islemi basarili"<<endl;
     }  
 
else  
 { 
  while (curr->nodeValue != value && curr->next!=ptr)
    {
      pre = curr; 
      curr = curr->next;  
     }  
      
   if(curr->next == ptr && curr->nodeValue == value) // sondakini sil
       {
         pre->next = ptr;
         ptr->pre = pre;
         delete curr;
       }
       
   else  // silinecek eleman arada ise
         {
          pre->next = curr->next;
          curr->next->pre = pre;
          delete curr;
         }      
         cout<<"Silme islemi basarili"<<endl;
  
 } // ELSE
 
 
  }
  
};
 
 
int main()
{
 node<int> *head=NULL;

  int SilinecekDeger;
  int adet,deger;
 
 srand(time(NULL));
 cout<<"Kac eleman listeye eklenecek ? ";
 cin>>adet;
 
 for(int i=0; i<adet; i++)
 {  
    cout<<"Listeye eklenecek degeri giriniz: ";
    cin>>deger;
    node<int>::LLSiraliEkle(deger,head);
 }
     
     cout<<"Saat Yonunde Yazd�ral�m\n";     
     node<int>::printList(head);
     cout<<"Saat Yonu Tersi Yazd�ral�m\n";
     node<int>::printListT(head);
 
 cout<<"\n Silinecek Degeri Giriniz : ";
 cin>>SilinecekDeger;
 
 if( node<int>::ListedenSil(SilinecekDeger,head ) )
    {
     cout<<"Saat Yonunde Yazd�ral�m\n";     
     node<int>::printList(head);
     cout<<"Saat Yonu Tersi Yazd�ral�m\n";
     node<int>::printListT(head);
     }
 else
    cout<<" Silinecek deger listede bulunamad� !\n";
  
  system("pause");
  return 0;
}
