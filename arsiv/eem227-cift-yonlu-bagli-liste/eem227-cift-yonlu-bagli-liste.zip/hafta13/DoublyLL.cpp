/*
    Doubly Linked List  
    
    Kac eleman listeye eklenecek ? 7
Listeye eklenecek degeri giriniz: 35
Listeye eklenecek degeri giriniz: 888
Listeye eklenecek degeri giriniz: 41
Listeye eklenecek degeri giriniz: 2
Listeye eklenecek degeri giriniz: 7
Listeye eklenecek degeri giriniz: 98
Listeye eklenecek degeri giriniz: 45
NULL<-2<=>7<=>35<=>41<=>45<=>98<=>888->NULL

 Silinecek Degeri Giriniz : 45
Silme islemi basarili
NULL<-2<=>7<=>35<=>41<=>98<=>888->NULL
Press any key to continue . . .

*/

#include<iostream>
#include<ctime>   
using namespace std;

template <typename T>
class node
{
private: 
      T nodeValue;      // data held by the node
      node<T> *next;    // next node in the list
      node<T> *pre;     // previous node in the list
public:

 node(const T& item, node<T> *nextNode=NULL, node<T> *previousNode=NULL)			  
      {
         nodeValue=item;
		 next=nextNode;
		 pre=previousNode;
	  }

static T LLSiraliEkle(T value, node<T> * &ptr)
{

node<T> *curr=ptr,*pre=ptr,*s;
 
 if( ptr == NULL) // Liste bo� ise ilk nodu heade yerle�tir.
      {
       ptr = new node<T> (value);
       ptr->next = NULL;
       ptr->pre = NULL;
      }
 
 else if (ptr->nodeValue >= value) // Ba�a ekle (sola)
     {
       s = new node<T> (value);
       s->next = ptr;
       ptr->pre = s;
       s->pre = NULL;
       ptr = s; 
     }  
 
else  
 { 
  while (curr->nodeValue <= value && curr->next!=NULL)
    {
      pre = curr; 
      curr = curr->next;  
     }  
      
   if(curr->next == NULL && curr->nodeValue <= value) // sona ekle
       {
         s = new node<T> (value);
         s->next = NULL;
         curr->next = s;
         s->pre = curr; 
       }
       
   else  // araya ekle
         {
          s = new node<T> (value);
          pre->next = s;
          s->pre = pre;
          s->next = curr;
          curr->pre = s;
         }      
  
 } // ELSE
}

static T printList(node<T> *ptr)
      {
        cout<<"NULL<-";
        while (ptr->next != NULL) // Araya ok koymak i�in bu �ekilde yapt�k...
        {
         cout << ptr->nodeValue<<"<=>" ;
         ptr = ptr->next;
        }
         cout<<ptr->nodeValue<<"->NULL" ;
           cout << endl;
       }
       
static T node<T>::ListedenSil(node<T>* &ptr, T value)
  {
     
node<T> *curr=ptr,*pre=ptr,*s;
 
 if( ptr == NULL) // Liste bo� ise
         cout<<"Liste yaratilmamis !" ;

 
 else if (ptr->nodeValue == value) // �lk eleman silinecek
     {
       ptr = ptr->next;
       delete curr;
       ptr->pre = NULL;
       cout<<"Silme islemi basarili"<<endl;
     }  
 
else  
 { 
  while (curr->nodeValue != value && curr->next!=NULL)
    {
      pre = curr; 
      curr = curr->next;  
     }  
      
   if(curr->next == NULL && curr->nodeValue == value) // sondakini sil
       {
         pre->next = NULL;
         delete curr;
       }
       
   else  // silinecek eleman arada ise
         {
          pre->next = curr->next;
          curr->next->pre = pre;
          delete curr;
         }      
         cout<<"Silme islemi basarili"<<endl;
  
 } // ELSE
 
 
  }
  
};
 

 
int main()
{
 node<int> *head=NULL;

  int SilinecekDeger;
  int adet,deger;
 
 srand(time(NULL));
 cout<<"Kac eleman listeye eklenecek ? ";
 cin>>adet;
 
 for(int i=0; i<adet; i++)
 {  
    cout<<"Listeye eklenecek degeri giriniz: ";
    cin>>deger;
    node<int>::LLSiraliEkle(deger,head);
    node<int>::printList(head);
 }
 
 cout<<endl;
 cout<<"Tum Liste\n";
     node<int>::printList(head);
 cout<<"\n Silinecek Degeri Giriniz : ";
 cin>>SilinecekDeger;
 
 if( node<int>::ListedenSil(head,SilinecekDeger) )
     node<int>::printList(head);
 else
    cout<<" Silinecek deger listede bulunamad� !\n";
  
  system("pause");
  return 0;
}
