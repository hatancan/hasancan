;THE FORM OF AN ASSEMBLY LANGUAGE PROGRAM
; USING SIMPLIFIED SEGMENT DEFINITION
		.MODEL SMALL
		.STACK 64
		.DATA
DATA            DB 69,87,96,45,75
		SONUC DB ?
		.CODE
MAIN		PROC	FAR		;this is the program entry point
		MOV	AX,@DATA	;load the data segment address
		MOV	DS,AX		;assign value to DS
		MOV DI,OFFSET DATA
		MOV CX,5
		MOV AX,00
AGAIN:		CMP AL,[DI]
		JA NEXT
		MOV AL,[DI]
		INC DI
NEXT:		LOOP AGAIN
		MOV SONUC,AL	
		MOV	AH,4CH	;set up to
		INT	21H		;return to DOS
MAIN		ENDP			
		END	MAIN		;this is the program exit point