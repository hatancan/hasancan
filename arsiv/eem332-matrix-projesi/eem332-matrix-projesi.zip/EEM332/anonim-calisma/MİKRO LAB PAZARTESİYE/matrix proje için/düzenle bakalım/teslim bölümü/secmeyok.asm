	.model small
	.stack 100h
.data

	ekranyazi db 13,10,"matrix ekran koruyucu"
		  db 13,10,""
		  db 13,10,"$"
	KARAKTER  db 'a'
	varColor  db 027h 	;renk ayarı
	satirNo	  db 5
	sutunNo	  db 10



.code
Program:
	call basla
	mov dx, OFFSET ekranyazi

	call mesajYazdir
	
	call tusKontrol
	call ekranTemizle

main:	
	call karakterYaz
	call kaydir
	call Shortdelay
	call rastgele
	call tusKontrol2
	jc main		;tusKontrol2 döngüsündeki stc'ye bağlı olarak çalışır (bitsin mi bitmesin mi kontrolü)
	call son




PROC basla
	mov ax,@DATA	;tipik başlangıç işlemleri
	mov ds,ax
	mov es,ax	;extra segment
ret
ENDP basla



PROC mesajYazdir
	push ax
	
	mov ah,09h	;write string to standart output
	int 21h
	
	pop ax
ret
ENDP mesajYazdir



PROC tusKontrol
	push ax
	
	mov ah,01h	;read character from standart input
	int 21h		;işleme başlamak için bir tuşa basılması bekleniyor
	
	pop ax
ret
ENDP tusKontrol




PROC ekranTemizle
	push ax bx cx dx

	mov bl,0
	mov bh,0
	sub cx,cx
	mov dx,184fh	;18h = 24 satır  &  4f = 79 sütun
	mov ax,0600h	;scroll all lines up
	int 10h

	pop dx cx bx ax
ret
ENDP ekranTemizle




PROC son
	push ax

	mov ah,4ch	;tipik sonlandırma işlemleri
	int 21h
	
	pop ax
ret
ENDP son




PROC kaydir
	add satirNo,1	;karakterleri kaydırma işlemi
	add sutunNo,2

	cmp satirNo,23	;ekrana sığabilecek maksimum satır sayısı
	jna satirOnay	;jump not above
	mov satirNo,1
satirOnay:
	cmp sutunNo,79	;ekrana sığabilecek maksimum sütun sayısı
	jna sutunOnay	
	mov sutunNo,0
sutunOnay:
ret
ENDP kaydir







PROC rastgele
		MOV AH,2CH		;saati kullanarak rastgele sayı üretiyor
		INT 21H	
		MOV KARAKTER,DL
ret
ENDP rastgele







PROC Shortdelay
	push ax bx cx dx   ; 1 saniye gecikme
	mov cx,10h 
delay0: 
	push cx 
	mov cx, 00fffh 
delay1: 
	loop delay1 
	pop cx 
	loop delay0 
	pop dx cx bx ax 
ret
ENDP Shortdelay 







PROC tusKontrol2
	push ax
	mov ah,0Bh	;Durum kontrolü, sonuç al'de 00 veya FF ile döner
	int 21h		;
	cmp al,0
	jnz Devam
	stc		;Carry Flag 1 yapılır, ana döngüde devam edilip edilmeyeceği buraya bağlı
Devam:	pop ax
ret
ENDP tusKontrol2








PROC karakterYaz
	push ax bx cx dx bp
	
	mov ah,13h			;write string
	mov al,01h			;yeşil renk
	xor bh,bh			;sayfa numarası   ///   video page
	mov bp, OFFSET KARAKTER		;yazılacak bölüm
	mov bl, varColor           	;renk ayarı 
	mov cx,1			;number of characters in string

	mov dh,satirNo			;satır numarası atanır (kural-int10)
	mov dl,sutunNo			;sütun numarası atanır (kural-int10)

	int 10h
	pop bp dx cx bx ax
ret
ENDP karakterYaz






END Program