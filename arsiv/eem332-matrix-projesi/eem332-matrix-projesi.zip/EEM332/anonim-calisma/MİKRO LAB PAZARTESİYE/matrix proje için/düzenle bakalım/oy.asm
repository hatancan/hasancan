	.model small
	.stack 100h
.data
	max_length equ 100
	ekranyazi db 13,10,"matrix ekran koruyucu"
		  db 13,10,""
		  db 13,10,"$"
	KARAKTER  db 'a'
	satirNo	  db 5
	sutunNo	  db 10
	aralik    db max_length dup (?)
	hiz 	  db max_length dup (?)



.code
Program:
	call basla
	mov dx, OFFSET ekranyazi

	call mesajYazdir
	call hizAl
	call aralikAl
	
	call tusKontrol
	call ekranTemizle

main:	
	call karakterYaz
	call kaydir
	call Shortdelay
	call rastgele
	call tusKontrol2
	jc main		;tusKontrol2 döngüsündeki stc'ye bağlı olarak çalışır (bitsin mi bitmesin mi kontrolü)
	call son




PROC basla
	mov ax,@DATA
	mov ds,ax
	mov es,ax	;extra segment
ret
ENDP basla



PROC mesajYazdir
	push ax
	
	mov ah,09h	;write string to standart output
	int 21h
	
	pop ax
ret
ENDP mesajYazdir



PROC tusKontrol
	push ax
	
	mov ah,01h	;read character from standart input
	int 21h
	
	pop ax
ret
ENDP tusKontrol




PROC ekranTemizle
	push ax bx cx dx

	mov bl,0
	mov bh,0
	sub cx,cx
	mov dx,184fh	;18h = 24 satır  &  4f = 79 sütun
	mov ax,0600h	;scroll all lines up
	int 10h

	pop dx cx bx ax
ret
ENDP ekranTemizle




PROC son
	push ax

	mov ah,4ch
	int 21h
	
	pop ax
ret
ENDP son




PROC kaydir
	add satirNo,1
	add sutunNo,2

	cmp satirNo,23
	jna satirOnay	;jump not above
	mov satirNo,1
satirOnay:
	cmp sutunNo,79
	jna sutunOnay
	mov sutunNo,0
sutunOnay:
ret
ENDP kaydir







PROC rastgele
	MOV AH,2CH
	INT 21H		;GET SYSTEM TIME	;veya shr olur mu??
			;CH = HOUR		;(elimizdeki bir değer için)
			;CL = MINUTE
			;DH = SECOND
			;DL = 1/100 SECONDS
	mov satirNo,dh
	mov sutunNo,dl
	
	
ret
ENDP rastgele







PROC Shortdelay
		push si di
		cmp hiz,'1'
		je delay1
		cmp hiz,'2'
		je delay2
		cmp hiz,'3'
		je delay3
delay1:	
		mov di, 0900h
		;mov di,0100h		;???????????????
		cmp aralik, '1'
		jz nextdec1
		cmp aralik, '2'
		jz nextdec2
		cmp aralik,'3'
		jz nextdec3

delay2:	
		mov di, 2000h
		cmp aralik, '1'
		jz nextdec1
		cmp aralik ,'2'
		jz nextdec2
		cmp aralik,'3'
		jz nextdec3
		
delay3:		
		mov di, 4000h
		cmp aralik, '1'
		jz nextdec1
		cmp aralik, '2'
		jz nextdec2
		cmp aralik,'3'
		jz nextdec3
nextDec1:
		mov si, 2500h
		jmp decsi1
decSi1: 		
		dec si
		jnz decSi1
		dec di
		jnz nextDec1
		pop di si
		ret

nextDec2: 	
		mov si, 5000h
		jmp decsi2
decSi2: 
		dec si
		jnz decSi2
		dec di
		jnz nextDec2
		pop di si
		ret		

nextDec3: 
		mov si, 7000h
		jmp decsi3
decSi3: 		
		dec si
		jnz decSi3
		dec di
		jnz nextDec3
		pop di si
		ret		
ret
ENDP Shortdelay 







PROC tusKontrol2
	push ax
	mov ah,0Bh	;Durum kontrolü, sonuç al'de 00 veya FF ile döner
	int 21h		;
	cmp al,0
	jnz Devam
	stc		;Carry Flag 1 yapılır, ana döngüde devam edilip edilmeyeceği buraya bağlı
Devam:	pop ax
ret
ENDP tusKontrol2








PROC karakterYaz
	push ax bx cx dx bp
	
	mov ah,13h			;write string
	mov al,01h
	xor bh,bh			;sayfa numarası??????????
	mov bp, OFFSET KARAKTER		;yazılacak bölüm
	mov cx,1			;number of characters in string

	mov dh,satirNo			;satır numarası atanır (kural-int10)
	mov dl,sutunNo			;sütun numarası atanır (kural-int10)

	int 10h
	pop bp dx cx bx ax
ret
ENDP karakterYaz







PROC hizAl
	
	;MOV AH,09H	; menunun 2satiri	şimdilik alma!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	;INT 21H
	MOV AH,3FH 	;hiz al
	MOV BX,0
	MOV CX,max_length
	MOV DX,offset hiz 
	INT 21H
ret
ENDP hizAl





PROC aralikAl
	
	;MOV AH,09H	; menunun 3satiri	şimdilik alma!!!!!!!!!!!!!!!!!!!!!
	;INT 21H
	MOV AH,3FH 	;aralik al
	MOV BX,0
	MOV CX,max_length
	MOV DX,offset aralik
	INT 21H
ret
ENDP aralikAl




END Program