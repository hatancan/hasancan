	.model small
	.stack 100h
.data

	ekranyazi db 13,10,"matrix ekran koruyucu"
		  db 13,10,""
		  db 13,10,"$"
	KARAKTER  db 'a'
	satirNo	  db 5
	sutunNo	  db 10



.code
Program:
	call basla
	mov dx, OFFSET ekranyazi

	call mesajYazdir
	
	call tusKontrol
	call ekranTemizle

main:	
	call karakterYaz
	call kaydir
	call Shortdelay
	call rastgele
	call tusKontrol2
	jc main		;tusKontrol2 döngüsündeki stc'ye bağlı olarak çalışır (bitsin mi bitmesin mi kontrolü)
	call son




PROC basla
	mov ax,@DATA
	mov ds,ax
	mov es,ax	;extra segment
ret
ENDP basla



PROC mesajYazdir
	push ax
	
	mov ah,09h	;write string to standart output
	int 21h
	
	pop ax
ret
ENDP mesajYazdir



PROC tusKontrol
	push ax
	
	mov ah,01h	;read character from standart input
	int 21h
	
	pop ax
ret
ENDP tusKontrol




PROC ekranTemizle
	push ax bx cx dx

	mov bl,0
	mov bh,0
	sub cx,cx
	mov dx,184fh	;18h = 24 satır  &  4f = 79 sütun
	mov ax,0600h	;scroll all lines up
	int 10h

	pop dx cx bx ax
ret
ENDP ekranTemizle




PROC son
	push ax

	mov ah,4ch
	int 21h
	
	pop ax
ret
ENDP son




PROC kaydir
	add satirNo,1
	add sutunNo,2

	cmp satirNo,23
	jna satirOnay	;jump not above
	mov satirNo,1
satirOnay:
	cmp sutunNo,79
	jna sutunOnay
	mov sutunNo,0
sutunOnay:
ret
ENDP kaydir







PROC rastgele
	MOV AH,2CH
	INT 21H		;GET SYSTEM TIME	;veya shr olur mu??
			;CH = HOUR		;(elimizdeki bir değer için)
			;CL = MINUTE
			;DH = SECOND
			;DL = 1/100 SECONDS

	MOV AL,DL
	
	MOV AH,0	;
	MOV BX,10	;
	DIV BL		;AX DECIMAL'E ÇEVRİLDİ
	OR AX,3030H	;DECIMAL AX ASCII'YE ÇEVRİLDİ

	MOV CX,0
	MOV CL,AH
	MOV DL,AL
ret
ENDP rastgele







PROC Shortdelay
	push ax bx cx dx   ; 1 saniye gecikme
	mov cx,10h 
delay0: 
	push cx 
	mov cx, 00fffh 
delay1: 
	loop delay1 
	pop cx 
	loop delay0 
	pop dx cx bx ax 
ret
ENDP Shortdelay 







PROC tusKontrol2
	push ax
	mov ah,0Bh	;Durum kontrolü, sonuç al'de 00 veya FF ile döner
	int 21h		;
	cmp al,0
	jnz Devam
	stc		;Carry Flag 1 yapılır, ana döngüde devam edilip edilmeyeceği buraya bağlı
Devam:	pop ax
ret
ENDP tusKontrol2








PROC karakterYaz
	push ax bx cx dx bp
	
	mov ah,13h			;write string
	mov al,01h
	xor bh,bh			;sayfa numarası??????????
	mov bp, OFFSET KARAKTER		;yazılacak bölüm
	mov cx,1			;number of characters in string

	mov dh,satirNo			;satır numarası atanır (kural-int10)
	mov dl,sutunNo			;sütun numarası atanır (kural-int10)

	int 10h
	pop bp dx cx bx ax
ret
ENDP karakterYaz






END Program