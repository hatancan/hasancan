;------------------------------------------------------------------------------------;
;                                      5x7 LED matrix                                ;
; Klavyeden girilen karakterler, önce paralel veriye dönüştürülür. Veri eğer,        ;
; gösterilebilecek bir karakterse, PIC'in EEPROM'una TUŞ KODU olarak kaydedilir.     ;
; Program EEOKU bölümüne geçtiğinde, EEPROM'a kaydedilmiş kodları sırasıyla okur.    ;
; Okunan kod, çevrim tablosu tarafından karaktere dönüştürülür. Elde edilen yeni     ;
; veri, LED display'lere gönderilir.	7 KASIM 2003 CUMA                            ;
;------------------------------------------------------------------------------------;
		LIST	P=16F84A
		INCLUDE	<P16F84A.INC>
		__CONFIG	_CP_OFF &_WDT_OFF &_PWRTE_ON &_XT_OSC
;------------------------------------------------------------------------------------;
; Register tanımlamaları                                                             ;
;------------------------------------------------------------------------------------;

TEMP		EQU	H'0F'	; Geçici register.

VERI		EQU	H'11'	; Seri verinin paralel olarak saklandığı file.
BIT_N		EQU	H'12'	; Klavyeden alınan bit sayısı.
CHAR_SUTUN	EQU	H'13'	; Karakterin sütun sayısı.
EEREAD_N	EQU	H'14'	; EEPROM'dan okunacak maximum sütun sayısı.
EEWRITE_N	EQU	H'15'	; EEPROM'a kaydedilen maximum sütun sayısı.
LINE		EQU	H'16'	; Çevrim tablosunda ulaşılacak satır no.

TIMER_H1	EQU	H'1A'	; Timer HIGH1.
TIMER_H2	EQU	H'1B'	; Timer HIGH2.
TIMA		EQU	H'1C'	; TimerA
TIMB		EQU	H'1D'	; TimerB
W_TEMP		EQU	H'1E'	; W'nin saklandığı geçici register.
STATUS_TEMP	EQU	H'1F'	; STATUS'ın saklandığı geçici register.

SUTUN1		EQU	H'21'	; Sütun 1 bilgisinin saklandığı register.
SUTUN2		EQU	H'22'	; Sütun 2 bilgisinin saklandığı register.
SUTUN3		EQU	H'23'	; Sütun 3 bilgisinin saklandığı register.
SUTUN4		EQU	H'24'	; Sütun 4 bilgisinin saklandığı register.
SUTUN5		EQU	H'25'	; Sütun 5 bilgisinin saklandığı register.
SUTUN6		EQU	H'26'	; Sütun 6 bilgisinin saklandığı register.
SUTUN7		EQU	H'27'	; Sütun 7 bilgisinin saklandığı register.
SUTUN8		EQU	H'28'	; Sütun 8 bilgisinin saklandığı register.
SUTUN9		EQU	H'29'	; Sütun 9 bilgisinin saklandığı register.
SUTUN10		EQU	H'2A'	; Sütun 10 bilgisinin saklandığı register.
SUTUN11		EQU	H'2B'	; Sütun 11 bilgisinin saklandığı register.
SUTUN12		EQU	H'2C'	; Sütun 12 bilgisinin saklandığı register.
SUTUN13		EQU	H'2D'	; Sütun 13 bilgisinin saklandığı register.
SUTUN14		EQU	H'2E'	; Sütun 14 bilgisinin saklandığı register.
SUTUN15		EQU	H'2F'	; Sütun 15 bilgisinin saklandığı register.
SUTUN16		EQU	H'30'	; Sütun 16 bilgisinin saklandığı register.
SUTUN17		EQU	H'31'	; Sütun 17 bilgisinin saklandığı register.
SUTUN18		EQU	H'32'	; Sütun 18 bilgisinin saklandığı register.
SUTUN19		EQU	H'33'	; Sütun 19 bilgisinin saklandığı register.
SUTUN20		EQU	H'34'	; Sütun 20 bilgisinin saklandığı register.
SUTUN21		EQU	H'35'	; Sütun 21 bilgisinin saklandığı register.
SUTUN22		EQU	H'36'	; Sütun 22 bilgisinin saklandığı register.
SUTUN23		EQU	H'37'	; Sütun 23 bilgisinin saklandığı register.
SUTUN24		EQU	H'38'	; Sütun 24 bilgisinin saklandığı register.

;------------------------------------------------------------------------------------;
		
		ORG	H'0000'		; RESET adresi.
		GOTO	MAIN		; Ana programa.
		
		ORG	H'0004'		; Kesme adresi.
		GOTO	KLYOKU		; Kesme alt programına.

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
YUKLE	; PORTA ve PORTB'nin başlangıç ayarları.
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;

		BSF	STATUS,RP0	; BANK1'e geç.
		MOVLW	B'00011000'	; W'ye H'10' yükle.
		MOVWF	PORTA		; Çıkışlar: RA0=CLOCK, RA1=RESET, RA2=PRESET
					; Girişler: RA3=SCAN_END, RA4=Klavye DATA
		MOVLW	B'10000000'	; W'ye H'7F' yükle.
		MOVWF	PORTB		; RB7 giriş (Klavye CLOCK), diğerleri çıkış.
		BCF	STATUS,RP0	; BANK0'a dön.
		CLRF	PORTB		; PORTB'yi temizle.
		RETURN

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
KLYTIMER	; Bu alt program, besleme gerilimin uygulanmasıyla birlikte,         ;
		; klavyeden gelen tanıtım bilgilerinin bitmesi için birkaç           ;
		; saniyelik bir gecikme sağlar.                                      ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;

		MOVLW	D'5'		; W'ye 5 yükle.
		MOVWF	TEMP		; TEMP'e gönder.
		
BEKLE		CALL	TIMER_HIGH	; Gecikme alt programını çağır.
		DECFSZ	TEMP,F		; TEMP-1, 0 mı?
		GOTO	BEKLE		; Hayır, TEMP'i eksiltmeye devam et.
		RETURN			; Alt programdan çık.

;------------------------------------------------------------------------------------;
MAIN	; Ana program.
;------------------------------------------------------------------------------------;

		CALL	YUKLE		; Portların başlangıç ayarlarını yap.
		CALL	KLYTIMER	; Klavyeden gelen parazitleri söndür.
		
		CLRF	VERI		; VERI'yi temizle.
		CLRF	EEREAD_N	; EEREAD_N'i temizle.
		CLRF	EEWRITE_N	; EEWRITE_N'i temizle.
		CLRF	EEADR		; EEADR'yi temizle.
		CLRF	PORTB		; PORTB'yi temizle.
		
		MOVLW	B'10001000'	; W'ye B'10001000' yükle.
		MOVWF	INTCON		; Genel kesme izni, PORTB kesmesi aktif.
		
;------------------------------------------------------------------------------------;
		
START		CLRF	PORTB		; PORTB'yi temizle.
		BSF	PORTA,0		; CLOCK hazır. (Düşen kenarla tetiklenir.)
		BCF	PORTA,1		; RESET=0
		BSF	PORTA,1		; RESET=1, sayıcılar saymaya hazır.
		CALL	SUTUN_TEMIZLE	; Sütun1...Sütun24'ü temizle.
		
KAYIT_SAYISI?	MOVLW	0		; W'ye 0 yaz.
		MOVWF	EEADR		; Veri sayısını okumak üzere EEADR'ye gönder.
		CALL	OKU		; Kayıt sayısını öğren ve dön.	
		MOVF	EEDATA,W	; Kayıt sayısını W'ye yaz.
		BTFSC	STATUS,Z	; Kayıt sayısı 0'dan farklı mı?
		GOTO	START		; Hayır, kayıtlı sütun sayısı "0"
		
DATA?255	MOVF	EEDATA,W	; EEDATA'yı W'ye yaz.
		SUBLW	D'255'		; 255-W
		BTFSC	STATUS,Z	; DATA, 255'ten farklı mı?
		GOTO	START		; Hayır 255, yeniden başla.
		MOVF	EEDATA,W	; EEDATA'yı W'ye yaz.
		MOVWF	EEREAD_N	; EEREAD_N register'a gönder.
		MOVWF	EEWRITE_N	; EEWRITE_N register'a gönder.
		
KAYIT_VARMI?	MOVF	EEREAD_N,W	; Okunacak karakter sayısını W'ye yaz.
		SUBLW	H'FF'		; 255-EEREAD_N
		BTFSC	STATUS,Z	; Okunacak bir kayıt var mı?
		GOTO	START		; Hayır, tüm kayıt silinmiş.

SONRAKI		INCF	EEADR,F		; EEADR+1
		CALL	OKU		; EEPROM'a kayıtlı veriyi al ve dön.
		MOVF	EEDATA,W	; EEDATA'yı W'ye yaz.
		MOVWF	VERI		; EEDATA'yı VERI'ye gönder.
		SUBLW	D'113'		; 113-VERI (Delete tuşunu kodu)
		BTFSC	STATUS,Z	; Basılan tuş DELETE'in dışında mı?
		GOTO	START		; Hayır, basılan tuş DELETE.
		
		CALL	ANALIZ		; Evet, tuşu analiz et, PORTB'den gönder.
				
		DECFSZ	EEREAD_N,F	; Kayıtlı son veri okundu mu?
		GOTO	BIR_SUTUN_BOS	; Hayır, karakter arası 1 sütun boş bırak.
		MOVLW	D'41'		; Evet.
		MOVWF	VERI		; W'ye boşluk karakterinin kodunu yaz.
		CALL	BOSLUK1		; Her CALL BOSLUK1...
		CALL	BOSLUK1		; ...komutuyla çağrılan...
		CALL	BOSLUK1		; ...alt programda 3 sütunluk...
		CALL	BOSLUK1		; ...boşluk bırakılır...
		CALL	BOSLUK1		; ...Bu, toplam olarak...
		CALL	BOSLUK1		; ...30 sütunluk boşluğa denk gelir....
		CALL	BOSLUK1		; ...24 sütun kaydırıldığında display...
		CALL	BOSLUK1		; ...söner. Bu noktadan itibaren 6 sütun...
		CALL	BOSLUK1		; ...kayma süresi kadar daha, ekran...
		CALL	BOSLUK1		; ...sönük kalacaktır.
		GOTO	START		; Ve tüm işlemleri yeniden yap.
		
BIR_SUTUN_BOS	MOVLW	H'00'		; W'ye 0 yükle.
		MOVWF	SUTUN1		; SUTUN1'e gönder.
		MOVWF	PORTB		; PORTB'den gönder.
		CALL	GOSTER		; Sütun bilgilerini göster.
		CALL	SHIFT		; 1 adım sola ötele.
		GOTO	SONRAKI		; Hayır, sonraki sütun bilgisini oku.
		
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
SUTUN_TEMIZLE	; Sütun verisini temizle.                                            ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;

		CLRF	SUTUN1
		CLRF	SUTUN2
		CLRF	SUTUN3
		CLRF	SUTUN4
		CLRF	SUTUN5
		CLRF	SUTUN6
		CLRF	SUTUN7
		CLRF	SUTUN8
		CLRF	SUTUN9
		CLRF	SUTUN10
		CLRF	SUTUN11
		CLRF	SUTUN12
		CLRF	SUTUN13
		CLRF	SUTUN14
		CLRF	SUTUN15
		CLRF	SUTUN16
		CLRF	SUTUN17
		CLRF	SUTUN18
		CLRF	SUTUN19
		CLRF	SUTUN10
		CLRF	SUTUN21
		CLRF	SUTUN22
		CLRF	SUTUN23
		CLRF	SUTUN24
		RETURN

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
OKU	; EEPROM'daki veriyi oku.
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;

		BSF	STATUS,RP0	; BANK1'e geç.
		BSF	EECON1,RD	; Girilen adresle ilgili veriyi oku.
		BCF	STATUS,RP0	; BANK0'a dön.
		RETURN

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
SHIFT	; Sütunları 1 adım sola ötele.                                               ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
		
		MOVF	SUTUN23,W	; 23. sütunu W'ye yaz.
		MOVWF	SUTUN24		; 24. sütuna gönder.
		
		MOVF	SUTUN22,W	; 22. sütunu W'ye yaz.
		MOVWF	SUTUN23		; 23. sütuna gönder.
		
		MOVF	SUTUN21,W	; 21. sütunu W'ye yaz.
		MOVWF	SUTUN22		; 22. sütuna gönder.
		
		MOVF	SUTUN20,W	; 20. sütunu W'ye yaz.
		MOVWF	SUTUN21		; 21. sütuna gönder.
		
		MOVF	SUTUN19,W	; 19. sütunu W'ye yaz.
		MOVWF	SUTUN20		; 20. sütuna gönder.
		
		MOVF	SUTUN18,W	; 18. sütunu W'ye yaz.
		MOVWF	SUTUN19		; 19. sütuna gönder.
		
		MOVF	SUTUN17,W	; 17. sütunu W'ye yaz.
		MOVWF	SUTUN18		; 18. sütuna gönder.
		
		MOVF	SUTUN16,W	; 16. sütunu W'ye yaz.
		MOVWF	SUTUN17		; 17. sütuna gönder.
		
		MOVF	SUTUN15,W	; 15. sütunu W'ye yaz.
		MOVWF	SUTUN16		; 16. sütuna gönder.

		MOVF	SUTUN14,W	; 14. sütunu W'ye yaz.
		MOVWF	SUTUN15		; 15. sütuna gönder.

		MOVF	SUTUN13,W	; 13. sütunu W'ye yaz.
		MOVWF	SUTUN14		; 14. sütuna gönder.

		MOVF	SUTUN12,W	; 12. sütunu W'ye yaz.
		MOVWF	SUTUN13		; 13. sütuna gönder.

		MOVF	SUTUN11,W	; 11. sütunu W'ye yaz.
		MOVWF	SUTUN12		; 12. sütuna gönder.

		MOVF	SUTUN10,W	; 10. sütunu W'ye yaz.
		MOVWF	SUTUN11		; 11. sütuna gönder.

		MOVF	SUTUN9,W	; 9. sütunu W'ye yaz.
		MOVWF	SUTUN10		; 10. sütuna gönder.

		MOVF	SUTUN8,W	; 8. sütunu W'ye yaz.
		MOVWF	SUTUN9		; 9. sütuna gönder.

		MOVF	SUTUN7,W	; 7. sütunu W'ye yaz.
		MOVWF	SUTUN8		; 8. sütuna gönder.

		MOVF	SUTUN6,W	; 6. sütunu W'ye yaz.
		MOVWF	SUTUN7		; 7. sütuna gönder.

		MOVF	SUTUN5,W	; 5. sütunu W'ye yaz.
		MOVWF	SUTUN6		; 6. sütuna gönder.

		MOVF	SUTUN4,W	; 4. sütunu W'ye yaz.
		MOVWF	SUTUN5		; 5. sütuna gönder.

		MOVF	SUTUN3,W	; 3. sütunu W'ye yaz.
		MOVWF	SUTUN4		; 4. sütuna gönder.

		MOVF	SUTUN2,W	; 2. sütunu W'ye yaz.
		MOVWF	SUTUN3		; 3. sütuna gönder.

		MOVF	SUTUN1,W	; 1. sütunu W'ye yaz.
		MOVWF	SUTUN2		; 2. sütuna gönder.
		RETURN

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
GOSTER	; Tablodan alınan sütun bilgisini PORTB'den gönderme.                        ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
		
		MOVF	SUTUN1,W	; 1. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN2,W	; 2. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN3,W	; 3. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN4,W	; 4. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN5,W	; 5. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN6,W	; 6. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN7,W	; 7. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN8,W	; 8. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN9,W	; 9. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN10,W	; 10. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN11,W	; 11. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN12,W	; 12. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN13,W	; 13. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN14,W	; 14. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN15,W	; 15. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN16,W	; 16. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN17,W	; 17. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN18,W	; 18. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN19,W	; 19. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN20,W	; 20. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN21,W	; 21. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN22,W	; 22. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN23,W	; 23. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		MOVF	SUTUN24,W	; 24. sütunu W'ye yaz.
		CALL	GOSTER_ALT	; Diğer işlemler için alt programı çağır.
		
		RETURN
		
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
GOSTER_ALT	; Bu alt program, sütun verisini PORTB'den gönderir.                 ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
		
		MOVWF	PORTB		; Sütun bilgisini PORTB'den gönder.
		CALL	TIMA_B		; Gecikme alt programını çağır.
		
		BCF	PORTA,0		; CLOCK düşen kenar.
		BSF	PORTA,0		; CLOCK yükselen kenar.
		RETURN

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
TIMA_B	; PORTB'den LED'lere gönderilen bilgiyi gösterme süresi.                     ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;

		MOVLW	D'20'		; W'ye 20 yaz.
		MOVWF	TIMA		; TIMA register'a gönder.
PAUSE2		MOVLW	D'25'		; W'ye 25 yaz.
		MOVWF	TIMB		; TIMB register' gönder.
PAUSE1		DECFSZ	TIMB,F		; TIMB-1, 0'a ulaştı mı?
		GOTO	PAUSE1		; Hayır.
		DECFSZ	TIMA,F		; TIMA-1, 0'a ulaştı mı?
		GOTO	PAUSE2		; Hayır.
		RETURN			; Evet, alt programdan çık.

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
TIMER_HIGH	; Bu alt program yaklaşık 0.2 saniyelik bir gecikme sağlar.          ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
		
		MOVLW	D'255'		; W'ye 255 yaz.
		MOVWF	TIMER_H1	; TIMER_H1 register'a gönder.
		
DONGU1		MOVLW	D'255'		; W'ye 255 yaz.
		MOVWF	TIMER_H2	; TIMER_H2 register'a gönder.
		
DONGU2		DECFSZ	TIMER_H2,F	; TIMER_H2-1, 0 mı?
		GOTO	DONGU2		; Hayır.
		DECFSZ	TIMER_H1,F	; TIMER_H1-1, 0 mı?
		GOTO	DONGU1		; Hayır.
		RETURN			; Evet, alt programdan çık.










;××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××;
KLYOKU	; Klavyeden gönderilen seri bilgiyi, paralel veriye dönüştürür.              ;
;××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××;
		
		BCF	INTCON,GIE	; Tüm kesme işlemleri geçersiz.
		BCF	INTCON,RBIE	; PORTB'den gelecek kesmeler geçersiz.
		BCF	INTCON,RBIF	; PORTB kesme bayrağını sıfırla.

		MOVWF	W_TEMP		; W'yi W_TEMP'e gönder.
		SWAPF	STATUS,W	; Alt ve üst 4-bit'i takas et.
		MOVWF	STATUS_TEMP	; STATUS'ı STATUS_TEMP'e gönder.
		
;××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××;
		
		CLRF	PORTB		; PORTB'yi temizle.
		
BASLA		CLRF	VERI		; VERI'yi, yeni bilgi için temizle.
		CALL	KLY_KONTROL	; Bit1 : START bit, değerlendirilmeyecek.
		MOVLW	D'8'		; W'ye 8 yükle.
		MOVWF	BIT_N		; BIT_N register'a gönder.

BIT_KAYDIR	RRF	VERI,F		; VERI içindeki bilgiyi, 1-bit sağa ötele.
		CALL	KLY_KONTROL	; CLOCK ve DATA sinyallerini değerlendir.
		IORWF	VERI,F		; W ve VERI'ye OR işlevi uygula.
		IORLW	B'01111111'	; W ve B'01111111'ye OR işlevi uygula.
		ANDWF	VERI,F		; Maskele.
		DECFSZ	BIT_N,F		; BIT_N-1, 0 mı?
		GOTO	BIT_KAYDIR	; Hayır.
		CALL	KLY_KONTROL	; Bit10 : EŞLİK bit'i, değerlendirilmeyecek.
		CALL	KLY_KONTROL	; Bit11 : STOP bit'i, değerlendirilmeyecek.
		
		CALL	KLY_KONTROL	; Klavyeden...
		CALL	KLY_KONTROL	; ...parmağın...
		CALL	KLY_KONTROL	; ...kaldırılması...
		CALL	KLY_KONTROL	; ...sırasında...
		CALL	KLY_KONTROL	; ...oluşan...
		CALL	KLY_KONTROL	; ...ikinci...
		CALL	KLY_KONTROL	; ...interrrupt'ın...
		CALL	KLY_KONTROL	; ...önlenmesi.
		CALL	KLY_KONTROL	; Aksi halde...
		CALL	KLY_KONTROL	; ...her karakter...
		CALL	KLY_KONTROL	; ...çift olarak gözükecektir.
		
		GOTO	KLY_MAIN 	; Seri veri, paralel veriye dönüştürüldü.

KLY_KONTROL	BTFSC	PORTB,7		; CLOCK 0 mı?
		GOTO	$ - 1		; Hayır, 0 olmasını bekle.
		BTFSS	PORTB,7		; CLOCK, 1 mi?
		GOTO	$ - 1		; Hayır, 1 olmasını bekle.
		BTFSS	PORTA,4		; DATA 1 mi?
		RETLW	B'00000000'	; Hayır, 0 ile dön.
		RETLW	B'10000000'	; Evet,  1 ile dön.

;××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××;
KLY_MAIN	; Bu alt program, klavyeden gelen seri bilgiyi okur.                 ;
;××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××;

DELETE?		MOVF	VERI,W		; VERI'yi W'ye yaz.
		SUBLW	D'113'		; 113-VERI
		BTFSS	STATUS,Z	; DELETE tuşuna basıldı mı?
		GOTO	HATAKONTROL	; Hayır, devam et.
		MOVLW	H'00'		; W'ye 0 yaz.
		MOVWF	EEADR		; Adres bilgisi olarak EEADR'ye gönder.
		MOVWF	EEDATA		; Veri olarak EEDATA'ya gönder.
		CALL	EEYAZ		; 0. adrese 0 yaz. (Kayıt sayısını temizle.)
		CALL	SUTUN_TEMIZLE	; Sütun bilgisini temizle.
		CLRF	EEREAD_N	; Okunacak kayıt sayısı 0
		CLRF	EEWRITE_N	; EEPROM'a kayıt sayısı 0
		GOTO	KLYCIK		; Silme işlemi tamamlandı.

HATAKONTROL	MOVF	VERI,W		; VERI'yi W'ye yaz.
		SUBLW	B'11110000'	; HATAKODU-VERI
		BTFSC	STATUS,Z	; Klavye kodu hatasız mı?
		GOTO	KLYCIK		; Hatalı, alt programdan çık.
		
SKIP		MOVF	VERI,W		; VERI'yi W'ye yaz.
		ANDLW	B'01111111'	; 7. bit'i maskele.		
		MOVWF	VERI		; Maskelenen bilgiyi yeniden VERI'ye gönder.
		
VERI_KAYDET	MOVF	VERI,W		; VERI'yi W'ye yaz.
		MOVWF	EEDATA		; EEDATA'ya gönder.
		MOVF	EEWRITE_N,W	; EEWRITE_N'i W'ye yaz.
		MOVWF	EEADR		; EEADR'ye adres bilgisi olarak gönder.
		INCF	EEADR,F		; EEADR+1
		INCF	EEWRITE_N,F	; Yazılan kayıt sayısını 1 arttır.
		CALL	EEYAZ		; EEPROM'a yaz.		

KAYIT_SAYISI	MOVLW	0		; Kayıt sayısının tutulduğu adres.
KAYDET		MOVWF	EEADR		; EEPROM'un ilk adresi.
		MOVF	EEWRITE_N,W	; Kayıtlı bellek sayısını W'ye yaz.
		MOVWF	EEDATA		; EEDATA' ya gönder.
		CALL	EEYAZ		; VERI'yi EEPROM'a kaydet.
		
KLYCIK		SWAPF	STATUS_TEMP,W	; STATUS_TEMP'i W'ye yaz.
		MOVWF	STATUS		; STATUS'ı ilk konumuna getir.
		SWAPF	W_TEMP,F	; W_TEMP'e swap işlemi uygula.
		SWAPF	W_TEMP,W	; W'yi ilk konumuna getir.

		BCF	INTCON,RBIF	; PORTB kesme bayrağını sıfırla.
		BSF	INTCON,GIE	; Yeni kesmeler kabul edilir.
		BSF	INTCON,RBIE	; PORTB'den gelecek kesmeler geçerli.
		
		RETFIE			; Alt programından çık.

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
EEYAZ	; VERI'yi EEPROM'a kaydetme alt programı.                                    ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
		
		BSF	STATUS,RP0	; BANK1'e geç.
		BCF	INTCON,GIE	; GIE pasif.
		BSF	EECON1,WREN	; Yazma işlemine izin ver.
		MOVLW	H'55'		; EEPROM...
		MOVWF	EECON2		; ...için...
		MOVLW	H'AA'		; ...standard...
		MOVWF	EECON2		; ...işlemler.
		BSF	EECON1,WR	; Yazma işlemini başlat.
SIFIRDATUT	BTFSC	EECON1,WR	; Yazma işlemi bitti mi?
		GOTO	SIFIRDATUT	; Hayır, bekle.
		BSF	EECON1,WREN	; Evet, Write Enable'ı lojik "1" yap.
		BCF	EECON1,EEIF	; EEIF'i temizle.
		BCF	STATUS,RP0	; BANK0'a dön.
		RETURN

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
ANALIZ	; EEDATA register'ından alınan bilginin değerlendirilmesi.                   ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;

BIR_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'22'		; 22-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "1" mi?
		GOTO	IKI_1		; Hayır.
		MOVLW	D'3'		; W'ye 3 yaz.
		MOVWF	LINE		; LINE register'a gönder.
		MOVLW	D'3'		; Sütun sayısını W'ye yaz.
		MOVWF	CHAR_SUTUN	; CHAR_SUTUN register'a gönder.
BIR_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	BIR_2		; Hayır, diğer sütunları oku.
		RETURN

IKI_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'30'		; 30-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "2" mi?
		GOTO	UC_1		; Hayır.
		MOVLW	D'8'		; W'ye 8 yaz.
		CALL	COMMON1		; Ortak işlemler1.
IKI_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	IKI_2		; Hayır, diğer sütunları oku.
		RETURN
		
UC_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'38'		; 38-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "3" mü?
		GOTO	DORT_1		; Hayır.
		MOVLW	D'13'		; W'ye 13 yaz.
		CALL	COMMON1		; Ortak işlemler1.
UC_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	UC_2		; Hayır, diğer sütunları oku.
		RETURN
		
DORT_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'37'		; 37-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "4" mü?
		GOTO	BES_1		; Hayır.
		MOVLW	D'18'		; W'ye 18 yaz.
		CALL	COMMON1		; Ortak işlemler1.
DORT_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	DORT_2		; Hayır, diğer sütunları oku.
		RETURN
		
BES_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'46'		; 46-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "5" mi?
		GOTO	ALTI_1		; Hayır.
		MOVLW	D'23'		; W'ye 23 yaz.
		CALL	COMMON1		; Ortak işlemler1.
BES_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	BES_2		; Hayır, diğer sütunları oku.
		RETURN
		
ALTI_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'54'		; 54-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "6" mı?
		GOTO	YEDI_1		; Hayır.
		MOVLW	D'28'		; W'ye 28 yaz.
		CALL	COMMON1		; Ortak işlemler1.
ALTI_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	ALTI_2		; Hayır, diğer sütunları oku.
		RETURN
		
YEDI_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'61'		; 61-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "7" mi?
		GOTO	SEKIZ_1		; Hayır.
		MOVLW	D'33'		; W'ye 33 yaz.
		CALL	COMMON1		; Ortak işlemler1.
YEDI_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	YEDI_2		; Hayır, diğer sütunları oku.
		RETURN
		
SEKIZ_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'62'		; 32-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "8" mi?
		GOTO	DOKUZ_1		; Hayır.
		MOVLW	D'38'		; W'ye 38 yaz.
		CALL	COMMON1		; Ortak işlemler1.
SEKIZ_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	SEKIZ_2		; Hayır, diğer sütunları oku.
		RETURN
		
DOKUZ_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'70'		; 70-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "9" mu?
		GOTO	SIFIR_1		; Hayır.
		MOVLW	D'43'		; W'ye 43 yaz.
		CALL	COMMON1		; Ortak işlemler1.
DOKUZ_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	DOKUZ_2		; Hayır, diğer sütunları oku.
		RETURN
		
SIFIR_1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'69'		; 69-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "0" mı?
		GOTO	A1		; Hayır.
		MOVLW	D'48'		; W'ye 48 yaz.
		CALL	COMMON1		; Ortak işlemler1.
SIFIR_2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	SIFIR_2		; Hayır, diğer sütunları oku.
		RETURN

A1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'28'		; 28-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "A" mı?
		GOTO	B1		; Hayır.
		MOVLW	D'53'		; W'ye 53 yaz.
		CALL	COMMON1		; Ortak işlemler1.
A2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	A2		; Hayır, diğer sütunları oku.
		RETURN
		
B1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'50'		; 50-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "B" mi?
		GOTO	C1		; Hayır.
		MOVLW	D'58'		; W'ye 58 yaz.
		CALL	COMMON1		; Ortak işlemler1.
B2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	B2		; Hayır, diğer sütunları gönder.
		RETURN

C1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'33'		; 33-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "C" mi?
		GOTO	D1		; Hayır.
		MOVLW	D'63'		; W'ye 63 yaz.
		CALL	COMMON1		; Ortak işlemler1.
C2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	C2		; Hayır, diğer sütunları gönder.
		RETURN

D1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'35'		; 35-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "D" mi?
		GOTO	E1		; Hayır.
		MOVLW	D'68'		; W'ye 73 yaz.
		CALL	COMMON1		; Ortak işlemler1.
D2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	D2		; Hayır, diğer sütunları gönder.
		RETURN
		
E1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'36'		; 36-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "E" mi?
		GOTO	F1		; Hayır.
		MOVLW	D'72'		; W'ye 77 yaz.
		CALL	COMMON4		; Ortak işlemler4.
E2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	E2		; Hayır, diğer sütunları gönder.
		RETURN

F1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'43'		; 43-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "F" mi?
		GOTO	G1		; Hayır.
		MOVLW	D'76'		; W'ye 81 yaz.
		CALL	COMMON4		; Ortak işlemler4.
F2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	F2		; Hayır, diğer sütunları oku.
		RETURN

G1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'52'		; 52-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "G" mi?
		GOTO	H1		; Hayır.
		MOVLW	D'81'		; W'ye 86 yaz.
		CALL	COMMON1		; Ortak işlemler1.
G2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	G2		; Hayır, diğer sütunları oku.
		RETURN

H1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'51'		; 51-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "H" mi?
		GOTO	I1		; Hayır.
		MOVLW	D'86'		; W'ye 96 yaz.
		CALL	COMMON1		; Ortak işlemler1.
H2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	H2		; Hayır, diğer sütunları oku.
		RETURN

I1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'67'		; 67-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "I mı?
		GOTO	J1		; Hayır.
		MOVLW	D'87'		; W'ye 97 yaz.
		MOVWF	LINE		; LINE register'a gönder.
		MOVLW	D'1'		; I'nın sütun sayısını W'ye yaz.
		MOVWF	CHAR_SUTUN	; CHAR_SUTUN register'a gönder.
I2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	I2		; Hayır, diğer sütunları gönder.
		RETURN

J1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'59'		; 59-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "J mi?
		GOTO	K1		; Hayır.
		MOVLW	D'91'		; W'ye 102 yaz.
		CALL	COMMON4		; Ortak işlemler4.
J2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	J2		; Hayır, diğer sütunları gönder.
		RETURN

K1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'66'		; 66-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "K" mı?
		GOTO	L1		; Hayır.
		MOVLW	D'96'		; W'ye 107 yaz.
		CALL	COMMON1		; Ortak işlemler1.
K2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	K2		; Hayır, diğer sütunları gönder.
		RETURN

L1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'75'		; 75-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "L" mi?
		GOTO	M1		; Hayır.
		MOVLW	D'100'		; W'ye 111 yaz.
		CALL	COMMON4		; Ortak işlemler4.
L2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	L2		; Hayır, diğer sütunları gönder.
		RETURN

M1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'58'		; 58-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "M" mi?
		GOTO	N1		; Hayır.
		MOVLW	D'107'		; W'ye 118 yaz.
		MOVWF	LINE		; LINE register'a gönder.
		MOVLW	D'7'		; M'nin sütun sayısını W'ye yaz.
		MOVWF	CHAR_SUTUN	; CHAR_SUTUN register'a gönder.
M2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	M2		; Hayır, diğer sütunları gönder.
		RETURN

N1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'49'		; 49-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "M" mi?
		GOTO	O1		; Hayır.
		MOVLW	D'112'		; W'ye 123 yaz.
		CALL	COMMON1		; Ortak işlemler1.
N2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	N2		; Hayır, diğer sütunları gönder.
		RETURN

O1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'68'		; 68-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "O" mu?
		GOTO	P1		; Hayır.
		MOVLW	D'117'		; W'ye 128 yaz.
		CALL	COMMON1		; Ortak işlemler1.
O2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	O2		; Hayır, diğer sütunları gönder.
		RETURN

P1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'77'		; 77-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "P" mi?
		GOTO	Q1		; Hayır.
		MOVLW	D'122'		; W'ye 138 yaz.
		CALL	COMMON1		; Ortak işlemler1.
P2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	P2		; Hayır, diğer sütunları gönder.
		RETURN
		
Q1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'21'		; 21-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "Q" mu?
		GOTO	R1		; Hayır.
		MOVLW	D'127'		; W'ye 143 yaz.
		CALL	COMMON1		; Ortak işlemler1.
Q2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	Q2		; Hayır, diğer sütunları oku.
		RETURN

R1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'45'		; 45-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "R" mi?
		GOTO	S1		; Hayır.
		MOVLW	D'132'		; W'ye 148 yaz.
		CALL	COMMON1		; Ortak işlemler1.
R2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	R2		; Hayır, diğer sütunları gönder.
		RETURN

S1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'27'		; 27-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "S" mi?
		GOTO	T1		; Hayır.
		MOVLW	D'137'		; W'ye 153 yaz.
		CALL	COMMON1		; Ortak işlemler1.
S2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	S2		; Hayır, diğer sütunları gönder.
		RETURN

T1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'44'		; 44-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "T" mi?
		GOTO	U1		; Hayır.
		MOVLW	D'142'		; W'ye 163 yaz.
		CALL	COMMON1		; Ortak işlemler1.
T2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	T2		; Hayır, diğer sütunları gönder.
		RETURN

U1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'60'		; 60-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "U" mu?
		GOTO	V1		; Hayır.
		MOVLW	D'147'		; W'ye 168 yaz.
		CALL	COMMON1		; Ortak işlemler1.
U2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	U2		; Hayır, diğer sütunları gönder.
		RETURN

V1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'42'		; 42-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "V" mi?
		GOTO	W1		; Hayır.
		MOVLW	D'152'		; W'ye 178 yaz.
		CALL	COMMON1		; Ortak işlemler1.
V2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	V2		; Hayır, diğer sütunları gönder.
		RETURN
		
W1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'29'		; 29-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "W" mu?
		GOTO	X1		; Hayır.
		MOVLW	D'159'		; W'ye 185 yaz.
		MOVWF	LINE		; LINE register'a gönder.
		MOVLW	D'7'		; Sütun sayısını W'ye yaz.
		MOVWF	CHAR_SUTUN	; CHAR_SUTUN register'a gönder.
W2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	W2		; Hayır, diğer sütunları oku.
		RETURN
		
X1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'34'		; 34-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "X" mi?
		GOTO	Y1		; Hayır.
		MOVLW	D'164'		; W'ye 190 yaz.
		CALL	COMMON1		; Ortak işlemler1.
X2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	X2		; Hayır, diğer sütunları oku.
		RETURN

Y1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'53'		; 53-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "Y" mi?
		GOTO	Z1		; Hayır.
		MOVLW	D'169'		; W'ye 195 yaz.
		CALL	COMMON1		; Ortak işlemler1.
Y2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	Y2		; Hayır, diğer sütunları gönder.
		RETURN

Z1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'26'		; 67-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "Z" mi?
		GOTO	NOKTA1		; Hayır.
		MOVLW	D'174'		; W'ye 200 yaz.
		CALL	COMMON1		; Ortak işlemler1.
Z2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	Z2		; Hayır, diğer sütunları gönder.
		RETURN

NOKTA1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'74'		; 74-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "NOKTA" mı?
		GOTO	BOSLUK1		; Hayır.
		MOVLW	D'175'		; W'ye 201 yaz.
		MOVWF	LINE		; LINE register'a gönder.
		MOVLW	D'1'		; NOKTA'nın sütun sayısını W'ye yaz.
		MOVWF	CHAR_SUTUN	; CHAR_SUTUN register'a gönder.
NOKTA2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	NOKTA2		; Hayır, diğer sütunları gönder.
		RETURN
		
BOSLUK1		MOVF	VERI,W		; Karakter'e ait kodu W'ye yaz.
		SUBLW	D'41'		; 41-EEDATA
		BTFSS	STATUS,Z	; Basılan tuş "SPACE" mi?
		RETURN			; Hayır.
CUMLE_SONU	MOVLW	D'178'		; W'ye 204 yaz.
		MOVWF	LINE		; LINE register'a gönder.
		MOVLW	D'3'		; BOSLUK'un sütun sayısını W'ye yaz.
		MOVWF	CHAR_SUTUN	; CHAR_SUTUN register'a gönder.
BOSLUK2		MOVLW	B'00000011'	; W'ye 3 yaz.
		CALL	COMMON2		; Ortak işlemler2.
		DECFSZ	CHAR_SUTUN,F	; Karakterin sütun sayısı-1, 0 mı?
		GOTO	BOSLUK2		; Hayır, diğer sütunları gönder.
		RETURN

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
; Karakterlerle ilgili yapılacak ortak işlemler, bu alt programda toplandı.	     ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;

COMMON1		MOVWF	LINE		; LINE register'a gönder.
		MOVLW	D'5'		; Sütun sayısını W'ye yaz.
		MOVWF	CHAR_SUTUN	; CHAR_SUTUN register'a gönder.
		RETURN

COMMON2		MOVWF	PCLATH		; Tabloya ulaşmak için üst bayt olarak yaz.
		MOVF	LINE,W		; Line'ı W'ye yaz.
		CALL	TABLE		; Çevrim tablosunu çağır.
		CLRF	PCLATH		; Üst bayt'ı sıfırla.
		MOVWF	SUTUN1		; Tablo bilgisini SUTUN'a gönder.
		CALL	GOSTER		; Sütun bilgisini LED göstergeye aktar.
		CALL	SHIFT		; Sütunları 1 adım sola ötele.
		DECF	LINE,F		; LINE-1
		RETURN

COMMON4		MOVWF	LINE		; LINE register'a gönder.
		MOVLW	D'4'		; Sütun sayısını W'ye yaz.
		MOVWF	CHAR_SUTUN	; CHAR_SUTUN register'a gönder.
		RETURN

;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;
TABLE	; Klavyeden basılan her tuş KLYOKU alt programında 8-bit'lik paralel KOD'a   ;
	; dönüştürülür. Her karakterin sütun sayısı farklı olduğundan, karakterin    ;
	; sütun özellikleri aşağıda yer alan TABLE adlı alt programa yerleştirildi.  ;
	; Örneğin "I" karakterini oluşturmak için, 3 kez çevrim tablosundan okuma    ;
	; yapılır. "W" ya da "M" karakterini oluşturmak için ise 7 kez.              ;
;«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»;

	ADDWF	PCL,F	; Program sayıcı+Tabloda ulaşılacak satır.

	RETLW	H'00'	; 0
_1	RETLW	H'7F'	; 1
	RETLW	H'20'	; 2
	RETLW	H'10'	; 3

_2	RETLW	H'31'	; 4
	RETLW	H'49'	; 5
	RETLW	H'49'	; 6
	RETLW	H'49'	; 7
	RETLW	H'27'	; 8

_3	RETLW	H'36'	; 9
	RETLW	H'49'	; 10
	RETLW	H'49'	; 11
	RETLW	H'41'	; 12
	RETLW	H'22'	; 13

_4	RETLW	H'04'	; 14
	RETLW	H'7F'	; 15
	RETLW	H'24'	; 16
	RETLW	H'14'	; 17
	RETLW	H'0C'	; 18

_5	RETLW	H'46'	; 19
	RETLW	H'49'	; 20
	RETLW	H'49'	; 21
	RETLW	H'49'	; 22
	RETLW	H'7A'	; 23

_6	RETLW	H'26'	; 24
	RETLW	H'49'	; 25
	RETLW	H'49'	; 26
	RETLW	H'49'	; 27
	RETLW	H'3E'	; 28

_7	RETLW	H'60'	; 29
	RETLW	H'50'	; 30
	RETLW	H'48'	; 31
	RETLW	H'47'	; 32
	RETLW	H'40'	; 33

_8	RETLW	H'36'	; 34
	RETLW	H'49'	; 35
	RETLW	H'49'	; 36
	RETLW	H'49'	; 37
	RETLW	H'36'	; 38

_9	RETLW	H'3E'	; 39
	RETLW	H'49'	; 40
	RETLW	H'49'	; 41
	RETLW	H'49'	; 42
	RETLW	H'32'	; 43

_0	RETLW	H'3E'	; 44
	RETLW	H'41'	; 45
	RETLW	H'41'	; 46
	RETLW	H'41'	; 47
	RETLW	H'3E'	; 48

_A	RETLW	H'3F'	; 49
	RETLW	H'48'	; 50
	RETLW	H'48'	; 51
	RETLW	H'48'	; 52
	RETLW	H'3F'	; 53

_B	RETLW	H'36'	; 54
	RETLW	H'49'	; 55
	RETLW	H'49'	; 56
	RETLW	H'49'	; 57
	RETLW	H'7F'	; 58

_C	RETLW	H'22'	; 59
	RETLW	H'41'	; 60
	RETLW	H'41'	; 61
	RETLW	H'41'	; 62
	RETLW	H'3E'	; 63

_D	RETLW	H'3E'	; 64
	RETLW	H'41'	; 65
	RETLW	H'41'	; 66
	RETLW	H'41'	; 67
	RETLW	H'7F'	; 68

_E	RETLW	H'41'	; 69
	RETLW	H'49'	; 70
	RETLW	H'49'	; 71
	RETLW	H'7F'	; 72

_F	RETLW	H'40'	; 73
	RETLW	H'48'	; 74
	RETLW	H'48'	; 75
	RETLW	H'7F'	; 76
	
_G	RETLW	H'2E'	; 77
	RETLW	H'49'	; 78
	RETLW	H'49'	; 79
	RETLW	H'41'	; 80
	RETLW	H'3E'	; 81

_H	RETLW	H'7F'	; 82
	RETLW	H'08'	; 83
	RETLW	H'08'	; 84
	RETLW	H'08'	; 85
	RETLW	H'7F'	; 86

_I	RETLW	H'7F'	; 87

_J	RETLW	H'7E'	; 88
	RETLW	H'01'	; 89
	RETLW	H'01'	; 90
	RETLW	H'02'	; 91

_K	RETLW	H'43'	; 92
	RETLW	H'24'	; 93
	RETLW	H'18'	; 94
	RETLW	H'08'	; 95
	RETLW	H'7F'	; 96

_L	RETLW	H'01'	; 97
	RETLW	H'01'	; 98
	RETLW	H'01'	; 99
	RETLW	H'7F'	; 100

_M	RETLW	H'3F'	; 101
	RETLW	H'40'	; 102
	RETLW	H'40'	; 103
	RETLW	H'3F'	; 104
	RETLW	H'40'	; 105
	RETLW	H'40'	; 106
	RETLW	H'3F'	; 107

_N	RETLW	H'7F'	; 108
	RETLW	H'02'	; 109
	RETLW	H'1C'	; 110
	RETLW	H'20'	; 111
	RETLW	H'7F'	; 112

_O	RETLW	H'3E'	; 113
	RETLW	H'41'	; 114
	RETLW	H'41'	; 115
	RETLW	H'41'	; 116
	RETLW	H'3E'	; 117

_P	RETLW	H'30'	; 118
	RETLW	H'48'	; 119
	RETLW	H'48'	; 120
	RETLW	H'48'	; 121
	RETLW	H'3F'	; 122

_Q	RETLW	H'3F'	; 123
	RETLW	H'43'	; 124
	RETLW	H'45'	; 125
	RETLW	H'41'	; 126
	RETLW	H'3E'	; 127

_R	RETLW	H'31'	; 128
	RETLW	H'4A'	; 129
	RETLW	H'4C'	; 130
	RETLW	H'48'	; 131
	RETLW	H'7F'	; 132

_S	RETLW	H'26'	; 133
	RETLW	H'49'	; 134
	RETLW	H'49'	; 135
	RETLW	H'49'	; 136
	RETLW	H'32'	; 137

_T	RETLW	H'40'	; 138
	RETLW	H'40'	; 139
	RETLW	H'7F'	; 140
	RETLW	H'40'	; 141
	RETLW	H'40'	; 142

_U	RETLW	H'7E'	; 143
	RETLW	H'01'	; 144
	RETLW	H'01'	; 145
	RETLW	H'01'	; 146
	RETLW	H'7E'	; 147

_V	RETLW	H'78'	; 148
	RETLW	H'06'	; 149
	RETLW	H'01'	; 150
	RETLW	H'06'	; 151
	RETLW	H'78'	; 152

_W	RETLW	H'7E'	; 153
	RETLW	H'01'	; 154
	RETLW	H'01'	; 155
	RETLW	H'7E'	; 156
	RETLW	H'01'	; 157
	RETLW	H'01'	; 158
	RETLW	H'7E'	; 159

_X	RETLW	H'41'	; 160
	RETLW	H'22'	; 161
	RETLW	H'1C'	; 162
	RETLW	H'22'	; 163
	RETLW	H'41'	; 164

_Y	RETLW	H'40'	; 165
	RETLW	H'20'	; 166
	RETLW	H'1F'	; 167
	RETLW	H'20'	; 168
	RETLW	H'40'	; 169

_Z	RETLW	H'61'	; 170
	RETLW	H'51'	; 171
	RETLW	H'49'	; 172
	RETLW	H'45'	; 173
	RETLW	H'43'	; 174

_NOKTA	RETLW	H'01'	; 175

_BOSLUK	RETLW	H'00'	; 176
	RETLW	H'00'	; 177
	RETLW	H'00'	; 178

;------------------------------------------------------------------------------------;
		END