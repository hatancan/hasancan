
	LIST p=16F84A; Kullanılacak PIC'in tanımlanması
	INCLUDE "P16F84A.INC"; Kullanılan PIC’teki yazmaç tanımlamaları bu dosyada saklanır. 
	;Böylece yazmaç değerlerinin teker teker tanımlanması gerekmez.

	__CONFIG _CP_OFF &_WDT_OFF &_PWRTE_ON &_XT_OSC; Konfigürasyon bitlerinin ayarlanması
	;	Kod koruma yok & watch dog timer kapalı& power on reset açık & kristal osilatör

	ORG     0x00; Programı 0x00'dan başlat
	
	CLRF PORTB; PortB'ye bağlı pinleri sıfırla
	BSF STATUS,5; Bank1'e geç
	MOVLW 0x00; 00h değerini
	MOVWF TRISB; TrisB yazmacına ata. B portunun tüm pinleri çıkış olarak atanmış olur.
	MOVLW 0x01; 01 değerini
	MOVWF TRISA; TrisB yazmacına ata. A portunun ilk pini (RA0) giriş olarak atanmış olur.
	BCF STATUS,5; Bank0'a geç
	
LEDcntrl:
	BTFSS PORTA,0; PortA'nın sıfırıncı bitinin (RA0 pini) 1 olup olmadığını kontrol et.
	GOTO TURN_ON; 1 ise TURN_ON etiketli yere git.
 
	BCF PORTB,0; RA0 pini 1 değilse PortB'nin 0. bitini (RB0 pini) 0 yap.
	GOTO LEDcntrl; LEDcntrl etiketli yere git. 
	
TURN_ON
	BSF PORTB,0; PortB'nin 0. bitini (RB0 pini) 1 yap.
	GOTO LEDcntrl; LEDcntrl etiketli yere git. 
	
End; Programı bitir.	