#include <iostream>
#include <iomanip>
#include <vector>


using namespace std;

template <typename T>
void PrintVector(vector<T>& Ref)
{
      for(int i=0; i<Ref.size(); i++)
       cout<<Ref[i]<<" ";                  
      cout<<endl;
}

template <typename T>
bool BosmuDolumu(vector<T>& Ref)
{
  if(Ref.empty()==0)
   return true;
  else
   return false;
}

template <typename T>
void Ekle(vector<T>& Ref,T value)
{
  Ref.push_back(value);
}

/*
template <typename T>
T Cikart(vector<T>& Ref)
{
  T x;
  x=Ref.pop_back();
  return x;
}

*/

int main()
{

int a[5]={1,3,5,7,9};
double b[5]={2.2,4.4,6.6,8.8,10.10};

int sizea=sizeof(a)/sizeof(int);
int sizeb=sizeof(b)/sizeof(double);

vector<int> VecA(a,a+sizea);
vector<double> VecB(b,b+sizeb);


PrintVector(VecA);
PrintVector(VecB);

cout<<"Back of A : "<< VecA.back()<<endl;
cout<<"Back of B : "<< VecB.back()<<endl;

cout<<" Empty ? :"<< BosmuDolumu(VecA)<<endl;
cout<<" Empty ? :"<< BosmuDolumu(VecB)<<endl;

VecA.resize(10,0);
PrintVector(VecA);


VecB.resize(4,0);
PrintVector(VecB);

Ekle(VecA,5);
PrintVector(VecA);

Ekle(VecB,7.7);
PrintVector(VecB);


cout<<"\n";
system("pause");
return 0;
}
/*
1 3 5 7 9
2.2 4.4 6.6 8.8 10.1
Back of A : 9
Back of B : 10.1
 Empty ? :1
 Empty ? :1
1 3 5 7 9 0 0 0 0 0
2.2 4.4 6.6 8.8
1 3 5 7 9 0 0 0 0 0 5
2.2 4.4 6.6 8.8 7.7

Press any key to continue . . .
*/
