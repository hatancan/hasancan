/*
Klavyeden girilen herhangi tipte bir bilgiyi depolay�p, bu bilgiyi ekranda
tekrar bast�rabilen bir �ablon s�n�f� tasarlay�n�z.

Bu s�n�f i�in klavyeden bilgi alma ve ekrana yazd�rma i�leminde 
kullan�lmak �zere kullan�lacak olan >> ve << operat�rlerine a��r� y�kleme 
uygulay�n�z.

Klavyeden girilen farkl� tipteki bilgiler i�in s�n�f�n�z�n �al��t���n� g�steren
ana program� kodlay�n�z. (int,float,double,char,string)

*/

#include <iostream>
#include <iomanip>
using namespace std;

template <typename T>
class Bilgi
{
 friend ostream &operator<<( ostream &, Bilgi<T> & obje);
 friend istream &operator>>( ostream &, Bilgi<T> & obje);
 
  public :  

   friend ostream &operator<<( ostream & yaz, Bilgi<T> & obje)
     { yaz<<"Girilen Bilgi :"<< obje.data<<endl;
       return yaz;}

   friend istream &operator>>( istream & al, Bilgi<T> & obje)
     { al>>obje.data;
       return al;}

  private :
          T data; 
};

int main()
{

cout<<"String :";
Bilgi<string> Nesne1;
cin>>Nesne1;
cout<<Nesne1;

    
cout<<"Char : ";
Bilgi<char> Nesne2;
cin>>Nesne2;
cout<<Nesne2;

cout<<"int :";
Bilgi<int> Nesne3;
cin>>Nesne3;
cout<<Nesne3;

    
cout<<"float : ";
Bilgi<float> Nesne4;
cin>>Nesne4;
cout<<Nesne4;


system("pause");
return 0;
}
/*
String :Merhaba
Girilen Bilgi :Merhaba
Char : W
Girilen Bilgi :W
int :56
Girilen Bilgi :56
float : 34.67
Girilen Bilgi :34.67
Press any key to continue . . .
*/
