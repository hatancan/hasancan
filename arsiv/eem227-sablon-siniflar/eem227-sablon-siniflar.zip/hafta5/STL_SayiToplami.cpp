/*
Farkl� tipteki say�lar�n toplam�n� yapabilen ve sonucu a��r�
y�klenmi� << operat�r� sayesinde bast�rabilen bir �ablon s�n�f yaz�n�z.
*/

#include <iostream>
#include <iomanip>
using namespace std;

template <typename T>
class Sayi
{

 friend ostream &operator<<( ostream &, Sayi<T> & obje); 
 
  public :  
     
         Sayi(T a,T b) // Constructorda inline olarak bildirdik
         { 
           data1 = a;
           data2 = b;
         };
  /* �ablon s�n�f�nda a��r� y�kledi�imiz << operat�r�n� inline olarak s�n�f ADT
     si i�erisinde bildirdik...
  */
 friend ostream &operator<<( ostream & yaz, Sayi<T> & obje)
     { yaz<<"Toplam Sonucu :"<< obje.data1 + obje.data2<<endl;
       return yaz;}

  private :
          T data1;
          T data2; 
          
};

int main()
{

Sayi<int> Sayi1(3,5); // Dikkat !!! T�r yaz�lmal�d�r...
cout<<"Tamsayi "<<Sayi1;

Sayi<float> Sayi2(1.3,5.8); // T�r yaz�lmal�d�r...
cout<<"Float "<<Sayi2;

Sayi<double> Sayi3(45.343,62346.83); // T�r yaz�lmal�d�r...
cout<<"Double "<<Sayi3;

system("pause");
return 0;
}
/*
Tamsayi Toplam Sonucu :8
Float Toplam Sonucu :7.1
Double Toplam Sonucu :62392.2
Press any key to continue . . .
*/
