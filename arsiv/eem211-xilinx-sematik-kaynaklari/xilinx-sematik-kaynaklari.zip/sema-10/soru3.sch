VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL XLXN_16
        SIGNAL XLXN_23(3:0)
        SIGNAL XLXN_24(3:0)
        SIGNAL XLXN_29
        SIGNAL mclk
        SIGNAL SS(7:0)
        SIGNAL AN(3:0)
        SIGNAL XLXN_25
        SIGNAL XLXN_39(7:0)
        SIGNAL XLXN_40
        SIGNAL XLXN_41
        SIGNAL BTN0
        PORT Input mclk
        PORT Output SS(7:0)
        PORT Output AN(3:0)
        PORT Input BTN0
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2006 7 31 23 58 46
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2001 2 2 12 53 1
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2001 2 2 12 51 49
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF pulldown
            TIMESTAMP 2002 3 20 16 43 42
            LINE N 64 -160 64 -128 
            LINE N 68 0 60 0 
            LINE N 76 -16 52 -16 
            LINE N 88 -32 40 -32 
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
        END BLOCKDEF
        BEGIN BLOCK XLXI_13 SSdriver
            PIN mclk mclk
            PIN S1(3:0) XLXN_23(3:0)
            PIN S2(3:0) XLXN_24(3:0)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0) SS(7:0)
            PIN AN(3:0) AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_9 pullup
            PIN O XLXN_29
        END BLOCK
        BEGIN BLOCK XLXI_16 cb8ce
            PIN C XLXN_25
            PIN CE XLXN_29
            PIN CLR XLXN_41
            PIN CEO
            PIN Q(7:0) XLXN_39(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_7 pulldown
            PIN O XLXN_41
        END BLOCK
        BEGIN BLOCK XLXI_18 ibuf
            PIN I BTN0
            PIN O XLXN_25
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN INSTANCE XLXI_13 2288 1072 R0
        END INSTANCE
        BUSTAP 2128 848 2224 848
        BUSTAP 2128 912 2224 912
        BEGIN BRANCH XLXN_23(3:0)
            WIRE 2224 848 2288 848
        END BRANCH
        BEGIN BRANCH XLXN_24(3:0)
            WIRE 2224 912 2288 912
        END BRANCH
        INSTANCE XLXI_9 1056 752 R0
        BEGIN BRANCH XLXN_29
            WIRE 1120 752 1120 912
            WIRE 1120 912 1296 912
        END BRANCH
        BEGIN BRANCH mclk
            WIRE 1840 672 2288 672
            WIRE 2288 672 2288 784
        END BRANCH
        BEGIN BRANCH SS(7:0)
            WIRE 2672 784 2768 784
        END BRANCH
        BEGIN BRANCH AN(3:0)
            WIRE 2672 1040 2768 1040
        END BRANCH
        INSTANCE XLXI_16 1296 1104 R0
        BEGIN BRANCH XLXN_25
            WIRE 1152 976 1200 976
            WIRE 1200 976 1296 976
        END BRANCH
        IOMARKER 1840 672 mclk R180 28
        IOMARKER 2768 784 SS(7:0) R0 28
        IOMARKER 2768 1040 AN(3:0) R0 28
        BEGIN BRANCH XLXN_39(7:0)
            WIRE 1680 848 2000 848
            WIRE 2000 848 2128 848
            WIRE 2000 848 2000 912
            WIRE 2000 912 2128 912
        END BRANCH
        INSTANCE XLXI_7 1216 1408 R0
        BEGIN BRANCH XLXN_41
            WIRE 1280 1072 1296 1072
            WIRE 1280 1072 1280 1248
        END BRANCH
        INSTANCE XLXI_18 928 1008 R0
        BEGIN BRANCH BTN0
            WIRE 832 976 880 976
            WIRE 880 976 928 976
        END BRANCH
        IOMARKER 832 976 BTN0 R180 28
    END SHEET
END SCHEMATIC
