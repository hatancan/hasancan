VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL Q(7:0)
        SIGNAL Q(3:0)
        SIGNAL Q(7:4)
        SIGNAL Q(1)
        SIGNAL Q(3)
        SIGNAL XLXN_9
        SIGNAL XLXN_10
        SIGNAL BTN0
        SIGNAL mclk
        SIGNAL SS(7:0)
        SIGNAL AN(3:0)
        SIGNAL XLXN_12(7:0)
        SIGNAL XLXN_13
        SIGNAL XLXN_14(3:0)
        SIGNAL XLXN_15(3:0)
        SIGNAL XLXN_16
        SIGNAL XLXN_17
        PORT Input BTN0
        PORT Input mclk
        PORT Output SS(7:0)
        PORT Output AN(3:0)
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2007 12 10 16 38 8
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2001 2 2 12 51 49
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2001 2 2 12 53 1
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 SSdriver
            PIN mclk mclk
            PIN S1(3:0) Q(3:0)
            PIN S2(3:0) Q(7:4)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0) SS(7:0)
            PIN AN(3:0) AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_2 cb8ce
            PIN C XLXN_1
            PIN CE XLXN_10
            PIN CLR XLXN_9
            PIN CEO
            PIN Q(7:0) Q(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_3 pullup
            PIN O XLXN_10
        END BLOCK
        BEGIN BLOCK XLXI_4 ibuf
            PIN I BTN0
            PIN O XLXN_1
        END BLOCK
        BEGIN BLOCK XLXI_5 and2
            PIN I0 Q(3)
            PIN I1 Q(1)
            PIN O XLXN_9
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_3 320 1216 R0
        INSTANCE XLXI_4 208 1360 R0
        BUSTAP 1072 1200 1168 1200
        BUSTAP 1072 1264 1168 1264
        BUSTAP 896 1536 800 1536
        BUSTAP 896 1600 800 1600
        BEGIN BRANCH Q(7:0)
            WIRE 896 1536 912 1536
            WIRE 912 1536 912 1600
            WIRE 896 1600 912 1600
            WIRE 912 1184 912 1536
            WIRE 912 1184 1040 1184
            WIRE 1040 1184 1040 1200
            WIRE 1040 1200 1072 1200
            WIRE 1040 1200 1040 1264
            WIRE 1040 1264 1072 1264
            WIRE 1024 1200 1024 1248
            WIRE 1024 1248 1056 1248
            WIRE 1024 1200 1040 1200
            WIRE 1040 944 1056 944
            WIRE 1056 944 1056 1248
        END BRANCH
        BEGIN BRANCH Q(3:0)
            WIRE 1168 1200 1184 1200
            WIRE 1184 1200 1184 1232
            WIRE 1184 1232 1664 1232
        END BRANCH
        BEGIN BRANCH Q(7:4)
            WIRE 1168 1264 1184 1264
            WIRE 1184 1264 1184 1296
            WIRE 1184 1296 1664 1296
        END BRANCH
        BEGIN BRANCH Q(1)
            WIRE 784 1456 784 1536
            WIRE 784 1536 800 1536
            WIRE 784 1456 1104 1456
            WIRE 1104 1456 1104 1856
            WIRE 1040 1856 1104 1856
        END BRANCH
        BEGIN BRANCH Q(3)
            WIRE 784 1568 784 1600
            WIRE 784 1600 800 1600
            WIRE 784 1568 1088 1568
            WIRE 1088 1568 1088 1920
            WIRE 1040 1920 1088 1920
        END BRANCH
        BEGIN BRANCH XLXN_9
            WIRE 656 1168 656 1888
            WIRE 656 1888 784 1888
        END BRANCH
        BEGIN BRANCH XLXN_10
            WIRE 384 1216 384 1232
            WIRE 384 1232 512 1232
            WIRE 512 1008 512 1232
            WIRE 512 1008 656 1008
        END BRANCH
        BEGIN BRANCH BTN0
            WIRE 176 1328 208 1328
        END BRANCH
        IOMARKER 176 1328 BTN0 R180 28
        BEGIN BRANCH mclk
            WIRE 1168 1136 1184 1136
            WIRE 1184 1136 1184 1168
            WIRE 1184 1168 1664 1168
        END BRANCH
        IOMARKER 1168 1136 mclk R180 28
        BEGIN BRANCH SS(7:0)
            WIRE 1600 1040 1600 1136
            WIRE 1600 1136 1616 1136
            WIRE 1600 1040 2112 1040
            WIRE 2112 1040 2112 1168
            WIRE 2048 1168 2112 1168
        END BRANCH
        IOMARKER 1616 1136 SS(7:0) R0 28
        BEGIN BRANCH AN(3:0)
            WIRE 1600 1392 1616 1392
            WIRE 1600 1392 1600 1520
            WIRE 1600 1520 2128 1520
            WIRE 2048 1424 2128 1424
            WIRE 2128 1424 2128 1520
        END BRANCH
        IOMARKER 1616 1392 AN(3:0) R0 28
        INSTANCE XLXI_2 656 1200 R0
        BEGIN BRANCH XLXN_1
            WIRE 432 1328 448 1328
            WIRE 448 1072 656 1072
            WIRE 448 1072 448 1328
        END BRANCH
        BEGIN INSTANCE XLXI_1 1664 1456 R0
        END INSTANCE
        INSTANCE XLXI_5 1040 1984 M0
    END SHEET
END SCHEMATIC
