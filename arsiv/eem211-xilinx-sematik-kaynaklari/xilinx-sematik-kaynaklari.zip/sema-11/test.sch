VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_2
        SIGNAL BTN0
        SIGNAL Q(7:4)
        SIGNAL Q(3:0)
        SIGNAL XLXN_13
        SIGNAL XLXN_14
        SIGNAL Q(7:0)
        SIGNAL SS(7:0)
        SIGNAL AN(3:0)
        SIGNAL Q(1)
        SIGNAL Q(3)
        SIGNAL mclk
        PORT Input BTN0
        PORT Output SS(7:0)
        PORT Output AN(3:0)
        PORT Input mclk
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2007 12 11 13 3 28
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2001 2 2 12 51 49
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2001 2 2 12 53 1
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 SSdriver
            PIN mclk mclk
            PIN S1(3:0) Q(3:0)
            PIN S2(3:0) Q(7:4)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0) SS(7:0)
            PIN AN(3:0) AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_3 pullup
            PIN O XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_4 ibuf
            PIN I BTN0
            PIN O XLXN_13
        END BLOCK
        BEGIN BLOCK XLXI_5 and2
            PIN I0 Q(1)
            PIN I1 Q(3)
            PIN O XLXN_14
        END BLOCK
        BEGIN BLOCK XLXI_6 cb8ce
            PIN C XLXN_13
            PIN CE XLXN_2
            PIN CLR XLXN_14
            PIN CEO
            PIN Q(7:0) Q(7:0)
            PIN TC
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_3 736 1120 R0
        BEGIN BRANCH XLXN_2
            WIRE 800 1120 800 1280
            WIRE 800 1280 1056 1280
        END BRANCH
        INSTANCE XLXI_4 688 1504 R0
        BEGIN BRANCH BTN0
            WIRE 496 1472 688 1472
        END BRANCH
        IOMARKER 496 1472 BTN0 R180 28
        BUSTAP 1664 1248 1760 1248
        BUSTAP 1664 1328 1760 1328
        BEGIN BRANCH Q(7:4)
            WIRE 1760 1328 1904 1328
            WIRE 1904 1328 2048 1328
            BEGIN DISPLAY 1904 1328 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_1 2048 1488 R0
        END INSTANCE
        BEGIN BRANCH Q(3:0)
            WIRE 1760 1248 1824 1248
            WIRE 1824 1248 1904 1248
            WIRE 1904 1248 1904 1264
            WIRE 1904 1264 2048 1264
            BEGIN DISPLAY 1824 1248 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_5 1600 1600 R180
        INSTANCE XLXI_6 1056 1472 R0
        BEGIN BRANCH XLXN_13
            WIRE 912 1472 976 1472
            WIRE 976 1344 976 1472
            WIRE 976 1344 1056 1344
        END BRANCH
        BEGIN BRANCH XLXN_14
            WIRE 1056 1440 1056 1696
            WIRE 1056 1696 1344 1696
        END BRANCH
        BEGIN BRANCH Q(7:0)
            WIRE 1440 1216 1488 1216
            WIRE 1488 1216 1552 1216
            WIRE 1552 1216 1552 1248
            WIRE 1552 1248 1584 1248
            WIRE 1584 1248 1664 1248
            WIRE 1584 1248 1584 1312
            WIRE 1584 1312 1584 1328
            WIRE 1584 1328 1664 1328
            WIRE 1584 1312 1584 1376
            WIRE 1584 1376 1904 1376
            WIRE 1904 1376 1904 1664
            WIRE 1904 1664 1904 1728
            WIRE 1840 1664 1904 1664
            WIRE 1840 1728 1904 1728
            BEGIN DISPLAY 1488 1216 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BUSTAP 1840 1664 1744 1664
        BUSTAP 1840 1728 1744 1728
        BEGIN BRANCH SS(7:0)
            WIRE 2432 1200 2464 1200
        END BRANCH
        IOMARKER 2464 1200 SS(7:0) R0 28
        BEGIN BRANCH AN(3:0)
            WIRE 2432 1456 2464 1456
        END BRANCH
        IOMARKER 2464 1456 AN(3:0) R0 28
        BEGIN BRANCH Q(1)
            WIRE 1600 1664 1664 1664
            WIRE 1664 1664 1744 1664
            BEGIN DISPLAY 1664 1664 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Q(3)
            WIRE 1600 1728 1664 1728
            WIRE 1664 1728 1728 1728
            WIRE 1728 1728 1744 1728
            BEGIN DISPLAY 1664 1728 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH mclk
            WIRE 1888 1104 1888 1200
            WIRE 1888 1200 2048 1200
        END BRANCH
        IOMARKER 1888 1104 mclk R270 28
    END SHEET
END SCHEMATIC
