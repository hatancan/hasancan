VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_23(3:0)
        SIGNAL XLXN_24(3:0)
        SIGNAL XLXN_25
        SIGNAL XLXN_26
        SIGNAL XLXN_27
        SIGNAL XLXN_28(7:0)
        SIGNAL XLXN_29
        SIGNAL XLXN_30
        SIGNAL mclk
        SIGNAL SS(7:0)
        SIGNAL AN(3:0)
        SIGNAL BTN0
        PORT Input mclk
        PORT Output SS(7:0)
        PORT Output AN(3:0)
        PORT Input BTN0
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2001 2 2 12 51 49
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2006 7 31 23 58 46
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2001 2 2 12 53 1
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCK XLXI_2 SSdriver
            PIN mclk mclk
            PIN S1(3:0) XLXN_23(3:0)
            PIN S2(3:0) XLXN_24(3:0)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0) SS(7:0)
            PIN AN(3:0) AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_1 cb8ce
            PIN C XLXN_25
            PIN CE XLXN_29
            PIN CLR XLXN_30
            PIN CEO
            PIN Q(7:0) XLXN_28(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_8 and2
            PIN I0 XLXN_26
            PIN I1 XLXN_27
            PIN O XLXN_30
        END BLOCK
        BEGIN BLOCK XLXI_9 pullup
            PIN O XLXN_29
        END BLOCK
        BEGIN BLOCK XLXI_10 ibuf
            PIN I BTN0
            PIN O XLXN_25
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN INSTANCE XLXI_2 1968 1072 R0
        END INSTANCE
        BUSTAP 1808 848 1904 848
        BUSTAP 1808 912 1904 912
        BUSTAP 1360 1152 1264 1152
        INSTANCE XLXI_8 1200 1088 R180
        BUSTAP 1360 1216 1264 1216
        BEGIN BRANCH XLXN_23(3:0)
            WIRE 1904 848 1968 848
        END BRANCH
        BEGIN BRANCH XLXN_24(3:0)
            WIRE 1904 912 1968 912
        END BRANCH
        BEGIN BRANCH XLXN_26
            WIRE 1200 1152 1264 1152
        END BRANCH
        BEGIN BRANCH XLXN_27
            WIRE 1200 1216 1264 1216
        END BRANCH
        BEGIN BRANCH XLXN_28(7:0)
            WIRE 1360 848 1728 848
            WIRE 1728 848 1808 848
            WIRE 1728 848 1728 912
            WIRE 1728 912 1728 1152
            WIRE 1728 1152 1728 1216
            WIRE 1728 912 1808 912
            WIRE 1360 1152 1728 1152
            WIRE 1360 1216 1728 1216
        END BRANCH
        INSTANCE XLXI_9 736 752 R0
        BEGIN BRANCH XLXN_29
            WIRE 800 752 800 912
            WIRE 800 912 976 912
        END BRANCH
        BEGIN BRANCH mclk
            WIRE 1520 672 1968 672
            WIRE 1968 672 1968 784
        END BRANCH
        BEGIN BRANCH SS(7:0)
            WIRE 2352 784 2448 784
        END BRANCH
        BEGIN BRANCH AN(3:0)
            WIRE 2352 1040 2448 1040
        END BRANCH
        IOMARKER 1520 672 mclk R180 28
        IOMARKER 2448 784 SS(7:0) R0 28
        IOMARKER 2448 1040 AN(3:0) R0 28
        INSTANCE XLXI_1 976 1104 R0
        BEGIN BRANCH XLXN_25
            WIRE 832 976 880 976
            WIRE 880 976 976 976
        END BRANCH
        BEGIN BRANCH XLXN_30
            WIRE 928 1072 976 1072
            WIRE 928 1072 928 1184
            WIRE 928 1184 944 1184
        END BRANCH
        INSTANCE XLXI_10 608 1008 R0
        BEGIN BRANCH BTN0
            WIRE 464 976 560 976
            WIRE 560 976 576 976
            WIRE 576 976 608 976
        END BRANCH
        IOMARKER 464 976 BTN0 R180 28
    END SHEET
END SCHEMATIC
