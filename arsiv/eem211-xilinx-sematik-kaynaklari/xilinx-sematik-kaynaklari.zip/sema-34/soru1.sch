VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL XLXN_2
        SIGNAL XLXN_3
        SIGNAL XLXN_4
        SIGNAL LD0
        SIGNAL XLXN_6
        SIGNAL XLXN_7
        SIGNAL BTN1
        SIGNAL XLXN_9
        SIGNAL XLXN_10
        SIGNAL BTN0
        SIGNAL XLXN_12
        SIGNAL XLXN_13
        SIGNAL XLXN_14
        SIGNAL XLXN_15
        SIGNAL XLXN_16
        SIGNAL XLXN_5
        SIGNAL XLXN_18
        SIGNAL XLXN_19
        SIGNAL XLXN_20
        PORT Output LD0
        PORT Input BTN1
        PORT Input BTN0
        BEGIN BLOCKDEF inv
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCKDEF or2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -144 48 -144 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -48 48 -48 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF and3
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 256 -128 192 -128 
            LINE N 64 -176 144 -176 
            LINE N 144 -80 64 -80 
            ARC N 96 -176 192 -80 144 -80 144 -176 
            LINE N 64 -64 64 -192 
        END BLOCKDEF
        BEGIN BLOCKDEF or3
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 48 -64 
            LINE N 0 -128 72 -128 
            LINE N 0 -192 48 -192 
            LINE N 256 -128 192 -128 
            ARC N 28 -256 204 -80 112 -80 192 -128 
            ARC N -40 -184 72 -72 48 -80 48 -176 
            LINE N 48 -64 48 -80 
            LINE N 48 -192 48 -176 
            LINE N 112 -80 48 -80 
            ARC N 28 -176 204 0 192 -128 112 -176 
            LINE N 112 -176 48 -176 
        END BLOCKDEF
        BEGIN BLOCKDEF fd
            TIMESTAMP 2001 2 2 12 52 25
            RECTANGLE N 64 -320 320 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 inv
            PIN I XLXN_13
            PIN O XLXN_4
        END BLOCK
        BEGIN BLOCK XLXI_2 inv
            PIN I XLXN_20
            PIN O XLXN_14
        END BLOCK
        BEGIN BLOCK XLXI_3 or2
            PIN I0 XLXN_20
            PIN I1 XLXN_13
            PIN O XLXN_15
        END BLOCK
        BEGIN BLOCK XLXI_4 and2
            PIN I0 XLXN_13
            PIN I1 BTN1
            PIN O XLXN_3
        END BLOCK
        BEGIN BLOCK XLXI_5 and3
            PIN I0 BTN1
            PIN I1 XLXN_14
            PIN I2 XLXN_13
            PIN O LD0
        END BLOCK
        BEGIN BLOCK XLXI_6 and2
            PIN I0 XLXN_13
            PIN I1 XLXN_20
            PIN O XLXN_5
        END BLOCK
        BEGIN BLOCK XLXI_7 and3
            PIN I0 XLXN_14
            PIN I1 BTN1
            PIN I2 XLXN_4
            PIN O XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_8 and2
            PIN I0 BTN1
            PIN I1 XLXN_15
            PIN O XLXN_9
        END BLOCK
        BEGIN BLOCK XLXI_9 or3
            PIN I0 XLXN_3
            PIN I1 XLXN_5
            PIN I2 XLXN_2
            PIN O XLXN_1
        END BLOCK
        BEGIN BLOCK XLXI_10 fd
            PIN C BTN0
            PIN D XLXN_1
            PIN Q XLXN_20
        END BLOCK
        BEGIN BLOCK XLXI_11 fd
            PIN C BTN0
            PIN D XLXN_9
            PIN Q XLXN_13
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN BRANCH XLXN_1
            WIRE 1888 1312 2176 1312
        END BRANCH
        BEGIN BRANCH XLXN_2
            WIRE 1408 1104 1632 1104
            WIRE 1632 1104 1632 1248
        END BRANCH
        BEGIN BRANCH XLXN_3
            WIRE 1472 1600 1632 1600
            WIRE 1632 1376 1632 1600
        END BRANCH
        INSTANCE XLXI_1 912 832 R90
        BEGIN BRANCH XLXN_4
            WIRE 944 1056 944 1072
            WIRE 944 1072 1040 1072
            WIRE 1040 1040 1040 1072
            WIRE 1040 1040 1152 1040
        END BRANCH
        INSTANCE XLXI_2 992 1856 R270
        BEGIN BRANCH LD0
            WIRE 1504 1808 1568 1808
            WIRE 1568 1680 1568 1808
            WIRE 1568 1680 2160 1680
            WIRE 2160 1680 2160 1824
            WIRE 2160 1824 3072 1824
        END BRANCH
        BEGIN BRANCH BTN1
            WIRE 624 720 848 720
            WIRE 848 720 1104 720
            WIRE 848 720 848 1216
            WIRE 848 1216 1136 1216
            WIRE 1136 1216 1136 1584
            WIRE 1136 1584 1200 1584
            WIRE 1200 1584 1200 1872
            WIRE 1200 1872 1248 1872
            WIRE 1136 1104 1152 1104
            WIRE 1136 1104 1136 1216
            WIRE 1200 1568 1216 1568
            WIRE 1200 1568 1200 1584
        END BRANCH
        BEGIN BRANCH XLXN_9
            WIRE 1360 688 2160 688
        END BRANCH
        BEGIN BRANCH BTN0
            WIRE 640 1440 2112 1440
            WIRE 2112 1440 2176 1440
            WIRE 2112 816 2160 816
            WIRE 2112 816 2112 1440
        END BRANCH
        INSTANCE XLXI_3 1616 1024 R0
        INSTANCE XLXI_4 1216 1696 R0
        INSTANCE XLXI_5 1248 1936 R0
        INSTANCE XLXI_6 1184 1424 R0
        BEGIN BRANCH XLXN_13
            WIRE 944 576 944 784
            WIRE 944 784 944 832
            WIRE 944 784 1072 784
            WIRE 1072 784 1072 1456
            WIRE 1072 1456 1168 1456
            WIRE 1168 1456 1168 1632
            WIRE 1168 1632 1216 1632
            WIRE 1168 1632 1168 1744
            WIRE 1168 1744 1248 1744
            WIRE 944 576 1536 576
            WIRE 1536 576 1536 896
            WIRE 1536 896 1616 896
            WIRE 1536 576 2608 576
            WIRE 2608 576 2608 688
            WIRE 1168 1360 1184 1360
            WIRE 1168 1360 1168 1456
            WIRE 2544 688 2608 688
        END BRANCH
        INSTANCE XLXI_7 1152 1232 R0
        BEGIN BRANCH XLXN_14
            WIRE 960 1168 1152 1168
            WIRE 960 1168 960 1536
            WIRE 960 1536 960 1632
            WIRE 960 1536 1104 1536
            WIRE 1104 1536 1104 1808
            WIRE 1104 1808 1248 1808
        END BRANCH
        INSTANCE XLXI_8 1104 784 R0
        BEGIN BRANCH XLXN_15
            WIRE 1024 656 1104 656
            WIRE 1024 656 1024 816
            WIRE 1024 816 1888 816
            WIRE 1888 816 1888 928
            WIRE 1872 928 1888 928
        END BRANCH
        INSTANCE XLXI_9 1632 1440 R0
        BEGIN BRANCH XLXN_5
            WIRE 1440 1328 1456 1328
            WIRE 1456 1312 1632 1312
            WIRE 1456 1312 1456 1328
        END BRANCH
        INSTANCE XLXI_10 2176 1568 R0
        BEGIN BRANCH XLXN_20
            WIRE 960 1856 960 1936
            WIRE 960 1936 1088 1936
            WIRE 1088 1936 2624 1936
            WIRE 1088 1296 1184 1296
            WIRE 1088 1296 1088 1936
            WIRE 1552 960 1616 960
            WIRE 1552 960 1552 992
            WIRE 1552 992 2624 992
            WIRE 2624 992 2624 1312
            WIRE 2624 1312 2624 1936
            WIRE 2560 1312 2624 1312
        END BRANCH
        INSTANCE XLXI_11 2160 944 R0
        IOMARKER 3072 1824 LD0 R0 28
        IOMARKER 640 1440 BTN0 R180 28
        IOMARKER 624 720 BTN1 R180 28
    END SHEET
END SCHEMATIC
