VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL BTN0
        SIGNAL XLXN_3
        SIGNAL XLXN_4
        SIGNAL XLXN_5
        SIGNAL XLXN_6
        SIGNAL XLXN_7
        SIGNAL BTN1
        SIGNAL XLXN_11
        SIGNAL XLXN_15
        SIGNAL XLXN_46
        SIGNAL XLXN_47
        SIGNAL XLXN_16
        SIGNAL XLXN_18
        SIGNAL LD0
        PORT Input BTN0
        PORT Input BTN1
        PORT Output LD0
        BEGIN BLOCKDEF and3
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 256 -128 192 -128 
            LINE N 64 -176 144 -176 
            LINE N 144 -80 64 -80 
            ARC N 96 -176 192 -80 144 -80 144 -176 
            LINE N 64 -64 64 -192 
        END BLOCKDEF
        BEGIN BLOCKDEF or3
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 48 -64 
            LINE N 0 -128 72 -128 
            LINE N 0 -192 48 -192 
            LINE N 256 -128 192 -128 
            ARC N 28 -256 204 -80 112 -80 192 -128 
            ARC N -40 -184 72 -72 48 -80 48 -176 
            LINE N 48 -64 48 -80 
            LINE N 48 -192 48 -176 
            LINE N 112 -80 48 -80 
            ARC N 28 -176 204 0 192 -128 112 -176 
            LINE N 112 -176 48 -176 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCKDEF fd
            TIMESTAMP 2001 2 2 12 52 25
            RECTANGLE N 64 -320 320 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF or2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -144 48 -144 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -48 48 -48 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 fd
            PIN C BTN0
            PIN D XLXN_1
            PIN Q XLXN_18
        END BLOCK
        BEGIN BLOCK XLXI_2 fd
            PIN C BTN0
            PIN D XLXN_3
            PIN Q XLXN_16
        END BLOCK
        BEGIN BLOCK XLXI_11 and2
            PIN I0 BTN1
            PIN I1 XLXN_7
            PIN O XLXN_1
        END BLOCK
        BEGIN BLOCK XLXI_4 or3
            PIN I0 XLXN_6
            PIN I1 XLXN_5
            PIN I2 XLXN_4
            PIN O XLXN_3
        END BLOCK
        BEGIN BLOCK XLXI_5 and3
            PIN I0 XLXN_15
            PIN I1 BTN1
            PIN I2 XLXN_11
            PIN O XLXN_4
        END BLOCK
        BEGIN BLOCK XLXI_6 and2
            PIN I0 XLXN_18
            PIN I1 XLXN_16
            PIN O XLXN_5
        END BLOCK
        BEGIN BLOCK XLXI_7 and2
            PIN I0 XLXN_18
            PIN I1 BTN1
            PIN O XLXN_6
        END BLOCK
        BEGIN BLOCK XLXI_3 or2
            PIN I0 XLXN_16
            PIN I1 XLXN_18
            PIN O XLXN_7
        END BLOCK
        BEGIN BLOCK XLXI_9 inv
            PIN I XLXN_18
            PIN O XLXN_11
        END BLOCK
        BEGIN BLOCK XLXI_10 inv
            PIN I XLXN_16
            PIN O XLXN_15
        END BLOCK
        BEGIN BLOCK XLXI_8 and3
            PIN I0 BTN1
            PIN I1 XLXN_15
            PIN I2 XLXN_18
            PIN O LD0
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 2272 1008 R0
        INSTANCE XLXI_2 2288 1664 R0
        INSTANCE XLXI_11 1712 848 R0
        BEGIN BRANCH XLXN_1
            WIRE 1968 752 2272 752
        END BRANCH
        BEGIN BRANCH BTN0
            WIRE 1968 880 2272 880
            WIRE 1968 880 1968 1536
            WIRE 1968 1536 1968 1824
            WIRE 1968 1536 2288 1536
        END BRANCH
        INSTANCE XLXI_4 1728 1536 R0
        BEGIN BRANCH XLXN_3
            WIRE 1984 1408 2288 1408
        END BRANCH
        INSTANCE XLXI_5 1088 1424 R0
        INSTANCE XLXI_6 1088 1600 R0
        INSTANCE XLXI_7 1088 1792 R0
        BEGIN BRANCH XLXN_4
            WIRE 1344 1296 1728 1296
            WIRE 1728 1296 1728 1344
        END BRANCH
        BEGIN BRANCH XLXN_5
            WIRE 1344 1504 1536 1504
            WIRE 1536 1408 1536 1504
            WIRE 1536 1408 1728 1408
        END BRANCH
        BEGIN BRANCH XLXN_6
            WIRE 1344 1696 1728 1696
            WIRE 1728 1472 1728 1696
        END BRANCH
        INSTANCE XLXI_3 944 784 R0
        BEGIN BRANCH XLXN_7
            WIRE 1200 688 1456 688
            WIRE 1456 688 1456 720
            WIRE 1456 720 1712 720
        END BRANCH
        BEGIN BRANCH BTN1
            WIRE 320 784 624 784
            WIRE 624 784 1712 784
            WIRE 624 784 624 1296
            WIRE 624 1296 992 1296
            WIRE 992 1296 1088 1296
            WIRE 992 1296 992 1664
            WIRE 992 1664 1056 1664
            WIRE 1056 1664 1088 1664
            WIRE 1056 1664 1056 2288
            WIRE 1056 2288 2016 2288
        END BRANCH
        INSTANCE XLXI_9 768 912 R90
        BEGIN BRANCH XLXN_11
            WIRE 800 1136 800 1232
            WIRE 800 1232 1088 1232
        END BRANCH
        INSTANCE XLXI_10 848 1936 R270
        BEGIN BRANCH XLXN_15
            WIRE 816 1360 1088 1360
            WIRE 816 1360 816 1616
            WIRE 816 1616 816 1712
            WIRE 816 1616 1408 1616
            WIRE 1408 1616 1408 2224
            WIRE 1408 2224 2016 2224
        END BRANCH
        BEGIN BRANCH XLXN_16
            WIRE 816 1936 816 2016
            WIRE 816 2016 944 2016
            WIRE 944 2016 2736 2016
            WIRE 880 576 880 720
            WIRE 880 720 944 720
            WIRE 880 576 2736 576
            WIRE 2736 576 2736 1408
            WIRE 2736 1408 2736 2016
            WIRE 944 1472 1088 1472
            WIRE 944 1472 944 2016
            WIRE 2672 1408 2736 1408
        END BRANCH
        BEGIN BRANCH XLXN_18
            WIRE 800 496 800 656
            WIRE 800 656 800 864
            WIRE 800 864 800 912
            WIRE 800 864 928 864
            WIRE 928 864 928 1536
            WIRE 928 1536 1024 1536
            WIRE 1024 1536 1088 1536
            WIRE 1024 1536 1024 1728
            WIRE 1024 1728 1088 1728
            WIRE 1024 1728 1024 2160
            WIRE 1024 2160 2016 2160
            WIRE 800 656 944 656
            WIRE 800 496 2720 496
            WIRE 2720 496 2720 752
            WIRE 2656 752 2720 752
        END BRANCH
        INSTANCE XLXI_8 2016 2352 R0
        BEGIN BRANCH LD0
            WIRE 2272 2224 2304 2224
        END BRANCH
        IOMARKER 1968 1824 BTN0 R90 28
        IOMARKER 320 784 BTN1 R180 28
        IOMARKER 2304 2224 LD0 R0 28
    END SHEET
END SCHEMATIC
