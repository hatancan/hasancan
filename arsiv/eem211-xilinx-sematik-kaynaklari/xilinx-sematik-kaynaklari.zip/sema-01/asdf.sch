VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL BTN0
        SIGNAL XLXN_13
        SIGNAL XLXN_14
        SIGNAL Q(7:0)
        SIGNAL Q(1)
        SIGNAL Q(3)
        SIGNAL mclk
        SIGNAL Q(3:0)
        SIGNAL Q(7:4)
        SIGNAL SS(7:0)
        SIGNAL AN(3:0)
        SIGNAL XLXN_15
        SIGNAL XLXN_17
        SIGNAL XLXN_18(3:0)
        SIGNAL XLXN_19
        SIGNAL XLXN_20
        SIGNAL XLXN_21
        SIGNAL XLXN_22
        SIGNAL XLXN_23
        PORT Input BTN0
        PORT Input mclk
        PORT Output SS(7:0)
        PORT Output AN(3:0)
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2008 1 13 13 17 5
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2001 2 2 12 53 1
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2001 2 2 12 51 49
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 SSdriver
            PIN mclk mclk
            PIN S1(3:0) Q(3:0)
            PIN S2(3:0) Q(7:4)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0) SS(7:0)
            PIN AN(3:0) AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_2 pullup
            PIN O XLXN_1
        END BLOCK
        BEGIN BLOCK XLXI_3 ibuf
            PIN I BTN0
            PIN O XLXN_13
        END BLOCK
        BEGIN BLOCK XLXI_4 and2
            PIN I0 Q(1)
            PIN I1 Q(3)
            PIN O XLXN_14
        END BLOCK
        BEGIN BLOCK XLXI_6 cb8ce
            PIN C XLXN_13
            PIN CE XLXN_1
            PIN CLR XLXN_14
            PIN CEO
            PIN Q(7:0) Q(7:0)
            PIN TC
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_2 848 544 R0
        BEGIN BRANCH XLXN_1
            WIRE 912 544 912 640
            WIRE 912 640 1120 640
        END BRANCH
        INSTANCE XLXI_3 800 928 R0
        BEGIN BRANCH BTN0
            WIRE 608 896 800 896
        END BRANCH
        BUSTAP 1776 672 1872 672
        BUSTAP 1776 752 1872 752
        BEGIN BRANCH XLXN_14
            WIRE 1120 800 1120 1408
            WIRE 1120 1408 1360 1408
        END BRANCH
        BEGIN BRANCH Q(7:0)
            WIRE 1504 576 1600 576
            WIRE 1600 576 1600 640
            WIRE 1600 640 1664 640
            WIRE 1664 640 1664 672
            WIRE 1664 672 1696 672
            WIRE 1696 672 1776 672
            WIRE 1696 672 1696 752
            WIRE 1696 752 1776 752
            WIRE 1696 752 1696 800
            WIRE 1696 800 2016 800
            WIRE 2016 800 2016 1088
            WIRE 2016 1088 2016 1152
            WIRE 1952 1088 2016 1088
            WIRE 1952 1152 2016 1152
            BEGIN DISPLAY 1600 640 ATTR Name
                ALIGNMENT SOFT-TCENTER
            END DISPLAY
        END BRANCH
        BUSTAP 1952 1088 1856 1088
        BUSTAP 1952 1152 1856 1152
        BEGIN BRANCH Q(1)
            WIRE 1616 1376 1696 1376
            WIRE 1696 1088 1696 1376
            WIRE 1696 1088 1776 1088
            WIRE 1776 1088 1856 1088
            BEGIN DISPLAY 1776 1088 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Q(3)
            WIRE 1616 1440 1776 1440
            WIRE 1776 1152 1856 1152
            WIRE 1776 1152 1776 1440
            BEGIN DISPLAY 1776 1152 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        IOMARKER 608 896 BTN0 R180 28
        IOMARKER 2000 528 mclk R270 28
        BEGIN BRANCH mclk
            WIRE 2000 528 2016 528
            WIRE 2016 528 2016 544
            WIRE 2016 544 2432 544
        END BRANCH
        BEGIN BRANCH Q(3:0)
            WIRE 1872 672 1888 672
            WIRE 1888 608 2432 608
            WIRE 1888 608 1888 672
        END BRANCH
        BEGIN BRANCH Q(7:4)
            WIRE 1872 752 2160 752
            WIRE 2160 672 2160 752
            WIRE 2160 672 2432 672
        END BRANCH
        BEGIN BRANCH SS(7:0)
            WIRE 2816 544 2928 544
            WIRE 2928 544 2928 784
            WIRE 2928 784 2944 784
        END BRANCH
        BEGIN BRANCH AN(3:0)
            WIRE 2816 800 2912 800
            WIRE 2912 800 2912 1040
            WIRE 2912 1040 2928 1040
        END BRANCH
        IOMARKER 2944 784 SS(7:0) R0 28
        IOMARKER 2928 1040 AN(3:0) R0 28
        INSTANCE XLXI_6 1120 832 R0
        BEGIN BRANCH XLXN_13
            WIRE 1024 896 1040 896
            WIRE 1040 704 1120 704
            WIRE 1040 704 1040 896
        END BRANCH
        BEGIN INSTANCE XLXI_1 2432 832 R0
        END INSTANCE
        INSTANCE XLXI_4 1616 1312 R180
    END SHEET
END SCHEMATIC
