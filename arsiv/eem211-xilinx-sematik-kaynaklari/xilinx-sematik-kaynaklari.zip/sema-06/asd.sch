VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2005 12 11 20 26 27
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF decoder
            TIMESTAMP 2005 12 11 21 2 56
            RECTANGLE N 64 -64 320 0 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF anode_decoder
            TIMESTAMP 2005 12 11 21 3 35
            RECTANGLE N 64 -64 320 0 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF clkdiv
            TIMESTAMP 2005 12 11 21 4 16
            RECTANGLE N 64 -64 320 0 
            LINE N 64 -32 0 -32 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 SSdriver
            PIN mclk
            PIN S1(3:0)
            PIN S2(3:0)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0)
            PIN AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_2 decoder
            PIN S(3:0)
            PIN SS(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_3 anode_decoder
            PIN cnt(1:0)
            PIN AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_4 clkdiv
            PIN mclk
            PIN clk
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN INSTANCE XLXI_1 1040 1248 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_2 624 912 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_3 592 1056 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_4 608 1200 R0
        END INSTANCE
    END SHEET
END SCHEMATIC
