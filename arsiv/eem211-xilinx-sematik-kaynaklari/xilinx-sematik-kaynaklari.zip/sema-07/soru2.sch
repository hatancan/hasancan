VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL mclk
        SIGNAL XLXN_2
        SIGNAL XLXN_3
        SIGNAL BTN0
        SIGNAL XLXN_5
        SIGNAL Q(3:0)
        SIGNAL Q(7:4)
        SIGNAL Q(1)
        SIGNAL Q(3)
        SIGNAL Q(7:0)
        SIGNAL SS(7:0)
        SIGNAL AN(3:0)
        PORT Input mclk
        PORT Input BTN0
        PORT Output SS(7:0)
        PORT Output AN(3:0)
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2001 2 2 12 51 49
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2005 12 11 20 26 28
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2001 2 2 12 53 1
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 cb8ce
            PIN C XLXN_3
            PIN CE XLXN_2
            PIN CLR XLXN_5
            PIN CEO
            PIN Q(7:0) Q(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_2 SSdriver
            PIN mclk mclk
            PIN S1(3:0) Q(3:0)
            PIN S2(3:0) Q(7:4)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0) SS(7:0)
            PIN AN(3:0) AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_3 pullup
            PIN O XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_4 and2
            PIN I0 Q(1)
            PIN I1 Q(3)
            PIN O XLXN_5
        END BLOCK
        BEGIN BLOCK XLXI_5 ibuf
            PIN I BTN0
            PIN O XLXN_3
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 1152 1920 R270
        BEGIN INSTANCE XLXI_2 1136 1360 R270
        END INSTANCE
        BEGIN BRANCH mclk
            WIRE 592 1456 848 1456
            WIRE 848 1360 848 1376
            WIRE 848 1376 848 1456
        END BRANCH
        INSTANCE XLXI_3 704 2112 R0
        BEGIN BRANCH XLXN_2
            WIRE 768 2112 768 2192
            WIRE 768 2192 960 2192
            WIRE 960 1920 960 2192
        END BRANCH
        BEGIN BRANCH XLXN_3
            WIRE 1024 1920 1024 2000
        END BRANCH
        BEGIN BRANCH BTN0
            WIRE 1024 2224 1024 2320
        END BRANCH
        INSTANCE XLXI_4 1248 1584 R90
        BEGIN BRANCH XLXN_5
            WIRE 1120 1920 1344 1920
            WIRE 1344 1840 1344 1920
        END BRANCH
        BUSTAP 1312 1456 1312 1552
        BUSTAP 1376 1456 1376 1552
        BUSTAP 912 1488 912 1392
        BUSTAP 976 1488 976 1392
        BEGIN BRANCH Q(3:0)
            WIRE 912 1360 912 1392
        END BRANCH
        BEGIN BRANCH Q(7:4)
            WIRE 976 1360 976 1392
        END BRANCH
        BEGIN BRANCH Q(1)
            WIRE 1312 1552 1312 1584
        END BRANCH
        BEGIN BRANCH Q(3)
            WIRE 1376 1552 1376 1584
        END BRANCH
        BEGIN BRANCH Q(7:0)
            WIRE 896 1504 896 1536
            WIRE 896 1504 912 1504
            WIRE 912 1504 976 1504
            WIRE 976 1504 1056 1504
            WIRE 912 1488 912 1504
            WIRE 976 1488 976 1504
            WIRE 1056 1392 1056 1504
            WIRE 1056 1392 1312 1392
            WIRE 1312 1392 1312 1456
            WIRE 1312 1392 1328 1392
            WIRE 1328 1392 1328 1408
            WIRE 1328 1408 1376 1408
            WIRE 1376 1408 1376 1456
        END BRANCH
        BEGIN BRANCH SS(7:0)
            WIRE 848 848 848 976
        END BRANCH
        BEGIN BRANCH AN(3:0)
            WIRE 1104 864 1104 976
        END BRANCH
        IOMARKER 848 848 SS(7:0) R270 28
        IOMARKER 1104 864 AN(3:0) R270 28
        IOMARKER 592 1456 mclk R180 28
        IOMARKER 1024 2320 BTN0 R90 28
        INSTANCE XLXI_5 1056 2224 R270
    END SHEET
END SCHEMATIC
