VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL mclk
        SIGNAL XLXN_2
        SIGNAL XLXN_3
        SIGNAL BTN0
        SIGNAL Q(3:0)
        SIGNAL Q(7:4)
        SIGNAL SS(7:0)
        SIGNAL AN(3:0)
        SIGNAL Q(7:0)
        SIGNAL XLXN_15
        PORT Input mclk
        PORT Input BTN0
        PORT Output SS(7:0)
        PORT Output AN(3:0)
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2001 2 2 12 51 49
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2005 12 11 20 26 28
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2001 2 2 12 53 1
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF pulldown
            TIMESTAMP 2002 3 20 16 43 42
            LINE N 64 -160 64 -128 
            LINE N 68 0 60 0 
            LINE N 76 -16 52 -16 
            LINE N 88 -32 40 -32 
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
        END BLOCKDEF
        BEGIN BLOCK XLXI_2 SSdriver
            PIN mclk mclk
            PIN S1(3:0) Q(3:0)
            PIN S2(3:0) Q(7:4)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0) SS(7:0)
            PIN AN(3:0) AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_3 pullup
            PIN O XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_5 ibuf
            PIN I BTN0
            PIN O XLXN_3
        END BLOCK
        BEGIN BLOCK XLXI_1 cb8ce
            PIN C XLXN_3
            PIN CE XLXN_2
            PIN CLR XLXN_15
            PIN CEO
            PIN Q(7:0) Q(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_7 pulldown
            PIN O XLXN_15
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN INSTANCE XLXI_2 1504 1344 R270
        END INSTANCE
        BEGIN BRANCH mclk
            WIRE 960 1440 1216 1440
            WIRE 1216 1344 1216 1360
            WIRE 1216 1360 1216 1440
        END BRANCH
        INSTANCE XLXI_3 1072 2096 R0
        BEGIN BRANCH XLXN_2
            WIRE 1136 2096 1136 2176
            WIRE 1136 2176 1328 2176
            WIRE 1328 1904 1328 2176
        END BRANCH
        BEGIN BRANCH XLXN_3
            WIRE 1392 1904 1392 1984
        END BRANCH
        BEGIN BRANCH BTN0
            WIRE 1392 2208 1392 2304
        END BRANCH
        BUSTAP 1280 1472 1280 1376
        BUSTAP 1344 1472 1344 1376
        BEGIN BRANCH Q(3:0)
            WIRE 1280 1344 1280 1376
        END BRANCH
        BEGIN BRANCH Q(7:4)
            WIRE 1344 1344 1344 1376
        END BRANCH
        BEGIN BRANCH SS(7:0)
            WIRE 1216 832 1216 960
        END BRANCH
        BEGIN BRANCH AN(3:0)
            WIRE 1472 848 1472 960
        END BRANCH
        INSTANCE XLXI_5 1424 2208 R270
        IOMARKER 1216 832 SS(7:0) R270 28
        IOMARKER 1472 848 AN(3:0) R270 28
        IOMARKER 960 1440 mclk R180 28
        IOMARKER 1392 2304 BTN0 R90 28
        INSTANCE XLXI_1 1520 1904 R270
        BEGIN BRANCH Q(7:0)
            WIRE 1264 1488 1280 1488
            WIRE 1264 1488 1264 1504
            WIRE 1264 1504 1264 1520
            WIRE 1264 1504 1344 1504
            WIRE 1280 1472 1280 1488
            WIRE 1344 1472 1344 1504
        END BRANCH
        INSTANCE XLXI_7 2048 2144 R0
        BEGIN BRANCH XLXN_15
            WIRE 1488 1904 2112 1904
            WIRE 2112 1904 2112 1984
        END BRANCH
    END SHEET
END SCHEMATIC
