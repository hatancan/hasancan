VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_3
        SIGNAL mclk
        SIGNAL XLXN_13
        SIGNAL Q(3:0)
        SIGNAL XLXN_15
        SIGNAL XLXN_16
        SIGNAL Q(0)
        SIGNAL XLXN_19
        SIGNAL XLXN_20
        SIGNAL XLXN_21
        SIGNAL Q(2)
        SIGNAL XLXN_23
        SIGNAL XLXN_24
        SIGNAL Q(1)
        SIGNAL XLXN_26
        SIGNAL XLXN_27
        SIGNAL Q(3)
        SIGNAL XLXN_29
        SIGNAL XLXN_30
        PORT Input mclk
        PORT Output Q(3:0)
        BEGIN BLOCKDEF fjkc
            TIMESTAMP 2001 2 2 12 52 25
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 0 -320 64 -320 
            LINE N 384 -256 320 -256 
            LINE N 0 -256 64 -256 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            RECTANGLE N 64 -384 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF pulldown
            TIMESTAMP 2002 3 20 16 43 42
            LINE N 64 -160 64 -128 
            LINE N 68 0 60 0 
            LINE N 76 -16 52 -16 
            LINE N 88 -32 40 -32 
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 fjkc
            PIN C mclk
            PIN CLR XLXN_13
            PIN J XLXN_3
            PIN K XLXN_3
            PIN Q XLXN_16
        END BLOCK
        BEGIN BLOCK XLXI_2 fjkc
            PIN C XLXN_16
            PIN CLR XLXN_13
            PIN J XLXN_3
            PIN K XLXN_3
            PIN Q XLXN_24
        END BLOCK
        BEGIN BLOCK XLXI_3 fjkc
            PIN C XLXN_24
            PIN CLR XLXN_13
            PIN J XLXN_3
            PIN K XLXN_3
            PIN Q XLXN_21
        END BLOCK
        BEGIN BLOCK XLXI_4 fjkc
            PIN C XLXN_21
            PIN CLR XLXN_13
            PIN J XLXN_3
            PIN K XLXN_3
            PIN Q XLXN_27
        END BLOCK
        BEGIN BLOCK XLXI_6 pulldown
            PIN O XLXN_13
        END BLOCK
        BEGIN BLOCK XLXI_11 pullup
            PIN O XLXN_3
        END BLOCK
        BEGIN BLOCK XLXI_12 inv
            PIN I XLXN_16
            PIN O Q(0)
        END BLOCK
        BEGIN BLOCK XLXI_13 inv
            PIN I XLXN_24
            PIN O Q(1)
        END BLOCK
        BEGIN BLOCK XLXI_14 inv
            PIN I XLXN_21
            PIN O Q(2)
        END BLOCK
        BEGIN BLOCK XLXI_15 inv
            PIN I XLXN_27
            PIN O Q(3)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 672 1600 R0
        INSTANCE XLXI_2 1360 1568 R0
        INSTANCE XLXI_3 2096 1568 R0
        INSTANCE XLXI_4 2832 1552 R0
        BEGIN BRANCH XLXN_3
            WIRE 656 592 656 800
            WIRE 656 800 656 1280
            WIRE 656 1280 656 1344
            WIRE 656 1344 672 1344
            WIRE 656 1280 672 1280
            WIRE 656 800 1344 800
            WIRE 1344 800 1344 1248
            WIRE 1344 1248 1360 1248
            WIRE 1344 1248 1344 1312
            WIRE 1344 1312 1360 1312
            WIRE 1344 800 2096 800
            WIRE 2096 800 2816 800
            WIRE 2816 800 2816 1216
            WIRE 2096 800 2096 1120
            WIRE 2000 1120 2000 1264
            WIRE 2000 1264 2080 1264
            WIRE 2080 1264 2080 1312
            WIRE 2080 1312 2096 1312
            WIRE 2000 1120 2096 1120
            WIRE 2080 1248 2096 1248
            WIRE 2080 1248 2080 1264
            WIRE 2800 1216 2816 1216
            WIRE 2800 1216 2800 1232
            WIRE 2800 1232 2816 1232
            WIRE 2816 1232 2832 1232
            WIRE 2816 1232 2816 1296
            WIRE 2816 1296 2832 1296
        END BRANCH
        BEGIN BRANCH mclk
            WIRE 384 1472 672 1472
        END BRANCH
        BUSTAP 960 1744 1056 1744
        BUSTAP 1648 1744 1744 1744
        BUSTAP 2384 1744 2480 1744
        BUSTAP 3120 1744 3216 1744
        BEGIN BRANCH Q(3:0)
            WIRE 528 1904 944 1904
            WIRE 944 1904 1632 1904
            WIRE 1632 1904 1760 1904
            WIRE 1760 1904 2368 1904
            WIRE 2368 1904 3104 1904
            WIRE 528 1904 528 1952
            WIRE 944 1744 960 1744
            WIRE 944 1744 944 1904
            WIRE 1632 1744 1648 1744
            WIRE 1632 1744 1632 1904
            WIRE 2368 1744 2384 1744
            WIRE 2368 1744 2368 1904
            WIRE 3104 1744 3120 1744
            WIRE 3104 1744 3104 1904
        END BRANCH
        IOMARKER 384 1472 mclk R180 28
        BEGIN BRANCH XLXN_13
            WIRE 240 1584 240 1728
            WIRE 240 1584 672 1584
            WIRE 672 1584 1360 1584
            WIRE 1360 1584 2096 1584
            WIRE 2096 1584 2832 1584
            WIRE 672 1568 672 1584
            WIRE 1360 1536 1360 1584
            WIRE 2096 1536 2096 1584
            WIRE 2832 1520 2832 1584
        END BRANCH
        INSTANCE XLXI_6 176 1888 R0
        IOMARKER 528 1952 Q(3:0) R90 28
        INSTANCE XLXI_11 592 592 R0
        BEGIN BRANCH XLXN_16
            WIRE 1056 1344 1120 1344
            WIRE 1120 1344 1232 1344
            WIRE 1232 1344 1232 1440
            WIRE 1232 1440 1360 1440
            WIRE 1120 1344 1120 1376
            WIRE 1120 1376 1200 1376
            WIRE 1200 1376 1200 1408
        END BRANCH
        BEGIN BRANCH Q(0)
            WIRE 1056 1744 1200 1744
            WIRE 1200 1632 1200 1744
        END BRANCH
        INSTANCE XLXI_13 1808 1408 R90
        BEGIN BRANCH XLXN_21
            WIRE 2480 1312 2496 1312
            WIRE 2496 1312 2496 1424
            WIRE 2496 1424 2528 1424
            WIRE 2528 1424 2832 1424
            WIRE 2528 1424 2528 1488
            WIRE 2528 1488 2576 1488
            WIRE 2576 1488 2576 1552
        END BRANCH
        BEGIN BRANCH Q(2)
            WIRE 2480 1744 2496 1744
            WIRE 2496 1744 2496 1792
            WIRE 2496 1792 2576 1792
            WIRE 2576 1776 2576 1792
        END BRANCH
        BEGIN BRANCH XLXN_24
            WIRE 1744 1312 1840 1312
            WIRE 1840 1312 1840 1376
            WIRE 1840 1376 1840 1408
            WIRE 1840 1376 1968 1376
            WIRE 1968 1376 1968 1440
            WIRE 1968 1440 2096 1440
        END BRANCH
        BEGIN BRANCH Q(1)
            WIRE 1744 1744 1840 1744
            WIRE 1840 1632 1840 1744
        END BRANCH
        BEGIN BRANCH XLXN_27
            WIRE 3216 1296 3232 1296
            WIRE 3232 1296 3232 1408
            WIRE 3232 1408 3328 1408
            WIRE 3328 1408 3328 1424
        END BRANCH
        BEGIN BRANCH Q(3)
            WIRE 3216 1744 3232 1744
            WIRE 3232 1696 3232 1744
            WIRE 3232 1696 3328 1696
            WIRE 3328 1648 3328 1696
        END BRANCH
        INSTANCE XLXI_15 3296 1424 R90
        INSTANCE XLXI_14 2544 1552 R90
        INSTANCE XLXI_12 1168 1408 R90
    END SHEET
END SCHEMATIC
