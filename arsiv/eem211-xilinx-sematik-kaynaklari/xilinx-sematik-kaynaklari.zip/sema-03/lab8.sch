VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL mclk
        SIGNAL XLXN_2
        SIGNAL F
        PORT Input mclk
        PORT Output F
        BEGIN BLOCKDEF fd
            TIMESTAMP 2001 2 2 12 52 25
            RECTANGLE N 64 -320 320 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 fd
            PIN C mclk
            PIN D F
            PIN Q XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_2 inv
            PIN I XLXN_2
            PIN O F
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 1120 1488 R0
        BEGIN BRANCH XLXN_2
            WIRE 1504 1232 1840 1232
        END BRANCH
        INSTANCE XLXI_2 1840 1264 R0
        BEGIN BRANCH mclk
            WIRE 816 1360 1120 1360
        END BRANCH
        BEGIN BRANCH F
            WIRE 800 896 2208 896
            WIRE 2208 896 2208 1232
            WIRE 2208 1232 2416 1232
            WIRE 800 896 800 1232
            WIRE 800 1232 1120 1232
            WIRE 2064 1232 2208 1232
        END BRANCH
        IOMARKER 816 1360 mclk R180 28
        IOMARKER 2416 1232 F R0 28
    END SHEET
END SCHEMATIC
