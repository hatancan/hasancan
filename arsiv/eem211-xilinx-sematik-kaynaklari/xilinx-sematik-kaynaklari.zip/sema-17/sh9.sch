VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL BTN_0
        SIGNAL XLXN_3
        SIGNAL mclk
        SIGNAL Q(7:0)
        SIGNAL Q(3:0)
        SIGNAL Q(7:4)
        SIGNAL XLXN_2
        SIGNAL Q(1)
        SIGNAL Q(3)
        SIGNAL SS(7:0)
        SIGNAL AN(3:0)
        PORT Input BTN_0
        PORT Input mclk
        PORT Output SS(7:0)
        PORT Output AN(3:0)
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2005 12 11 10 1 20
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2001 2 2 12 53 1
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2001 2 2 12 51 49
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 SSdriver
            PIN mclk mclk
            PIN S1(3:0) Q(3:0)
            PIN S2(3:0) Q(7:4)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0) SS(7:0)
            PIN AN(3:0) AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_2 pullup
            PIN O XLXN_1
        END BLOCK
        BEGIN BLOCK XLXI_3 ibuf
            PIN I BTN_0
            PIN O XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_4 and2
            PIN I0 Q(1)
            PIN I1 Q(3)
            PIN O XLXN_3
        END BLOCK
        BEGIN BLOCK XLXI_5 cb8ce
            PIN C XLXN_2
            PIN CE XLXN_1
            PIN CLR XLXN_3
            PIN CEO
            PIN Q(7:0) Q(7:0)
            PIN TC
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN INSTANCE XLXI_1 1712 1232 R0
        END INSTANCE
        INSTANCE XLXI_2 896 960 R0
        BEGIN BRANCH XLXN_1
            WIRE 960 960 960 1088
            WIRE 960 1088 1040 1088
        END BRANCH
        INSTANCE XLXI_3 784 1184 R0
        BEGIN BRANCH BTN_0
            WIRE 736 1152 784 1152
        END BRANCH
        INSTANCE XLXI_4 1408 1280 R180
        BEGIN BRANCH XLXN_3
            WIRE 1040 1248 1040 1376
            WIRE 1040 1376 1152 1376
        END BRANCH
        BEGIN BRANCH mclk
            WIRE 1376 752 1424 752
            WIRE 1424 752 1424 944
            WIRE 1424 944 1712 944
        END BRANCH
        BEGIN BRANCH Q(7:0)
            WIRE 1424 1024 1520 1024
            WIRE 1520 1024 1536 1024
            WIRE 1536 1024 1552 1024
            WIRE 1520 1024 1520 1088
            WIRE 1520 1088 1552 1088
            WIRE 1520 1088 1520 1296
            WIRE 1520 1296 1760 1296
            WIRE 1760 1296 1760 1360
            WIRE 1760 1360 1760 1440
            WIRE 1696 1360 1760 1360
            WIRE 1696 1440 1760 1440
        END BRANCH
        BEGIN BRANCH Q(3:0)
            WIRE 1648 1008 1648 1024
            WIRE 1648 1008 1712 1008
        END BRANCH
        BEGIN BRANCH Q(7:4)
            WIRE 1648 1088 1680 1088
            WIRE 1680 1072 1680 1088
            WIRE 1680 1072 1712 1072
        END BRANCH
        BEGIN BRANCH XLXN_2
            WIRE 1008 1152 1040 1152
        END BRANCH
        INSTANCE XLXI_5 1040 1280 R0
        BEGIN BRANCH Q(1)
            WIRE 1408 1344 1504 1344
            WIRE 1504 1344 1504 1360
            WIRE 1504 1360 1600 1360
        END BRANCH
        BEGIN BRANCH Q(3)
            WIRE 1408 1408 1504 1408
            WIRE 1504 1408 1504 1440
            WIRE 1504 1440 1584 1440
            WIRE 1584 1440 1600 1440
        END BRANCH
        BEGIN BRANCH SS(7:0)
            WIRE 2096 944 2176 944
        END BRANCH
        BEGIN BRANCH AN(3:0)
            WIRE 2096 1200 2176 1200
        END BRANCH
        IOMARKER 1376 752 mclk R180 28
        IOMARKER 736 1152 BTN_0 R180 28
        IOMARKER 2176 1200 AN(3:0) R0 28
        IOMARKER 2176 944 SS(7:0) R0 28
        BUSTAP 1696 1360 1600 1360
        BUSTAP 1696 1440 1600 1440
        BUSTAP 1552 1088 1648 1088
        BUSTAP 1552 1024 1648 1024
    END SHEET
END SCHEMATIC
