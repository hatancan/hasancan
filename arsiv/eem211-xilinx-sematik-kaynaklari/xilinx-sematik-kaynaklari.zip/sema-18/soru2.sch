VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL XLXN_2
        SIGNAL BTN0
        SIGNAL XLXN_4
        SIGNAL Q(3)
        SIGNAL Q(1)
        SIGNAL XLXN_10
        SIGNAL mclk
        SIGNAL XLXN_12(3:0)
        SIGNAL XLXN_13(3:0)
        SIGNAL XLXN_14(7:0)
        SIGNAL XLXN_15
        SIGNAL XLXN_16
        SIGNAL XLXN_17
        SIGNAL SS(7:0)
        SIGNAL AN(3:0)
        PORT Input BTN0
        PORT Input mclk
        PORT Output SS(7:0)
        PORT Output AN(3:0)
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2001 2 2 12 51 49
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF SSdriver
            TIMESTAMP 2006 12 18 17 57 47
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2001 2 2 12 53 1
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 cb8ce
            PIN C XLXN_2
            PIN CE XLXN_1
            PIN CLR XLXN_4
            PIN CEO
            PIN Q(7:0) XLXN_14(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_2 SSdriver
            PIN mclk mclk
            PIN S1(3:0) XLXN_12(3:0)
            PIN S2(3:0) XLXN_13(3:0)
            PIN S3(3:0)
            PIN S4(3:0)
            PIN SS(7:0) SS(7:0)
            PIN AN(3:0) AN(3:0)
        END BLOCK
        BEGIN BLOCK XLXI_3 pullup
            PIN O XLXN_1
        END BLOCK
        BEGIN BLOCK XLXI_4 ibuf
            PIN I BTN0
            PIN O XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_5 and2
            PIN I0 Q(1)
            PIN I1 Q(3)
            PIN O XLXN_4
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 736 960 R0
        INSTANCE XLXI_3 416 448 R0
        BEGIN BRANCH XLXN_1
            WIRE 480 448 480 768
            WIRE 480 768 736 768
        END BRANCH
        INSTANCE XLXI_4 464 864 R0
        BEGIN BRANCH XLXN_2
            WIRE 688 832 736 832
        END BRANCH
        BEGIN BRANCH BTN0
            WIRE 304 832 464 832
        END BRANCH
        IOMARKER 304 832 BTN0 R180 28
        INSTANCE XLXI_5 816 960 R180
        BEGIN BRANCH XLXN_4
            WIRE 544 928 544 1056
            WIRE 544 1056 560 1056
            WIRE 544 928 736 928
        END BRANCH
        BUSTAP 976 1024 880 1024
        BUSTAP 976 1088 880 1088
        BEGIN BRANCH Q(3)
            WIRE 816 1088 880 1088
        END BRANCH
        BEGIN BRANCH Q(1)
            WIRE 816 1024 880 1024
        END BRANCH
        BEGIN INSTANCE XLXI_2 1664 928 R0
        END INSTANCE
        BUSTAP 1520 704 1616 704
        BUSTAP 1520 768 1616 768
        BEGIN BRANCH mclk
            WIRE 1584 544 1600 544
            WIRE 1600 544 1648 544
            WIRE 1648 544 1648 640
            WIRE 1648 640 1664 640
        END BRANCH
        IOMARKER 1584 544 mclk R180 28
        BEGIN BRANCH XLXN_12(3:0)
            WIRE 1616 704 1664 704
        END BRANCH
        BEGIN BRANCH XLXN_13(3:0)
            WIRE 1616 768 1664 768
        END BRANCH
        BEGIN BRANCH XLXN_14(7:0)
            WIRE 976 1024 1040 1024
            WIRE 1040 1024 1040 1088
            WIRE 1040 1024 1472 1024
            WIRE 976 1088 1040 1088
            WIRE 1120 704 1472 704
            WIRE 1472 704 1520 704
            WIRE 1472 704 1472 768
            WIRE 1472 768 1520 768
            WIRE 1472 768 1472 1024
        END BRANCH
        BEGIN BRANCH SS(7:0)
            WIRE 2048 640 2160 640
        END BRANCH
        BEGIN BRANCH AN(3:0)
            WIRE 2048 896 2176 896
        END BRANCH
        IOMARKER 2160 640 SS(7:0) R0 28
        IOMARKER 2176 896 AN(3:0) R0 28
    END SHEET
END SCHEMATIC
