VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL A
        SIGNAL XLXN_4
        SIGNAL XLXN_6
        SIGNAL C
        SIGNAL XLXN_8
        SIGNAL XLXN_9
        SIGNAL XLXN_10
        SIGNAL XLXN_14
        SIGNAL B
        SIGNAL F
        PORT Input A
        PORT Input C
        PORT Input B
        PORT Output F
        BEGIN BLOCKDEF and2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCKDEF or2
            TIMESTAMP 2001 2 2 12 53 52
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -144 48 -144 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -48 48 -48 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 and2
            PIN I0 B
            PIN I1 A
            PIN O XLXN_8
        END BLOCK
        BEGIN BLOCK XLXI_2 and2
            PIN I0 C
            PIN I1 XLXN_4
            PIN O XLXN_9
        END BLOCK
        BEGIN BLOCK XLXI_4 inv
            PIN I B
            PIN O XLXN_4
        END BLOCK
        BEGIN BLOCK XLXI_5 or2
            PIN I0 XLXN_9
            PIN I1 XLXN_8
            PIN O F
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 1504 736 R0
        INSTANCE XLXI_2 1504 1008 R0
        INSTANCE XLXI_4 976 912 R0
        BEGIN BRANCH A
            WIRE 720 608 1504 608
        END BRANCH
        BEGIN BRANCH XLXN_4
            WIRE 1200 880 1504 880
        END BRANCH
        BEGIN BRANCH C
            WIRE 736 944 1504 944
        END BRANCH
        BEGIN BRANCH XLXN_8
            WIRE 1760 640 1968 640
            WIRE 1968 640 1968 656
            WIRE 1968 656 2176 656
        END BRANCH
        BEGIN BRANCH XLXN_9
            WIRE 1760 912 1968 912
            WIRE 1968 720 1968 912
            WIRE 1968 720 2176 720
        END BRANCH
        BEGIN BRANCH B
            WIRE 720 672 896 672
            WIRE 896 672 1504 672
            WIRE 896 672 896 880
            WIRE 896 880 976 880
        END BRANCH
        BEGIN BRANCH F
            WIRE 2432 688 2560 688
        END BRANCH
        INSTANCE XLXI_5 2176 784 R0
        IOMARKER 720 608 A R180 28
        IOMARKER 720 672 B R180 28
        IOMARKER 736 944 C R180 28
        IOMARKER 2560 688 F R0 28
    END SHEET
END SCHEMATIC
