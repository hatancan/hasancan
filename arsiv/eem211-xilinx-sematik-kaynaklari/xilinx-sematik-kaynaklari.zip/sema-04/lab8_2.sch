VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_7
        SIGNAL Q(0)
        SIGNAL Q(1)
        SIGNAL Q(2)
        SIGNAL Q(3)
        SIGNAL mclk
        SIGNAL XLXN_13
        SIGNAL Q(3:0)
        PORT Input mclk
        PORT Output Q(3:0)
        BEGIN BLOCKDEF fjkc
            TIMESTAMP 2001 2 2 12 52 25
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 0 -320 64 -320 
            LINE N 384 -256 320 -256 
            LINE N 0 -256 64 -256 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            RECTANGLE N 64 -384 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF pullup
            TIMESTAMP 2002 3 20 16 41 31
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
            LINE N 48 -56 64 -48 
            LINE N 80 -72 48 -56 
            LINE N 48 -88 80 -72 
            LINE N 80 -104 48 -88 
            LINE N 64 -108 80 -104 
            LINE N 64 0 64 -32 
            LINE N 96 -128 32 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF pulldown
            TIMESTAMP 2002 3 20 16 43 42
            LINE N 64 -160 64 -128 
            LINE N 68 0 60 0 
            LINE N 76 -16 52 -16 
            LINE N 88 -32 40 -32 
            LINE N 64 -108 64 -128 
            LINE N 80 -104 64 -108 
            LINE N 48 -88 80 -104 
            LINE N 80 -72 48 -88 
            LINE N 48 -56 80 -72 
            LINE N 64 -48 48 -56 
            LINE N 64 -32 64 -48 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 fjkc
            PIN C mclk
            PIN CLR XLXN_13
            PIN J XLXN_7
            PIN K XLXN_7
            PIN Q Q(0)
        END BLOCK
        BEGIN BLOCK XLXI_2 fjkc
            PIN C Q(0)
            PIN CLR XLXN_13
            PIN J XLXN_7
            PIN K XLXN_7
            PIN Q Q(1)
        END BLOCK
        BEGIN BLOCK XLXI_3 fjkc
            PIN C Q(1)
            PIN CLR XLXN_13
            PIN J XLXN_7
            PIN K XLXN_7
            PIN Q Q(2)
        END BLOCK
        BEGIN BLOCK XLXI_4 fjkc
            PIN C Q(2)
            PIN CLR XLXN_13
            PIN J XLXN_7
            PIN K XLXN_7
            PIN Q Q(3)
        END BLOCK
        BEGIN BLOCK XLXI_5 pullup
            PIN O XLXN_7
        END BLOCK
        BEGIN BLOCK XLXI_6 pulldown
            PIN O XLXN_13
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 512 1456 R0
        INSTANCE XLXI_2 1200 1424 R0
        INSTANCE XLXI_3 1936 1424 R0
        INSTANCE XLXI_4 2672 1408 R0
        BEGIN BRANCH XLXN_7
            WIRE 496 464 496 592
            WIRE 496 592 496 1136
            WIRE 496 1136 496 1200
            WIRE 496 1200 512 1200
            WIRE 496 1136 512 1136
            WIRE 496 592 1184 592
            WIRE 1184 592 1184 640
            WIRE 1184 640 1184 1104
            WIRE 1184 1104 1200 1104
            WIRE 1184 1104 1184 1168
            WIRE 1184 1168 1200 1168
            WIRE 1184 640 1200 640
            WIRE 1200 624 1200 640
            WIRE 1200 624 1936 624
            WIRE 1936 624 1936 656
            WIRE 1936 656 2656 656
            WIRE 2656 656 2656 1072
            WIRE 1936 656 1936 976
            WIRE 1840 976 1840 1120
            WIRE 1840 1120 1920 1120
            WIRE 1920 1120 1920 1168
            WIRE 1920 1168 1936 1168
            WIRE 1840 976 1936 976
            WIRE 1920 1104 1936 1104
            WIRE 1920 1104 1920 1120
            WIRE 2640 1072 2656 1072
            WIRE 2640 1072 2640 1088
            WIRE 2640 1088 2656 1088
            WIRE 2656 1088 2672 1088
            WIRE 2656 1088 2656 1152
            WIRE 2656 1152 2672 1152
        END BRANCH
        INSTANCE XLXI_5 432 464 R0
        BEGIN BRANCH Q(0)
            WIRE 896 1200 960 1200
            WIRE 960 1200 960 1296
            WIRE 960 1296 1200 1296
            WIRE 960 1296 960 1600
            WIRE 896 1600 960 1600
        END BRANCH
        BEGIN BRANCH Q(1)
            WIRE 1584 1168 1600 1168
            WIRE 1600 1168 1600 1296
            WIRE 1600 1296 1600 1600
            WIRE 1600 1296 1936 1296
            WIRE 1584 1600 1600 1600
        END BRANCH
        BEGIN BRANCH Q(2)
            WIRE 2320 1168 2336 1168
            WIRE 2336 1168 2336 1280
            WIRE 2336 1280 2672 1280
            WIRE 2336 1280 2336 1600
            WIRE 2320 1600 2336 1600
        END BRANCH
        BEGIN BRANCH Q(3)
            WIRE 3056 1152 3072 1152
            WIRE 3072 1152 3072 1600
            WIRE 3056 1600 3072 1600
        END BRANCH
        BEGIN BRANCH mclk
            WIRE 224 1328 512 1328
        END BRANCH
        BEGIN BRANCH XLXN_13
            WIRE 272 1424 512 1424
            WIRE 512 1424 512 1440
            WIRE 512 1440 1200 1440
            WIRE 1200 1440 1936 1440
            WIRE 1936 1440 2672 1440
            WIRE 272 1424 272 1552
            WIRE 1200 1392 1200 1440
            WIRE 1936 1392 1936 1440
            WIRE 2672 1376 2672 1440
        END BRANCH
        INSTANCE XLXI_6 208 1712 R0
        BUSTAP 800 1600 896 1600
        BUSTAP 1488 1600 1584 1600
        BUSTAP 2224 1600 2320 1600
        BUSTAP 2960 1600 3056 1600
        BEGIN BRANCH Q(3:0)
            WIRE 416 1760 784 1760
            WIRE 784 1760 1472 1760
            WIRE 1472 1760 1472 1776
            WIRE 1472 1776 1488 1776
            WIRE 1488 1776 1488 1824
            WIRE 1488 1824 1504 1824
            WIRE 416 1760 416 2016
            WIRE 784 1600 800 1600
            WIRE 784 1600 784 1760
            WIRE 1472 1600 1488 1600
            WIRE 1472 1600 1472 1760
            WIRE 1504 1760 1504 1824
            WIRE 1504 1760 2208 1760
            WIRE 2208 1760 2208 1776
            WIRE 2208 1776 2944 1776
            WIRE 2208 1600 2224 1600
            WIRE 2208 1600 2208 1760
            WIRE 2944 1600 2960 1600
            WIRE 2944 1600 2944 1776
        END BRANCH
        IOMARKER 416 2016 Q(3:0) R90 28
        IOMARKER 224 1328 mclk R180 28
    END SHEET
END SCHEMATIC
