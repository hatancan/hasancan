.model small
.stack 100
.data
rnum dw ?
	.code
main proc far

        in al, 40h			; read micro-clock for initial seed
        mov ah, al
        in al, 40h
        xchg al, ah
        or ax, 1
        mov rnum, ax			;rnum değeri ax değerini alır

	mov bx,0100			;0-100 arası için kıstılama yapacak register
	div bx				;bölme işlemi kalan dx registerinde
	add dx,1			;mod işlemi gereği 1 toplanması
	
	mov ax,dx	
	MOV aH, 0H
					;decimale çevirmek için gerekli işlemler		
	MOV BX, 10	
	DIV BL
	OR aX, 3030H	

	mov dl,al
	mov bl,ah
	mov ah,02H
	int 21H

	mov dl,bl			;yazdırma işlemleri
	mov ah,02H
	
	int 21H
	mov ah,4cH			;DOS a dönüş
	int 21H

main endp
	end main