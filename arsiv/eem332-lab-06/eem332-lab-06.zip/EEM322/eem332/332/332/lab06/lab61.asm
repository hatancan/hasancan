;EEM 332 - LAB 6 - ÖNÇALIŞMA SORU 1

		.MODEL SMALL
		.STACK 64
		.DATA
SONUC	DB	100 DUP(?)
		

		.CODE
MAIN		PROC	FAR		;this is the program entry point
		MOV	AX,@DATA	;load the data segment address
		MOV	DS,AX	;assign value to DS
		
	
		SUB DX,DX	;DX'i sıfırla
		SUB BX,BX
		INC DX		;En az bir kelime
		
	DEVAM:	MOV AH,1
		INT 21H
		CMP AL,0DH		;Enter'a basıldı mı?
		JZ  BITIS		;Basıldıysa döngüden çık
		MOV [SI],AL
		INC SI			;stringi arttır
		CMP AL,20H		;Boşluk mu?
		JZ  BOSLUK		;Boşluk ise DX'i arttır
		JMP DEVAM		;Devam

	BOSLUK: INC DX		;Boşluk, DX'i arttır
		JMP DEVAM    

		MOV DI,DX	
	
	

		;Lab Föyünde verilen Hex 'i Decimal'e çeviren kod

	BITIS:  MOV DI,DX
		MOV AX,DI 	;HEXVAL ADRESINDEN DEGERI AX’E AL
		SUB DX,DX
		MOV BL,000AH 	;BX YAZMACINA 0A DEGERINI ATA
		DIV BL 		;AX YAZMACINI BX YAZMACINA BÖL
		MOV DH,AL 	;CIKAN DEGER DECIMAL SAYININ 10LAR
		MUL BL 		;DEGERI BX’LE CARP
		MOV CX,DI
		SUB CX,AX	;CX VE AX YAZMACLARININ FARKINI AL
		MOV DL,CL 	;CIKAN DEGER DECIMAL SAYININ 1LER 


		OR  DX,3030H		;ASCII'ye çevir
		XCHG DL,DH		;Basamakları düzenle
		MOV DI,OFFSET SONUC
		MOV AX,0D0AH		;Alt Satıra yazdırmak için
		MOV [DI],AX		;Alt Satıra yazdırmak için
		ADD DI,2
		MOV [DI],DL
		INC DI
		MOV [DI],DH
		INC DI	
		MOV DX,OFFSET SONUC	
		MOV AH,'$'		;String sonu
		MOV [DI],AH



		MOV 	AH,09H	;Yazdır
		INT 	21H
		
		MOV	AH,4CH	;set up to
		INT	21H		;return to DOS
MAIN		ENDP			
		END  MAIN		;this is the program exit point