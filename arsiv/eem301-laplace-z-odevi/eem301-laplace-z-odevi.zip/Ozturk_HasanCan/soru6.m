clear all
close all
clc

%1)  2 -4  3  2  1
%2) -2 -3  3 -2 -2
%3)  2  1  1 -3 -2
%4)  1 -3  1 -3 18
%5)  3 -3  1  3  6
%6)  1 -2  4 -2

syms z n    %(z ve n sembolik de?i?kenleri tan?mlan?r) 

X=(-2*z^(-2)+1)/(1+z^(-1)+(-1/2)*z^(-2)); %(fonksiyonumuz tan?mlan?r)

x=iztrans(X);  %(ters z d?n???m? yap?l?r)

disp(x);