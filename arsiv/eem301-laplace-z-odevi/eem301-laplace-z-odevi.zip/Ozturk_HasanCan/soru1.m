clear all
close all
clc

%1)  2 -4  3  2  1
%2) -2 -3  3 -2 -2
%3)  2  1  1 -3 -2
%4)  1 -3  1 -3 18
%5)  3 -3  1  3  6
%6)  1 -2  4 -2

syms s t Y  % s ve t domainlerini tan?ml? hale getirmek i?in

denklem='D(D(y))(t)+2*D(y)(t)-4*y(t)=3*exp(t)'; %denklemimizin ilk de?ersiz hali

laplace_ilk=laplace(denklem,t,s); %denklemin ilk de?ersiz halinin laplace'si

laplace_son=subs(laplace_ilk,{'laplace(y(t),t,s)','y(0)','D(y)(0)'},{Y,2,1}); %ilk de?er bilgilerinin eklenmesi
Y=solve(laplace_son,Y); % Y fonksiyonunun yaln?z b?rak?lmas?

y=ilaplace(Y,s,t) % Y'nin ters laplace'si 