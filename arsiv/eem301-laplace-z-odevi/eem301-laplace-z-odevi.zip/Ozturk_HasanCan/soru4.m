clear all
close all
clc

%1)  2 -4  3  2  1
%2) -2 -3  3 -2 -2
%3)  2  1  1 -3 -2
%4)  1 -3  1 -3 18
%5)  3 -3  1  3  6
%6)  1 -2  4 -2

syms s t Y % s ve t domainlerini tan?ml? hale getirmek i?in

F= (s-3)/s*(s^2-3*s+18);
f= ilaplace(F);

disp(f);