clear all
close all
clc

%1)  2 -4  3  2  1
%2) -2 -3  3 -2 -2
%3)  2  1  1 -3 -2
%4)  1 -3  1 -3 18
%5)  3 -3  1  3  6
%6)  1 -2  4 -2

syms z n Y

% y(n)-2y(n-1)+3y(n-2)=x(n)  , y(-1)=5  , y(-2)=2  , x(n)=(1/2)^(n)u(n) 


a=1;     % y(n)'in katsay?s?
b=3/2;    % y(n-1)'in katsay?s?
c=-3/2;     % y(n-2)'nin katsay?s?
d=1;     % x(n)'in katsay?s?
e= 1/4;  % x(n)'i olu?turan ?stel terimin taban?ndaki sabit

y_1= 3 ;   % y(-1)'in tan?mlanmas?
y_2= 6 ;   % y(-2)'nin tan?mlanmas?

X=ztrans(e^n*heaviside(n));     % x(n) in z domaine d?n??t?r?lmesi

Y1=(z^(-1)*Y)+y_1;              % y(n-1)'in z domaine d?n??t?r?lmesi

Y2=(z^(-2)*Y+(z^(-1)*y_1)+y_2); % y(n-2)'in z domaine d?n??t?r?lmesi
 
f= a*Y+b*Y1+c*Y2-d*X;           % denklemin olu?turulmas?

sol=solve(f,Y);                 % denklemde Y(z)'nin yanl?z b?rak?lmas?

pretty(sol);                     % yaln?z b?rak?lan Y(z)nin daha sade yaz?lmas?

yn=iztrans(sol);                 % ters z d?n???m? ile y[n]'in bulunmas?

disp(yn);

