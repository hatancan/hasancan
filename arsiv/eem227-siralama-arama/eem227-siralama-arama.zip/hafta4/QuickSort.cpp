#include<iomanip>
/*karakter dizisini quick sort ile siralar */
#include<stdio.h>
#include<string.h>
void quick_str(char dizi[][10],int say);
void qs_string(char dizi[][10],int sol,int sag);
char str[][10]={"tulay","pelin","aysu","can","beril","ogul"};
int main(void)
{

int i;
quick_str(str,sizeof(str));
printf("siralanmis dizi\n");
for (i=0;i<sizeof(str);i++)
 printf("%s\n",str[i]);
system("pause");
return 0;

}

void quick_str(char dizi[][10],int say)
{
qs_string(dizi,0,say-1);
}
void qs_string(char dizi[][10],int sol,int sag)
{
int i,j;
char *x;
char yedek[10];
i=sol;j=sag;
x=dizi[(sol+sag)/2];
do {
  while((strcmp(dizi[i],x)< 0) && (i< sag))i++;
  while((strcmp(dizi[j],x)> 0) && (j > sol))j--;
     if(i <= j)
       {
	strcpy( yedek,dizi[i]);
	strcpy( dizi[i],dizi[j]);
	strcpy( dizi[j],yedek);
        i++; j--;
       }
    }while(i <= j);
    if(sol < j) qs_string(dizi,sol,j);
    if(i < sag) qs_string(dizi,i,sag);
}
