// Sequential Search...
//-----------------------
#include <iostream>
#include <iomanip> // setw fonksiyonu i�in 
#include <vector>

using namespace std;

template <class T>
int seqSearch (vector<T>& dizi,int ilk, int son, int aranan)
{
	int i=ilk;
	while(i != son && dizi[i] != aranan)
	i++;

	return i;
}
	
//------------------------------ main -----------------------------------

int main ()
{
    vector<int> D;
    int x;
	
    // 20 elemanl�, rasgele bir katar olu�turuluyor.

	for (int i = 0; i < 10; i ++) 
     D.push_back (rand () % 150);
	
	for(int i=0;i<D.size();i++)
	cout<<setw(4)<<'['<<i<<']'<<setw(5)<<D[i]<<"\n";
	cout<<"Aranacak Deger ? ";
	cin>>x;
	cout<<"Indis No : "<< seqSearch(D,0,D.size(),x)<<endl;
    system("pause");
	return 0;
} 
/*
�rnek �al��ma : Random 10 de�eri vekt�re ekler
-----------------------------------------------
   [0]   41
   [1]   17
   [2]   34
   [3]  100
   [4]  119
   [5]  124
   [6]   78
   [7]  108
   [8]  112
   [9]   14
Aranacak Deger ? 119
Indis No : 4
Press any key to continue . . .

Not: Bulamaz ise Indis No: 10 der !!!
*/
