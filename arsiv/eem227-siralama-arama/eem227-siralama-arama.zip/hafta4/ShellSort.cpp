
#include <stdio.h>
/* shell sort algoritmasi ile buyukten kucuge siralama yapar */
int main (void)
{
int a[10],i,j,n,orta,k,yedek;
printf(" dizinin eleman sayisini < 10 giriniz \n");
scanf("%d",&n);
printf("Diziyi  giriniz\n");
for(i=0;i<n;i++)
scanf("%d",&a[i]);
orta=(n-1)/2;
     while(orta >0){
	  for(i=orta+1;i<n;i++){
              j=i-orta;
	      while(j>0){
                k=(j-1)+orta;
	        if(a[j-1]>=a[k]) j=0;
	        else {
		yedek=a[j-1];
		a[j-1]=a[k];
                a[k]=yedek;
                j=j-orta;
	       }
	    }
	 }
    orta=orta/2;
    }
printf("Siralanmis Dizi\n");
for(i=0;i<n;i++)
printf("%3d",a[i]);
scanf("%d",&n);
return 0;
}
