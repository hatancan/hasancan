
# include <stdio.h>
/* merge algoritmasi ile iki sirali diziyi birlestirir */
// Not Her iki girilen dizide kendi i�inde s�ral� olmal�d�r...

int main (void)
{
int a[10],b[10],d[20];
int n,m,i,j,l;
printf("ilk dizinin boyutu < 10 ?\n");
scanf("%d",&n);
printf("ikinci  dizinin boyutu <10 ?\n");
scanf("%d",&m);
printf(" birinci dizinin elemanlari\n ");
for(i=0;i<n;i++)
scanf("%d",&a[i]);
printf(" ikinci dizinin elemanlari\n ");
for(i=0;i<m;i++)
scanf("%d",&b[i]);
a[n]=b[m-1];
b[m]=a[n-1];
i=0;
j=0;
for(l=0;l<n+m;l++)
   if(a[i]<=b[j]){
      d[l]=a[i];
      i++;
      }
      else
      {
      d[l]=b[j];
      j++;
      }
//clrscr();
printf(" birlestirilmis dizi \n\n" );
for(i=0;i<n+m;i++)
printf("%5d",d[i]);

scanf("%d",&n); // ekran� durdurmak i�in
return 0;;
}
