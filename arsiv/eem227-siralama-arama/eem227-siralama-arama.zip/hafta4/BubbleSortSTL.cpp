#include <iostream>
#include<vector>

using namespace std;
 
template <typename T>
T bubbleSort (vector<T>&dizi)
{
	int temp;
	for (int i = dizi.size(); i > 2; i --)
	{	 
		for (int j = 0; j < i - 1; j ++)
		{
			if (dizi[j] > dizi[j + 1])
			{
				temp = dizi[j + 1];
				dizi[j + 1] = dizi[j];
				dizi[j] = temp;
			}
		}
	}
	
	for(int k=0;k<10;k++)
	cout<<dizi[k]<<" ";
	cout<<endl;

}
	
//------------------------------ main -----------------------------------

int main ()
{
    vector<int> D;
    for(int i=10;i>0;i++)
    D.push_back(i);
   	
       for(int k=0;k<10;k++)
	cout<<D[k]<<" ";
	cout<<endl;
	
    bubbleSort(D);
    
    system("pause");
	return 0;
}
	   


