#include<iomanip>
#include<stdio.h>
/* selection sort ile diziyi kucukten buyuye dogru siralar */
int main(void)
{
int d[10];
int i,j,n,min,yer;
printf(" dizinin eleman sayisini < 10 giriniz \n");
scanf("%d",&n);
printf(" dizi elemanlarini giriniz \n");
for (i=0;i<n;i++)
  scanf("%d",&d[i]);
for(i=0;i<n-1;i++){
  yer=i;
  min=d[i];
    for(j=i+1;j<n;j++)
       if(d[j]<min)
       {
	 yer=j;
	 min=d[j];
		 }
    d[yer]=d[i];
    d[i]=min;
    }
 printf(" sirali dizi \n\n");
 for(i=0;i<n;i++)
      printf("%4d",d[i]);
system("pause");
return 0;
 }

