// Binary  Search...
// S�ral� dizi i�erisinde aranan de�eri bulma kodu
// ------
 

#include <iostream>
#include <iomanip> // setw fonksiyonu i�in 
#include <vector>

using namespace std;

template <class T>
int binSearch (vector<T>& dizi,int ilk, int son, int aranan)
{
	
	int orta; // orta noktan�n indeksi
	T ortadeger; // dizi[orta] ye atanacak de�er
	int origSon=son; // orjinal son de�eri sakla
	
	while(ilk < son)
	{
    orta=(ilk+son)/2;
	ortadeger=dizi[orta];

	if(aranan==ortadeger)
	   return orta;
    else if ( aranan < ortadeger)
       {
       son=orta; // alt alt listede arama yap
       binSearch (dizi,ilk,son,aranan);
       }
    if ( aranan > ortadeger)
       {
       ilk=orta+1; // �st alt listede arama yap
       binSearch (dizi,ilk,son,aranan);
       }
    }
    return origSon; // aranan bulunamad�...  

}
	
//------------------------------ main -----------------------------------

int main ()
{
    vector<int> D;
    int x;
	
    // 20 elemanl�, s�ral� bir dizi olu�turuluyor.

	for (int i = 0; i < 20; i ++) 
     D.push_back (i*10-3);
	
	for(int i=0;i<D.size();i++)
	cout<<setw(4)<<'['<<i<<']'<<setw(6)<<D[i]<<"\n";
	cout<<"Aranacak Deger ? ";
	cin>>x;
	cout<<"Indis No : "<< binSearch(D,0,D.size(),x)<<endl;
    system("pause");
	return 0;
} 
/*
�rnek �al��ma : Random 10 de�eri vekt�re ekler
-----------------------------------------------
   [0]    -3
   [1]     7
   [2]    17
   [3]    27
   [4]    37
   [5]    47
   [6]    57
   [7]    67
   [8]    77
   [9]    87
   [10]    97
   [11]   107
   [12]   117
   [13]   127
   [14]   137
   [15]   147
   [16]   157
   [17]   167
   [18]   177
   [19]   187
Aranacak Deger ? 127
Indis No : 13
Press any key to continue . . .

Not: Bulamaz ise Indis No: 20 der !!!
*/
