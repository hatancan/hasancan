#include <iostream>
//#include <vector>
using namespace std;

//---------------------------- quickSort --------------------------------
//
// Ama�	: Verilen de�erleri, k���kten b�y��e do�ru s�raya koymak
//
// GirSon� parametresi : De�erlerin yaz�l� oldu�u vekt�r
//
//-----------------------------------------------------------------------

//template <class T>


//---------------------------- quickSort --------------------------------
//
// Giri� parametreleri : De�erlerin yaz�l� oldu�u vekt�r. Bu vekt�r�n
//		       	 hangi aral��� ile ilgilendi�imizi g�steren
//		       	 sol ve sag isimli iki de�i�ken. Bu aral�k
//		       	 i�erisinden bir pivot se�ilip, bu aral�k da
//		       	 iki par�aya b�l�necek.
//
//-----------------------------------------------------------------------

//template <class T>
void quickSort (int dizi[], int sol, int sag)
{
	int x = sol;
	int y = sag;
	int pivot = dizi[x]; // Verilen aral���n ilk eleman� pivot olarak se�iliyor
  
	// Pivottan b�y�k elemanlar�n sa� tarafa, pivottan k���k
	// elemanlar�n ise sol tarafa al�nmas� sa�lan�yor. En sonda
	// ise pivot, olu�an yeni iki gurubun ortas�na yerle�ecek.
	while (x < y)
	{
		// Sa�da pivottan k���k ilk eleman� bul
		while ((dizi[y] >= pivot) && (x < y)) y --;
    
		// Bu eleman� sola al
		if (x != y)
		{
			dizi[x] = dizi[y];
			x ++;
		}
    
		// Solda pivottan b�y�k ilk eleman� bul
		while ((dizi[x] <= pivot) && (x < y)) x ++;
    
		// bu eleman� sa�a al
		if (x != y)
		{
			dizi[y] = dizi[x];
			y --;
		}
	}
  
	dizi[x] = pivot; // pivot buraya ta��nd�

	int pivotIndis = x; // pivotun yeni yeri

	// Pivottan k���k elemanlar [sol,pivotIndis-1] aral���na yerle�ti.
	// Pivottan b�y�k elemanlar [pivotIndis+1,sag] aral���na yerle�ti.
	// Her iki aral�k de�eri i�in, e�er aral���n boyu birden b�y�kse, 
	// quickSort fonksiyonu �zyinelemeli olarak yeniden �a��r�l�yor
  
	if (sol + 1 < pivotIndis)
		quickSort (dizi, sol, pivotIndis - 1); // pivotun sol taraf�
  
	if (sag - 1 > pivotIndis)
		quickSort (dizi, pivotIndis+1, sag); // pivotun sa� taraf�
}


int main ()
{
	int d[20];

	// 20 elemanl�, rasgele bir katar olu�turuluyor.
	for (int i = 0; i < 20; i ++) 
    d[i]=(rand () % 1000);
	quickSort (d,0,20);

	for (int i = 0; i < 20; i ++)
    cout<<d[i]<<" ";
    cout<<endl;
    system("pause");
	return 0;
}
	   




