
#include <iostream>
#include <vector>
using namespace std;
	
//--------------------------- selectionSort -----------------------------
//
// Ama�	: Verilen de�erlerin, k���kten b�y��e s�raya koymak
//
// Giri� parametresi : De�erlerin yaz�l� oldu�u vekt�r
//
// D�n�� de�eri : void
//
// Fonksiyonda s�ralama i�lemi, Selection Sort algoritmas� ile
// ger�eklenmi�tir.
//
//-----------------------------------------------------------------------

template <class T>
T selectionSort (vector<T>& num)
{ int minIndex;
	for (int i = 0; i < num.size () - 1; i ++)
	{
     minIndex = i;
		for (int j = i + 1; j < num.size (); j ++)
			if (num [minIndex] > num [j]) 
              minIndex = j;
    		if (minIndex != i)
	    	{
		    	T temp = num[i]; 
		    	num[i] = num[minIndex];
		    	num[minIndex] = temp;
	    	}
	for(int k=0;k<10;k++)
	cout<<num[k];
	cout<<endl;
    }
}
	
//------------------------------ main -----------------------------------

int main ()
{
	vector<int> D;
	// 20 elemanl�, rasgele bir katar olu�turuluyor.

    for(int j=10;j>0;j--)
	D.push_back(j);
	selectionSort(D);
	
 
    system("pause");
	return 0;
} 

