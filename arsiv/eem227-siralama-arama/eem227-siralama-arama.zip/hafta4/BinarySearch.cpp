#include <stdio.h>
/* binary search algoritmasi ile sirali dizide arama yapar */
int main (void)
{
int a[10],i,bas,son,x,orta,bul,n;
printf(" Tam sayi dizisinin eleman sayisini < 10 giriniz \n");
scanf("%d",&n);
printf("Dizi elemanlarini  giriniz\n");
for(i=0;i<n;i++)
scanf("%d",&a[i]);
printf("\n aranacak sayiyi giriniz\n");
scanf("%d",&x);
     bas=0;son=n;
     bul=0;
     while(bas <= son && bul==0)
     {
	    orta=(bas+son)/2;
	  
      if(x==a[orta]) 
         bul=1 ;
	  else if(x>a[orta]) 
         bas=orta+1;
	  else
          son=orta-1;
	  }
     if(x==a[orta]) 
         printf("aranan sayi %3d dizideki indisi:%3d",x,orta);
     else 
         printf("Aranan deger bulunamadi");
scanf("%d",&x); // ekran� durdurma
return 0;
}
