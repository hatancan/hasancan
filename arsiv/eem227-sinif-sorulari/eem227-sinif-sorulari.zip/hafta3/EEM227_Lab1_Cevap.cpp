#include <iostream>
using namespace std;
#define TRUE  1
#define FALSE 0

class rasyonel
{
private :
  long pay;
  long payda;
  long payilk;
  long paydailk;
  void indirge(void);
  
public :
       
//void topla(rasyonel);
  void carp(rasyonel);
  void bol(rasyonel);
   int esit(rasyonel);
  void degerata(long, long);
  void yazdir(void);
  
};

/*
void rasyonel::topla(rasyonel r)
{
  int k, tpay, tpayda;
  rasyonel rnl;

  // Her iki rasyonel say�n�n en k���k terimlerine indirgenmesi
  indirge();
  r.indirge();

  rnl.degerata(payda, r.payda);
  rnl.indirge();
  k=rnl.payda;

  tpayda = payda * k;
  tpay = pay*k + r.pay*(tpayda/r.payda);
  cout<<tpayda,tpay;
  rnl.degerata(tpay, tpayda);
  rnl.indirge();

}
*/


void rasyonel::bol(rasyonel r)
{
  rasyonel rnl;
  rnl.degerata(r.payda, r.pay);
  //cout<<"Bolme Sonucu : "<<endl;
  carp(rnl);
}


void rasyonel::carp(rasyonel r)
{
  rasyonel rnl, rnl1, rnl2;
  int py, pyd;
  // Her iki rasyonel say�n�n en k���k terimlerine indirgenmesi
  indirge();
  r.indirge();

  rnl1.degerata(pay, r.payda);
  rnl.indirge();
  rnl2.degerata(r.pay, payda);
  rnl2.indirge();

  py  = rnl1.pay * rnl2.pay;
  pyd = rnl1.payda * rnl2.payda;
  
  if(pyd==1)
     cout<<"Sonuc : "<<py;
  else
     cout<<"Sonuc : "<<py<<"/"<<pyd<<endl;
}


void rasyonel::degerata(long n, long d)
  {
    if(d==0) cout << "Hata! payda 0 olamaz";
    pay = n; 
    payda = d; 
    payilk=n; 
    paydailk=d;
    indirge();
  };
  
 void rasyonel::yazdir(void) {
       cout<<"\nGirilen degerler:\n" ;
       cout<<"------------------";
       cout<<"\nPay : "<<payilk<<endl;
       cout<<"Payda : "<<paydailk<<endl;
     //  cout<<"\n \n"<<endl;
       if(payda==1)
       cout<<"Sadelesmis Hali : "<<pay<<endl;
       else
       cout <<"Sadelesmis Hali : " <<pay << "/" << payda << endl; 
       
       };
void rasyonel::indirge(void)
{
  int a, b, r, sign;
  if (pay==0) payda = 1;
  sign = 1;
  if(pay<0 && payda<0) { pay = -pay; payda = -payda; };
  if(pay<0) { pay = -pay; sign = -1; };
  if(payda<0) { payda = -payda; sign = -1; };
  if(pay>payda) { a=pay; b=payda; } else { a=payda; b=pay; };
  while(b!=0) { r = a%b; a=b; b=r; };
  pay = sign*pay / a;
  payda = payda / a;
  
}
  int payilk,paydailk; // Global tan�mlad�k...
  
  int rasyonel::esit(rasyonel r)
{
  // Her iki rasyonel say�n�n en k���k terimlerine indirgenmesi
  indirge();
  r.indirge();
  if (pay==r.pay && payda==r.payda) return TRUE; else return FALSE;
}


int main()
{
  rasyonel r1;  
  cout<<"1.Sayinin Pay Degeri : ? ";
  cin>>payilk;
  cout<<"\n1.Sayinin Payda Degeri : ?";
  cin>>paydailk;
  r1.degerata(payilk,paydailk);
  r1.yazdir();
  
  
  rasyonel r2;
  cout<<"\n2.Sayinin Pay Degeri : ? ";
  cin>>payilk;
  cout<<"\n2.Sayinin Payda Degeri : ?";
  cin>>paydailk;
  r2.degerata(payilk,paydailk);
  r2.yazdir();  

  cout<<"\n Sayilar esitmi (0=H, 1=E)? : "<<r1.esit(r2);
  cout<<"\n";
  cout<<"\n Carpma Sonucu: "<<endl;
  r1.carp(r2);
  cout<<"\n Bolme Sonucu: "<<endl;
  r1.bol(r2);
/*
  cout<<"\n\n Toplama Sonucu: ";
  r1.topla(r2);
*/  
  cout<<"\n \n";
  system("pause");
return 0;
}

