#include<iostream>
#include<stdlib.h>
using std::cin;
using std::cout;
using std::endl;
using std::istream;
using std::ostream;
class Karmasik
{
      friend istream& operator>>(istream& oku,Karmasik& nesne);
      friend ostream& operator<<(ostream& yaz,Karmasik& nesne);
      private:
              int gercel,sanal;
      public:
             Karmasik(int a=0,int b=0)
             {
                   gercel=a;
                   sanal=b;
             }       
             int retsanal()
             {
                 return sanal;
             }
             int retgercel()
             {
                 return gercel;
             }
             Karmasik operator+(Karmasik& nesne)
             {
                       Karmasik top;
                       top.gercel=gercel+nesne.retgercel();
                       top.sanal=sanal+nesne.retsanal();
                       return top;
             }
             Karmasik operator-(Karmasik& nesne)
             {
                       Karmasik cik;
                       cik.gercel=gercel-nesne.retgercel();
                       cik.sanal=sanal-nesne.retsanal();
                       return cik;
             }
             Karmasik operator*(Karmasik& nesne)
             {
                       Karmasik carp;
                       carp.gercel=(gercel*nesne.retgercel())-(sanal*nesne.retsanal());
                       carp.sanal=(gercel*nesne.retsanal())+(sanal*nesne.retgercel());
                       return carp;
             }
};
istream&operator>>(istream& oku,Karmasik& nesne)
      {
             oku>>nesne.gercel>>nesne.sanal;;
      }
ostream&operator<<(ostream& yaz,Karmasik& nesne)
      {
             if(nesne.sanal>=0)
             yaz<<nesne.gercel<<"+"<<nesne.sanal<<"i";
             else
             yaz<<nesne.gercel<<nesne.sanal<<"i"; 
      
      }      
      
int main()
{
    Karmasik a,b,c,d,s,f;
    cout<<"Birinci Sayiyi Gir"<<endl;
    cin>>a;
    cout<<"Ikinci Sayiyi Gir"<<endl;
    cin>>b;
    cout<<"Ucuncu Sayiyi Gir"<<endl;
    cin>>c;
    d=a+b;
    d=d+c;
    cout<<"Toplam:"; cout<<d; cout<<endl;
    s=b+c;
    d=a-s;
    cout<<"Fark:"; cout<<d; cout<<endl;
    s=a*b;
    d=b*c;
    f=s+d;
    cout<<"Carpim:"; cout<<f; cout<<endl;
    system("PAUSE");
    return 0;
}
    
