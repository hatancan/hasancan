%soru 177 b.

clc
clear all
close all

omega=[0:511]*pi/256;   %de�i�kenler tan�mlan�yor
unitcirc=exp(i*omega); 

num=[1 0 0];%transfer fonksiyonunu tan�mlamaya ba�lad�k
den=[1 -0.9 0.81];
ps1=roots(den)
sys=tf(num,den,-1)


polevectors1=ones(2,1)*unitcirc-ps1*ones(1,512);
polelength1=abs(polevectors1)
poleangle1=atan2(imag(polevectors1),real(polevectors1))


%poleangle2=angle(polevectors1)
%poleangle son sat�rdaki gibi de hesaplanabilirdi

%detayl� a��klamalar pazartesi g�n� elden teslim edilecek ka��tta olacak

% 2. soru (laplace sorusu) tamamen matematiksel i�lem oldu�undan yaz�l�
% olarak teslim edece�im
