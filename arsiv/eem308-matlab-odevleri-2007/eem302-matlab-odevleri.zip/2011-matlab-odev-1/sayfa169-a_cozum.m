clc
clear all

display ('1. MATLAB �devi 169.a')

x=[1]
y=[1 2]
ps=roots(x)
sz=roots(y)
h= tf(x,y)
display('Nedensel bir sistemin transfer fonksiyonunu, yazilan kodlar ile belirtilmistir. Nedensel olmayan sistemlerde -y(-t) =y(t) oldugundan denklemi,  -dy(-t)/dt - 2y(-t)= -x(-t) haline gelir. ')

 
r=[-1]
w=[-1 -2]
ps2=roots(r)
sz2=roots(w)
h2=tf(r,w)
