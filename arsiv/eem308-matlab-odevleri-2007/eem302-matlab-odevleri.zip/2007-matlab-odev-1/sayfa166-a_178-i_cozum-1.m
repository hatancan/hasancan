display('-----------------------------')
display ('----- 166.(a) -----')
display('-----------------------------')

b1=[4];
a1=[1 2 17];
zeros=roots(b1);
poles=roots(a1);

disp('166 (a) i�in');
disp('Kutuplar:');
disp(poles);

figure (1);
plot(real(zeros),imag(zeros),'o');
hold on
plot(real(poles),imag(poles),'x');
grid
title('Soru : 166 (a)');
xlabel('Re');
ylabel('Im');
axis([-5 5 -5 5]);
display('Buradan g�rd���m�z gibi; 2 adet kutup bulunmu�tur.')

%--------------------------------------------

display('-----------------------------')
display ('----- 178.(i) -----')
display('-----------------------------')

b=[0.25 -(sqrt(3)/2) 1];
a=[1 -(sqrt(3)/2) 0.25];
zs=roots(b);
ps=roots(a);

disp('Soru : 178 (i) i�in');
disp('S�f�rlar:');
disp(zs);
disp('Kutuplar:');
disp(ps);

figure (2);
plot(real(zs),imag(zs),'o');
hold on
plot(real(ps),imag(ps),'x');
rsmak('circle');
grid
title('178 (i)');
xlabel('Re');
ylabel('Im');
axis([-5 5 -5 5]);

display('Buradan g�rd���m�z gibi; 2 adet kutup ve 2 adet s�f�r bulunmu�tur.')
