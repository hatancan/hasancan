package com.deneme39;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;



public class MainActivity extends Activity implements OnItemClickListener {

    private Button ledonbtn;
    private Button ledoffbtn;
    private EditText editText;
    private TextView text1;
    OutputStream outstream;
    ArrayAdapter<String> adaptorlist;
    ListView liste;
    BluetoothAdapter blt;
    Set<BluetoothDevice> arraydevice;
    ArrayList<String> eslesen;
    ArrayList<BluetoothDevice> aygitlar;
    public static final UUID mmuuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    protected static final int baglanti = 0;
    protected static final int mesajoku = 1;
    IntentFilter filtre;
    BroadcastReceiver receiver;
    Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            // TODO Auto-generated method stub
            super.handleMessage(msg);
            switch(msg.what){
                case baglanti:

                    ConnectedThread connectedThread = new ConnectedThread((BluetoothSocket)msg.obj);
                    Toast.makeText(getApplicationContext(), "Baglandı", 0).show();
                    String s = "successfully connected";
                    break;
                case mesajoku:
                    byte[] readBuf = (byte[])msg.obj;
                    String string = new String(readBuf);
                    Toast.makeText(getApplicationContext(), string, 0).show();
                    break;
            }
        }
    };
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text1=(TextView) findViewById(R.id.liste);
        editText=(EditText)findViewById(R.id.editText);
        liste=(ListView)findViewById(R.id.listem);
        liste.setOnItemClickListener(this);
        adaptorlist= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,0);
        liste.setAdapter(adaptorlist);
        blt = BluetoothAdapter.getDefaultAdapter();
        eslesen = new ArrayList<String>();
        filtre = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        aygitlar = new ArrayList<BluetoothDevice>();

        receiver = new BroadcastReceiver(){
            @Override
            public void onReceive(Context context, Intent intent) {
                // TODO Auto-generated method stub
                String action = intent.getAction();

                if(BluetoothDevice.ACTION_FOUND.equals(action)){

                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    aygitlar.add(device);
                    String s = "";

                    for(int a = 0; a < eslesen.size(); a++){
                        if(device.getName().equals(eslesen.get(a))){

                            s = "(Eslesti)";
                            break;
                        }
                    }

                    adaptorlist.add(device.getName()+""+s+""+"\n"+device.getAddress());
                }

                else if(BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)){
                    if(blt.getState() == blt.STATE_OFF){
                        bltac();
                    }
                }

            }


        };

        registerReceiver(receiver, filtre);
        filtre = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(receiver, filtre);



        if(blt==null){
            Toast.makeText(getApplicationContext(), "Bluetooth ayg�tlar� bulunamad�", 0).show();
            text1.setText("Bluetooth aygiti yok");
            finish();
        }
        else{
            if(!blt.isEnabled()){
                bltac();
            }

            getPairedDevices();
            startDiscovery();

            ledonbtn=(Button) findViewById(R.id.ledon);
            ledonbtn.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    try {
                        ledon();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block

                    }
                }
            });

            ledoffbtn=(Button) findViewById(R.id.ledoff);
            ledoffbtn.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    try {
                        ledoff();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block

                    }
                }
            });
        }


    }





    private void startDiscovery() {
        // TODO Auto-generated method stub
        blt.cancelDiscovery();
        blt.startDiscovery();

    }
    private void bltac() {
        // TODO Auto-generated method stub
        Intent intent =new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(intent, 1);
    }
    private void getPairedDevices() {
        // TODO Auto-generated method stub
        arraydevice = blt.getBondedDevices();
        if(arraydevice.size()>0){
            for(BluetoothDevice device:arraydevice){
                eslesen.add(device.getName());

            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_CANCELED){
            Toast.makeText(getApplicationContext(), "Kontrol i�lemi i�in bluetoothun a��k olmas� gerekir", Toast.LENGTH_SHORT).show();
            finish();
        }
    }


    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                            long arg3) {
        // TODO Auto-generated method stub

        if(blt.isDiscovering()){
            blt.cancelDiscovery();
        }
        if(adaptorlist.getItem(arg2).contains("Eslesti")){

            BluetoothDevice selectedDevice = aygitlar.get(arg2);
            ConnectThread connect = new ConnectThread(selectedDevice);
            connect.start();

        }
        else{
            Toast.makeText(getApplicationContext(), "Cihazlar e�le�medi", 0).show();
            text1.setText("Cihazlar eşleşmedi");
        }
    }

    private class ConnectThread extends Thread {

        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;

        public ConnectThread(BluetoothDevice device) {

            BluetoothSocket tmp = null;
            mmDevice = device;

            try {

                tmp = device.createRfcommSocketToServiceRecord(mmuuid);
            } catch (IOException e) {

            }
            mmSocket = tmp;
        }

        public void run() {

            blt.cancelDiscovery();

            try {

                mmSocket.connect();

            } catch (IOException connectException) {

                try {
                    mmSocket.close();
                } catch (IOException closeException) { }
                return;
            }

            mHandler.obtainMessage(baglanti, mmSocket).sendToTarget();
        }


        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) { }
        }
    }

    private class ConnectedThread extends Thread {

        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;

        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            mmInStream = tmpIn;
            outstream = tmpOut;
        }

        public void run() {
            byte[] buffer;
            int bytes;


            while (true) {
                try {

                    buffer = new byte[1024];
                    bytes = mmInStream.read(buffer);

                    mHandler.obtainMessage(mesajoku, bytes, -1, buffer)
                            .sendToTarget();

                } catch (IOException e) {
                    break;
                }
            }
        }


        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) { }
        }
    }

    public void ledon() throws IOException {
        outstream.write("1".getBytes());
    }

    public void ledoff() throws IOException {
        outstream.write("2".getBytes());
    }
}
