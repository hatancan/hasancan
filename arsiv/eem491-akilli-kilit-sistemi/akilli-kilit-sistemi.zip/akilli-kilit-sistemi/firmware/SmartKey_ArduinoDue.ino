#define ag_ismi "wireless"
#define ag_sifresi "********"
#define LED 13
#define LED1 8
#define bekleme_suresi 30000

unsigned long simdikizaman = 0, oncekizaman = 0;
char sayac_acik = 0;
int fark = 0;

void setup()
{
  // mySerial.begin(115200);   //bluethoot icin
  Serial1.begin(115200); //Seriport'u açıyoruz. Güncellediğimiz
  Serial2.begin(9600); //Seriport'u açıyoruz. Güncellediğimiz
  Serial3.begin(115200);

  //ESP modülünün baudRate değeri 115200 olduğu için bizde Seriport'u 115200 şeklinde seçiyoruz
  Serial1.println("AT"); //ESP modülümüz ile bağlantı kurulup kurulmadığını kontrol ediyoruz.
  pinMode(LED1, OUTPUT);
  pinMode(LED, OUTPUT);
  delay(3000); //ESP ile iletişim için 3 saniye bekliyoruz.

  if (Serial1.find("OK")) {       //esp modülü ile bağlantıyı kurabilmişsek modül "AT" komutuna "OK" komutu ile geri dönüş yapıyor.
    Serial1.println("AT+CWMODE=1"); //esp modülümüzün WiFi modunu STA şekline getiriyoruz. Bu mod ile modülümüz başka ağlara bağlanabilecek.
    digitalWrite(LED, HIGH);
    delay(2000);
    String baglantiKomutu = String("AT+CWJAP_CUR=\"") + ag_ismi + "\",\"" + ag_sifresi + "\"";
    Serial1.println(baglantiKomutu);
    delay(5000);
    if (Serial1.find("OK"))
      digitalWrite(LED, LOW);
  }

  Serial1.println("AT+CWDHCP_CUR=1,0");    //DHCP yi kapat
  delay(500);
  Serial1.println("AT+CIPSTA_CUR=\"192.168.1.20\",\"192.168.1.1\",\"255.255.255.0\"");   //static IP ata
  delay(500);

  Serial1.println("AT+CIPMUX=1");
  delay(1000);
  Serial1.println("AT+CIPSERVER=1,80");
  delay(1000);
  Serial1.println("AT+CIPCLOSE=0");
}


void loop() {
  if (Serial1.available() > 0) {
    if (Serial1.find("+IPD,")) {
      String metin = "<head> Hello World </head>";
      metin += "<br><a href=\" ?pin=on\"><button type='button'>ON</button></a>";
      metin += "<br><a href=\" ?pin=off\"><button type='button'>OFF</button></a>";
      String cipsend = "AT+CIPSEND=";
      cipsend += "0";
      cipsend += ",";
      cipsend += metin.length();
      cipsend += "\r\n";
      Serial1.print(cipsend);
      delay(500);
      Serial1.println(metin);
      led_yakma();
      Serial1.println("AT+CIPCLOSE=0");

    }
  }

  if (Serial2.available() > 0) {
    kilit_kontrol_bt();
  }

  if (sayac_acik && millis() - oncekizaman > bekleme_suresi) {
    sayac_acik = 0;
    digitalWrite(LED, LOW);
  }

  if (sayac_acik && millis() - oncekizaman <= bekleme_suresi) {
    fark = (millis () - oncekizaman) / 1000;
    Serial2.print(fark);
    Serial2.print("\r");
  }
}



void led_yakma() {
  String gelen = "";
  char serialdenokunan;
  int ii = 0;

  while (Serial1.available() > 0) {
    serialdenokunan = Serial1.read();
    gelen += serialdenokunan;
    ii++;
  }
  
  Serial3.println(gelen);

  if ((gelen.indexOf("pin=on") > 1)) { //on butonuna basıldığında server adresinde /?pin=on var ise
    digitalWrite(LED, HIGH);                 //ledi yakar
  }
  if ((gelen.indexOf("pin=off") > 1)) { // off butonuna basıldığında server adresinde /?pin=off var ise
    digitalWrite(LED, LOW);                   //ledi söndürür
  }
}




void kilit_kontrol_bt() {
  String gelenbt = "";
  char serialdenokunanbt;

  while (Serial2.available() > 0) {
    serialdenokunanbt = Serial2.read();
    gelenbt += serialdenokunanbt;

    if (serialdenokunanbt == 't') { //on butonuna basıldığında server adresinde blu=on var ise
      digitalWrite(LED, HIGH);                 //ledi yakar
      oncekizaman = millis();
      sayac_acik = 1;
    }

    if (serialdenokunanbt == 'n') { //on butonuna basıldığında server adresinde blu=on var ise
      digitalWrite(LED, HIGH);                 //ledi yakar
    }

    if (serialdenokunanbt == 'f') { // off butonuna basıldığında server adresinde blu=off var ise
      digitalWrite(LED, LOW);                   //ledi söndürür
      sayac_acik = 0;
    }

  }

  Serial3.print(gelenbt);

  /*  if ((gelenbt.indexOf("on") > 1)) { //on butonuna basıldığında server adresinde blu=on var ise
      digitalWrite(LED, HIGH);                 //ledi yakar
      oncekizaman = millis();
      sayac_acik = 1;
      Serial3.print("ok");
    }

  if ((gelenbt.indexOf("off") > 1)) { // off butonuna basıldığında server adresinde blu=off var ise
    digitalWrite(LED, LOW);                   //ledi söndürür
    sayac_acik = 0;
  }
*/
}


