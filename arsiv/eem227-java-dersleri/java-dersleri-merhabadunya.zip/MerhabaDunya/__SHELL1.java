
public class __SHELL1 extends bluej.runtime.Shell {
public static java.lang.Object run() throws Throwable {

int __bluej_param0 = 6;
try {
return makeObj(yildiz.piramid(__bluej_param0)
);}
finally {
}
}}
