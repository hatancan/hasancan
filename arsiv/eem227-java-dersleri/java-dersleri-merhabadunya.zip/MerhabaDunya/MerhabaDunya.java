
public class MerhabaDunya
{
    public static void main(){
        System.out.println("Merhaba Dünya");
    }
}
