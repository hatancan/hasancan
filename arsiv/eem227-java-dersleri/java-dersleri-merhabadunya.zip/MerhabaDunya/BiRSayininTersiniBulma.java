public class BiRSayininTersiniBulma
{
    public static int tersiniBul(int sayi){
        int ters=0;
        int kontrol=1;
        int sayac=0;
        int basamak=10;
        while(kontrol!=sayi){
            kontrol=sayi%basamak;
            sayac++;
            basamak=basamak*10;
        }
        int basamak1=1;
        int basamak2=10;
        basamak=basamak/100;
        while(sayac!=0){
            ters=ters+((((sayi%basamak2)-(sayi%basamak1))/basamak1)*basamak);
            basamak2=basamak2*10;
            basamak1=basamak1*10;
            basamak=basamak/10;
            sayac--;
        }
        return ters;
    }
    
    public static String SayiyiStringleTersle(String sayi){
        String ters="";
        char[] charDizisi = sayi.toCharArray();
        for (int i =charDizisi.length-1; i>=0; i--){
            char c = charDizisi[i];
            ters=ters+c;
        }
        return ters;
    }
}
