
public class yildiz
{
   public static int piramid(int piramidKenar){
       int pk = piramidKenar;
       int satir;
       int sutun;
       int bosluk = 1;
       int i=0;
       for(satir=0;satir<pk;satir++){
           for (sutun=0; sutun<pk; sutun++){
               System.out.println(" ");
           }
           i=bosluk+i;
           while(bosluk<=i){
               System.out.println("*");
           }
       }
       i=bosluk-i;
       i++;
       System.out.println(" ");
       return pk;
   }
}