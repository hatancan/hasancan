
public class Girilen3SayiEnBuyuk
{
   public static int enBUyukBul (int a, int b, int c){
       int enBuyuk=a;
       if(b>a){
            enBuyuk=b;
       }
       if(c>a && c>b){
           enBuyuk=c;
       }
       return enBuyuk;
   }
}
