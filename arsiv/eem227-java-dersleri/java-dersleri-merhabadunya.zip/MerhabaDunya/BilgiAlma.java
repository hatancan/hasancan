
public class BilgiAlma
{
    public static double DikUcgenAlanBul(double DikKenarA, double DikKenarB){
        double alan = DikKenarA*DikKenarB/2;
        return alan;
    }
}
