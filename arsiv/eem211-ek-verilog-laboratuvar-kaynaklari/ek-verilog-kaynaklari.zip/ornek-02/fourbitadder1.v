`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: [kişisel bilgi çıkarıldı]
//
// Create Date:    14:29:49 11/01/06
// Design Name:    
// Module Name:    fourbitadder1
// Project Name:   
// Target Device:  
// Tool versions:  
// Description:
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////
module fadder (s,co,c,a,b);
	output s,co;
	input c,a,b;
	assign co=(~c & a & b)|(c & ~a & b)|(c & a & ~b)|(a & b & c);
	assign s=(~c & ~a & b)|(~c & a & ~b)|(c & ~a & ~b)|(c & a & b);
endmodule

module fourbitadder1 (LD0,LD1,LD2,LD3,LD4,SW0,SW1,SW2,SW3,SW4,SW5,SW6,SW7,BTN0);
	 output LD0,LD1,LD2,LD3,LD4;
	 input  SW0,SW1,SW2,SW3,SW4,SW5,SW6,SW7,BTN0;
	 wire W1,W2,W3;
	 fadder a1(LD0,W1,BTN0,SW0,SW4);
	 fadder a2(LD1,W2,W1,SW1,SW5);
	 fadder a3(LD2,W3,W2,SW2,SW6);
	 fadder a4(LD3,LD4,W3,SW3,SW7);
endmodule
