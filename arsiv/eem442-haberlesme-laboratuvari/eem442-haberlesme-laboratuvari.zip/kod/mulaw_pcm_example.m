x = audioread('brian.wav');
x = x(1:50000);

[sqnrmu10, aquanmu10, codemu10] = mulaw_pcm(x, 16, 10);
[sqnrmu100, aquanmu100, codemu100] = mulaw_pcm(x, 16, 100);
[sqnrmu255, aquanmu255, codemu255] = mulaw_pcm(x, 16, 255);

subplot(4,1,1)
plot(x);
subplot(4,1,2)
plot(aquanmu10);
subplot(4,1,3)
plot(aquanmu100);
subplot(4,1,4)
plot(aquanmu255);
