function [ y,a ] = mulaw( x, mu )
% mu-law nonkinearity for non-uniform quantization

a = max(abs(x));
y=(log(1+mu*abs(x/a))./log(1+mu)).*sign(x);

end

