function [ sqnr, a_quan, code ] = mulaw_pcm( a, n, mu)
% mulaw non-uniform PCM encoding of a sequence
% a = input sequence
% n = number of quantization levels
% sqnr = output SQNR (in dB)
% a_quan = quantized output before encoding
% code = the encoded output

[y,maximum]=mulaw(a,mu);
[sqnr, y_q, code] = u_pcm(y,n);
a_quan = invmulaw(y_q,mu);
a_quan = maximum*a_quan;
sqnr=20*log10(norm(a)/norm(a-a_quan));

end