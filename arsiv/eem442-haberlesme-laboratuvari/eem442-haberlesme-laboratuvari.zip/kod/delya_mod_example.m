x = audioread('brian.wav');
x = x(1:50000);

[ax_quan, asqnr]=delta_mod(x,1);
[bx_quan, bsqnr]=delta_mod(x,0.1);
[cx_quan, csqnr]=delta_mod(x,0.01);
[dx_quan, dsqnr]=delta_mod(x,0.001);

subplot(5,1,1)
plot(x);
title('�rneklenen sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,2)
plot(ax_quan);
title('Delta=1 i�in �rneklenmi� sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,3)
plot(bx_quan);
title('Delta=0.1 i�in �rneklenmi� sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,4)
plot(cx_quan);
title('Delta=0.01 i�in �rneklenmi� sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,5)
plot(dx_quan);
title('Delta=0.001 i�in �rneklenmi� sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');