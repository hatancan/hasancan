x = audioread('brian.wav');
x = x(1:50000);

[sqnrmu8, aquanmu8, codemu8] = mulaw_pcm(x, 8, 255);
[sqnrmu16, aquanmu16, codemu16] = mulaw_pcm(x, 16, 255);
[sqnrmu32, aquanmu32, codemu32] = mulaw_pcm(x, 32, 255);
[sqnrmu64, aquanmu64, codemu64] = mulaw_pcm(x, 64, 255);

subplot(5,1,1)
plot(x);
title('�rneklenmemi� ses i�areti');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,2)
plot(aquanmu8);
title('Q=8 mu=255 olan ses sinyali');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,3)
plot(aquanmu16);
title('Q=16 mu=255 olan ses sinyali');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,4)
plot(aquanmu32);
title('Q=32 mu=255 olan ses sinyali');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,5)
plot(aquanmu64);
title('Q=64 mu=255 olan ses sinyali');
xlabel('Zaman(s)');
ylabel('Genlik (v)');