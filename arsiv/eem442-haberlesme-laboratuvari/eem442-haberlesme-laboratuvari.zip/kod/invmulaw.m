function x = invmulaw( y, mu )
% inverse mu-law nonlinearity for non-uniform quantization

x = (((1+mu).^(abs(y))-1)./mu).*sign(y);

end