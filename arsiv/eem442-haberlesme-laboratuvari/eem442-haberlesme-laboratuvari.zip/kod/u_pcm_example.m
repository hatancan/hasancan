t = [0:0.01:10];
a = sin(t);

[sqnr8, aquan8, code8] = u_pcm(a,8);
[sqnr16, aquan16, code16] = u_pcm(a,16);
[sqnr32, aquan32, code32] = u_pcm(a,32);
[sqnr64, aquan64, code64] = u_pcm(a,64);

subplot(5,1,1)
plot(t,a);
title('�rneklenen sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,2)
plot(t,aquan8);
title('8 seviyeli kuantalanm�� sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,3)
plot(t,aquan16);
title('16 seviyeli kuantalanm�� sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,4)
plot(t,aquan32);
title('32 seviyeli kuantalanm�� sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');

subplot(5,1,5)
plot(t,aquan64);
title('64 seviyeli kuantalanm�� sinyal');
xlabel('Zaman(s)');
ylabel('Genlik (v)');