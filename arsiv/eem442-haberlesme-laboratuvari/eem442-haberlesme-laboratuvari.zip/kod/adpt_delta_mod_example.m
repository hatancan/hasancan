x = audioread('brian.wav');
x = x(1:50000);

[adpt_X_quan, adpt_sqnr] = adpt_delta_mod(x,3,0.1);
plot(adpt_X_quan);