/*
Soru 5: SIRALI EKLEME SORUSU

  int x[10]={89,17,88,45,26,30,4,25,72,1}; k���kten b�y��e do�ru s�ral� ekleme!
89->NULL
17->89->NULL
17->88->89->NULL
17->45->88->89->NULL
17->26->45->88->89->NULL
17->26->30->45->88->89->NULL
4->17->26->30->45->88->89->NULL
4->17->25->26->30->45->88->89->NULL
4->17->25->26->30->45->72->88->89->NULL
1->4->17->25->26->30->45->72->88->89->NULL
Press any key to continue . . .
*/
#include<iostream>
#include<ctime>   
using namespace std;

template <typename T>
class node
{
private: 
      T nodeValue;      // data held by the node
      node<T> *next;    // next node in the list
public:

 node(const T& item, node<T> *nextNode=NULL)			  
      {
         nodeValue=item;
		 next=nextNode;
	  }

static T LLSiraliEkle(T value,node<T> * &ptr)
{

node<T> *curr=ptr,*pre=ptr,*s;
 
 if( ptr == NULL) // Liste bo� ise ilk nodu heade yerle�tir.
      {
       ptr = new node<T> (value);
       ptr->next = NULL;
      }
 
 else if (ptr->nodeValue >= value) // Ba�a ekle (sola)
     {
       s = new node<T> (value);
       s->next = ptr;
       ptr = s; 
     }  
 
else  
 { 
  while (curr->nodeValue <= value && curr->next!=NULL)
    {
      pre = curr; 
      curr = curr->next;  
     }  
      
   if(curr->next == NULL && curr->nodeValue <= value) // sona ekle
       {
         s = new node<T> (value);
         s->next = NULL;
         curr->next = s; 
       }
       
   else  // araya ekle
         {
          s = new node<T> (value);
          pre->next = s;
          s->next = curr;
         }      
  
 } // ELSE
}

static T printList(node<T> *ptr)
      {

        while (ptr->next != NULL) // Araya ok koymak i�in bu �ekilde yapt�k...
        {
         cout << ptr->nodeValue<<"->" ;
         ptr = ptr->next;
        }
         cout<<ptr->nodeValue<<"->NULL" ;
           cout << endl;
       }
       
static T node<T>::ListedenSil(node<T>* &ptr, T deger)
  {
  node<T> * curr, * pre;
   pre = curr = ptr;
    
    while(curr->nodeValue != deger && curr->next!=NULL)
     {
        pre = curr;
       curr = curr->next;
     }
     
   if(curr == ptr) // Silinecek de�er head de bulunduysa
   {
    ptr = ptr -> next; // head i �tele
    delete curr;
   }
   
   else if(curr->nodeValue == deger) // head d���nda bir yerde ise
    {  pre->next = curr->next;
       delete curr;
       cout<<"Silme islemi basarili"<<endl;
    }
    else
       cout<<"Silinecek deger listede bulunamadi"<<endl;
  }
  
};
 

int main()
{
//  int x[]={89,17,88,45,26,30,4,25,72,1};
  int SilinecekDeger;
  int adet,deger;
  
 node<int> *head=NULL;

 srand(time(NULL));
 cout<<"Kac eleman listeye eklenecek ? ";
 cin>>adet;
 
 for(int i=0; i<adet; i++)
 {  
    cout<<"Listeye eklenecek degeri giriniz: ";
    cin>>deger;
    node<int>::LLSiraliEkle(deger,head);
    node<int>::printList(head);
 }
 
 cout<<"\n Silinecek Degeri Giriniz : ";
 cin>>SilinecekDeger;
 
 if( node<int>::ListedenSil(head,SilinecekDeger) )
     node<int>::printList(head);
 else
    cout<<" Silinecek deger listede bulunamad� !\n";
  
  system("pause");
  return 0;
}
