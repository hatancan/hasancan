.MODEL SMALL
.STACK 100h
.DATA
isim DB "Isim: $"
cevir DB 30,?, 29 DUP ('$')
.CODE

MAIN 	PROC FAR
	MOV AX, @DATA   ; @ ile başlangıç adresi otomatik veriliyor
	MOV DS, AX	

	MOV AH,09h
	MOV DX, OFFSET isim     ; İsim okunup DX’e gönderildi
	INT 21h

	MOV DL,10D      ;SABİT KOD
	MOV AH,2h
	INT 21h

	MOV CX,11
	MOV DX,OFFSET isim
	PUSH CX
	MOV BX,OFFSET isim
	MOV SI,OFFSET cevir+4
	ADD SI,CX

DONDUR:	MOV AL,[BX]
	MOV [SI],AL
	INC BX
	DEC SI
	LOOP DONDUR

	POP CX
	MOV AH,40H
	MOV BX,1
	MOV DX,OFFSET cevir+2
	INT 21h

	MOV AH,4CH	;SABİT KOD
	INT 21H
	MAIN ENDP			
	END MAIN