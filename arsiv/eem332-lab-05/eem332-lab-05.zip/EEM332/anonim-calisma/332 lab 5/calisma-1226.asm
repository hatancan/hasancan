.MODEL SMALL
.STACK 100h
.DATA
isim DB "Isim: $"
cevir DB 30,?, 29 DUP ('$')
.CODE

MAIN 	PROC FAR
	MOV AX, @DATA   ; @ ile başlangıç adresi otomatik veriliyor
	MOV DS, AX	
	MOV ES, AX

	MOV AH,09h
	MOV DX, OFFSET isim     ; İsim okunup DX’e gönderildi
	INT 21h

	MOV AH,Ah         ; Döngünün tekrar sayısı
	MOV DX, OFFSET cevir     ; Değiştirilip ekrana yazılıyor
	INT 21h

	MOV DL,10D      ;SABİT KOD
	MOV AH,2h
	INT 21h

	CLD   ;	Destination flag sıfırlaması
	MOV DI,OFFSET cevir
	MOV CX,0FFh
	MOV AL,'e';     ;Değiştirilecek harf

DONGU:	REPNE SCASB   ; Harf bulunana kadar tarama yapılacak
	JNE OVER      ; Eşit değilse OVER döngüsüne atlıyor
	DEC DI	; DI’ nın değeri azaltılıyor
	MOV BYTE PTR[DI],'a'     ; “e” yerine “a” yazılacak
	INC CX         ; CX++
	LOOP DONGU

OVER:	MOV AX, 09H
	MOV DX, OFFSET cevir
	INT 21h

	MOV AH,4CH	;SABİT KOD
	INT 21H
	MAIN ENDP			
	END MAIN